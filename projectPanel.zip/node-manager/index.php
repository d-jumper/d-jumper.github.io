<?php
/**
 * NODE MANAGER - Main Controller
 * Path: node-manager/index.php
 */

// 1. ENVIRONMENT & INITIALIZATION
if (!isset($user_target)) {
    $user_target = isset($_GET['user']) ? preg_replace('/[^a-z0-9]/', '', $_GET['user']) : 'root';
} 
$base_dir = "/var/www/html/$user_target/node_apps/"; 
$json_file = $base_dir . "node_config.json"; 
$ajax_path = "node-manager/index.php";
$id = $_GET['id'] ?? '';
$redirect_url = "?page=manage&id=$id&subpage=node-config";
$user_manage_url = "?page=manage&id=$id";

// Pastikan direktori kerja tersedia
if (!is_dir($base_dir)) { mkdir($base_dir, 0775, true); }
if (!file_exists($json_file)) { file_put_contents($json_file, json_encode([])); }
$my_node = json_decode(file_get_contents($json_file), true);
if (!is_array($my_node)) $my_node = [];

// --- UPDATE PATH FILE ---
if (isset($_POST['update_path'])) {
    $node_name = $_POST['node_name'] ?? '';
    $new_relative = trim($_POST['new_path_relative'] ?? '', " /");
    
    $clean_base = rtrim($base_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    $full_path = $clean_base . $new_relative;
    $log_path = preg_replace("*.js", "", $full_path);

    if (isset($my_node[$node_name])) {
        if (file_exists($full_path)) {
            $real_entry_path = realpath($full_path); // Path absolut ke index.js
            $node_dir = dirname($real_entry_path); // Folder tempat index.js berada
            
            $my_node[$node_name]['path'] = $real_entry_path;
            // Simpan path log secara absolut di folder yang sama dengan file entry
            $my_node[$node_name]['npm_log'] = $node_dir . "/npm_action.log";
            
            if (file_put_contents($json_file, json_encode($my_node, JSON_PRETTY_PRINT))) {
                echo "<script>window.location.href='$redirect_url&status=success&msg=Jalur+path+berhasil+diperbarui';</script>";
            } else {
                echo "<script>window.location.href='$redirect_url&status=danger&msg=Gagal+menulis+config!';</script>";
            }
        } else {
            echo "<script>window.location.href='$redirect_url&status=danger&msg=$new_relative+tidak+ditemukan!';</script>";
        }
        exit;
    }
}

// --- DETEKSI ERROR UKURAN FILE (POST MAX SIZE) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST) && empty($_FILES) && $_SERVER['CONTENT_LENGTH'] > 0) {
    $max_post = ini_get('post_max_size');
    echo "<script>window.location.href='$redirect_url&status=danger&msg=File+terlalu+besar!';</script>";
    exit;
}

// --- LOGIKA AUTO-SCAN FOLDER ---
$existing_folders = glob($base_dir . '*', GLOB_ONLYDIR);
$has_new_scan = false;
if ($existing_folders) {
    foreach ($existing_folders as $folder_path) {
        $node_name = basename($folder_path);
        $expected_file = $folder_path . "/index.js";
        if (file_exists($expected_file) && !isset($my_node[$node_name])) {
            $my_node[$node_name] = ['path' => $expected_file, 'node' => 'Not Available!'];
            $has_new_scan = true;
        }
    }
}
if ($has_new_scan) file_put_contents($json_file, json_encode($my_node));

// --- HELPER FUNCTIONS ---
function getInstalledNodeVersions() {
    $versions = [];
    $base_nvm = "/var/www/.nvm";
    $nvm_path = $base_nvm . "/versions/node/";
    if (is_dir($nvm_path)) {
        $dirs = glob($nvm_path . 'v*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            $versions[] = str_replace('v', '', basename($dir));
        }
    }
    $system_node = shell_exec("node -v 2>&1");
    if ($system_node && strpos($system_node, 'v') === 0) {
        $versions[] = str_replace('v', '', trim($system_node));
    }
    $versions = array_unique($versions);
    sort($versions, SORT_NATURAL);
    return !empty($versions) ? $versions : ['Not Available!'];
}
function getNodeBinary($version) {
    $base_nvm = "/var/www/.nvm";
    $paths = [
        "{$base_nvm}/versions/node/v{$version}/bin/node",
        "{$base_nvm}/versions/node/v{$version}.0/bin/node",
        "/usr/local/bin/node"
    ];
    if (strpos($version, '.') === false) {
        $glob_path = glob("{$base_nvm}/versions/node/v{$version}*/bin/node");
        if (!empty($glob_path)) return $glob_path[0];
    }
    foreach($paths as $p) { if (file_exists($p)) return $p; }
    return "node";
}
function getNpmBinary($version) {
    $node_bin = getNodeBinary($version);
    $npm_bin = str_replace('/bin/node', '/bin/npm', $node_bin);
    return file_exists($npm_bin) ? $npm_bin : "npm";
}
$available_versions = getInstalledNodeVersions();

// --- LOGIKA HAPUS NODE & BERKAS ---
if (isset($_POST['delete_node'])) {
    $name = $_POST['node_name'];
    
    if (isset($my_node[$name])) {
        $entry_path = $my_node[$name]['path'];
        $node_dir = realpath(dirname($entry_path));
        
        shell_exec("sudo pm2 delete " . escapeshellarg($name) . " 2>&1");
        $clean_base = realpath($base_dir);
        if ($node_dir && strpos($node_dir, $clean_base) === 0 && $node_dir !== $clean_base) {
            shell_exec("sudo rm -rf " . escapeshellarg($node_dir));
        }

        unset($my_node[$name]);
        file_put_contents($json_file, json_encode($my_node, JSON_PRETTY_PRINT));
    }
    
    echo "<script>window.location.href='$redirect_url&status=success&msg=Node+dan+Folder+berhasil+dihapus';</script>";
    exit;
}

// --- LOGIKA UPLOAD & ADD NODE ---
if (isset($_POST['add_node'])) {
    $new_name = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['new_name'] ?? '');
    $target_dir = $base_dir . $new_name;
    
    if (empty($new_name) || !isset($_FILES['node_file'])) {
        echo "<script>window.location.href='$redirect_url&status=danger&msg=Data+tidak+lengkap!';</script>";
        exit;
    }

    $file = $_FILES['node_file'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $file_error = $file['error'];
        echo "<script>window.location.href='$redirect_url&status=danger&msg=Upload+gagal!+Kode+(+$file_error+)';</script>";
        exit;
    }

    if (is_dir($target_dir)) {
        echo "<script>window.location.href='$redirect_url&status=danger&msg=Nama+node+sudah+digunakan!';</script>";
        exit;
    }

    mkdir($target_dir, 0775, true);
    $zip = new ZipArchive;
    if ($zip->open($file['tmp_name']) === TRUE) {
        $zip->extractTo($target_dir);
        $zip->close();
        
        $expected_file = $target_dir . "/index.js";
        if (!file_exists($expected_file)) {
            $subfolders = glob($target_dir . '/*/index.js');
            if (!empty($subfolders)) {
                $expected_file = $subfolders[0];
            } else {
                file_put_contents($expected_file, "console.log('node $new_name started...');\nsetInterval(() => {}, 1000);");
            }
        }
        
        // Mengambil folder tempat file eksekusi berada secara absolut
        $real_entry_path = realpath($expected_file);
        $node_dir = dirname($real_entry_path);
        
        // Simpan semua data ke dalam satu array agar tidak terhapus (overwrite)
        $my_node[$new_name] = [
            'path' => $real_entry_path, // Path file .js
            'node' => $_POST['node_version'], // Versi Node.js yang dipilih
            'npm_log' => $node_dir . "/npm_action.log" // Lokasi log NPM di folder yang sama
        ];
        
        file_put_contents($json_file, json_encode($my_node));
        echo "<script>window.location.href='$redirect_url&status=success&msg=Berhasil+membuat+node+baru';</script>";
        exit;
    } else {
        echo "<script>window.location.href='$redirect_url&status=danger&msg=Gagal+mengekstrak+ZIP!';</script>";
        exit;
    }
}

// --- AJAX: DETEKSI PACKAGE ---
if (isset($_GET['check_file'])) {
    header('Content-Type: application/json');
    $relative_path = trim($_GET['check_file'], " /");
    $full_path = rtrim($base_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $relative_path;
    
    echo json_encode([
        'exists' => (!empty($relative_path) && file_exists($full_path)),
        'path_searched' => $relative_path
    ]);
    exit;
}
if (isset($_GET['detect_packages'])) {
    header('Content-Type: application/json');
    $name = $_GET['detect_packages'];
    
    if (!isset($my_node[$name])) { 
        echo json_encode(['packages' => [], 'error' => 'Node not found']); 
        exit; 
    }
    
    // Pastikan kita bekerja di direktori root project
    $entry_path = $my_node[$name]['path']; // Misal: /app/sub/start.js
    $node_dir = dirname($entry_path);
    
    // Cari package.json di direktori yang sama atau naik ke atas (root)
    $package_json_path = $node_dir . "/package.json";
    
    // Jika tidak ketemu di folder entry, coba cek satu level di atasnya
    if (!file_exists($package_json_path)) {
        $package_json_path = dirname($node_dir) . "/package.json";
        $node_dir = dirname($node_dir); // Reset root dir ke lokasi package.json
    }

    $found_packages = [];
    $to_install = [];

    // --- STRATEGI 1: Analisis package.json (Paling Akurat) ---
    if (file_exists($package_json_path)) {
        $pkg_data = json_decode(file_get_contents($package_json_path), true);
        
        // 1. Ambil dari dependencies
        if (isset($pkg_data['dependencies'])) {
            $found_packages = array_keys($pkg_data['dependencies']);
        }
        
        // 2. Jika ada properti "main", update entry_path ke file tersebut
        if (isset($pkg_data['main'])) {
            $entry_path = $node_dir . "/" . ltrim($pkg_data['main'], './');
        }
    }

    // --- STRATEGI 2: Deep Scan Entry File (Regex Fallback) ---
    if (file_exists($entry_path)) {
        $content = file_get_contents($entry_path);
        // Regex diperkuat untuk menangkap require, import, dan export dari module
        preg_match_all('/(?:require\(|from\s+|import\s+[\'"])([\'"]?)([^.\/][^\'"]+)\1/', $content, $matches);
        if (!empty($matches[2])) {
            $found_packages = array_unique(array_merge($found_packages, $matches[2]));
        }
    }

    // --- VALIDASI & FILTER ---
    $built_in = ['fs', 'path', 'http', 'https', 'crypto', 'os', 'util', 'events', 'child_process', 'stream', 'url', 'querystring', 'buffer', 'process', 'tls', 'net'];
    
    $to_install = [];
    $already_installed = [];
    
    foreach ($found_packages as $pkg) {
        $main_pkg = explode('/', trim($pkg, " '\""))[0]; 
        if (strpos($pkg, '@') === 0 && count(explode('/', $pkg)) >= 2) {
            $parts = explode('/', $pkg);
            $main_pkg = $parts[0] . '/' . $parts[1];
        }

        if (in_array($main_pkg, $built_in) || empty($main_pkg)) continue;

        // CEK APAKAH FOLDER SUDAH ADA
        if (is_dir($node_dir . "/node_modules/" . $main_pkg)) {
            $already_installed[] = $main_pkg; // Masuk daftar uninstall
        } else {
            $to_install[] = $main_pkg; // Masuk daftar install
        }
    }

    echo json_encode([
        'packages' => array_values(array_unique($to_install)),
        'already_installed' => array_values(array_unique($already_installed)),
        'detected_root' => $node_dir,
        'entry_file' => basename($entry_path)
    ]);
    exit;
}

// --- LOGIKA PM2 ACTIONS ---
if (isset($_POST['action']) && isset($_POST['node_name'])) {
    $name = $_POST['node_name'];
    $action = $_POST['action'];
    $info = $my_node[$name];
    $msgg = "";
    
    // Ambil versi yang dipilih user (default ke Not Available! jika tidak ada)
    $version_choice = $info['node'] ?? 'Not Available!';
    $interpreter = getNodeBinary($version_choice);
    
    if ($action == 'start') {
        // Tambahkan --interpreter agar PM2 menggunakan versi spesifik yang dipilih user
        // Kita gunakan escapeshellarg untuk keamanan path
        $cmd = "sudo pm2 start " . escapeshellarg($info['path']) . " --name " . escapeshellarg($name) . " --interpreter " . escapeshellarg($interpreter) . " 2>&1";
        shell_exec($cmd);
        $msgg = "Node+v$version_choice+telah+dijalankan";
    } elseif ($action == 'stop') {
        shell_exec("sudo pm2 stop " . escapeshellarg($name));
        $msgg = "Node+telah+dihentikan";
    } elseif ($action == 'restart') {
        // Restart otomatis menggunakan interpreter yang sudah terdaftar saat start
        shell_exec("sudo pm2 restart " . escapeshellarg($name));
        $msgg = "Node+telah+direstart";
    } elseif ($action == 'clear_logs') {
        shell_exec("sudo pm2 flush " . escapeshellarg($name));
        $msgg = "Log+telah+dibersihkan";
    }
        echo "<script>window.location.href='$redirect_url&status=success&msg=$msgg';</script>";
        exit;
}

// --- LOGIKA NPM INSTALL/UNINSTALL ---
if (isset($_POST['install_npm']) || isset($_POST['uninstall_npm'])) {
    $node_name = $_POST['node_name'];
    $package = $_POST['package_name'];
    $info = $my_node[$node_name];
    $node_v = $info['node'] ?? 'Not Available!';
    $node_path = dirname($info['path']);
    $log_file = $node_path . "/npm_action.log";
    $type = isset($_POST['install_npm']) ? "install" : "uninstall";
    $npm_bin = getNpmBinary($node_v);
    $node_bin = getNodeBinary($node_v);
    $node_dir = dirname($node_bin);
    
    $header = "[SYSTEM] Node v$node_v Detected\n[SYSTEM] Running: npm $type $package\n-----------------------------------\n";
    file_put_contents($log_file, $header);
    chmod($log_file, 0666);
    
    $cmd = "export PATH=$node_dir:\$PATH && cd " . escapeshellarg($node_path) . " && sudo env PATH=\$PATH $npm_bin $type " . escapeshellarg($package) . " --no-audit --no-fund --loglevel=info";
    shell_exec("$cmd >> " . escapeshellarg($log_file) . " 2>&1 &");
    echo json_encode(['status' => 'started']);
    exit;
}

// --- LOGIKA INSTALL BARU VIA NPM ---
if (isset($_POST['npm_install_plugin'])) {
    header('Content-Type: application/json');
    $pkg_name = preg_replace('/[^a-zA-Z0-9@\/_-]/', '', $_POST['package_name'] ?? '');
    $node_v = $_POST['node_version'] ?? 'Not Available!';
    
    // 1. Tentukan Nama Folder (Gunakan nama package sebagai nama folder agar mudah dideteksi)
    // Contoh: @user/package-name menjadi user-package-name
    $clean_folder_name = str_replace(['@', '/'], '-', $pkg_name);
    $target_dir = rtrim($base_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $clean_folder_name;
    $log_file = $target_dir . "/npm_action.log";
    $entry_file = $target_dir . "/index.js";

    // 2. Buat folder aplikasi terlebih dahulu agar perintah 'cd' tidak gagal
    if (!is_dir($target_dir)) { 
        mkdir($target_dir, 0775, true); 
        chmod($target_dir, 0775); 
    }

    // 3. PRE-CREATE LOG: Wajib ada file fisik sebelum shell_exec dimulai
    file_put_contents($log_file, "[SYSTEM] Memulai instalasi package: $pkg_name ke folder $clean_folder_name...\n");
    chmod($log_file, 0666);

    // 4. Inisialisasi file index.js bootstrap
    if (!file_exists($entry_file)) {
        $starter_code = "const plugin = require('$pkg_name');\nconsole.log('Plugin $pkg_name aktif!');\nsetInterval(() => {}, 1000);";
        file_put_contents($entry_file, $starter_code);
    }

    // 5. Simpan konfigurasi ke JSON (Lakukan sebelum shell agar UI bisa langsung polling)
    $my_node[$clean_folder_name] = [
        'path' => realpath($entry_file) ?: $entry_file,
        'node' => $node_v,
        'npm_log' => realpath($log_file) ?: $log_file
    ];
    file_put_contents($json_file, json_encode($my_node, JSON_PRETTY_PRINT));

    // 6. Eksekusi Perintah NPM di folder target
    $npm_bin = getNpmBinary($node_v);
    $cmd = "cd " . escapeshellarg($target_dir) . " && $npm_bin init -y && $npm_bin install --save " . escapeshellarg($pkg_name);
    
    // Gunakan '>>' agar tidak menimpa pesan [SYSTEM] di atas
    shell_exec("$cmd >> " . escapeshellarg($log_file) . " 2>&1 &");

    echo json_encode(['status' => 'started', 'node_name' => $clean_folder_name]);
    exit;
}

// --- UPDATE VERSI ---
if (isset($_POST['update_node_version'])) {
    $my_node[$_POST['node_name']]['node'] = $_POST['node_version'];
    file_put_contents($json_file, json_encode($my_node));
        echo "<script>window.location.href='$redirect_url&status=success&msg=Versi+node+berhasil+diubah';</script>";
        exit;
}

// AMBIL STATUS PM2
$pm2_data = json_decode(shell_exec("sudo pm2 jlist"), true) ?: [];
$statuses = [];
foreach ($pm2_data as $proc) { 
    $statuses[$proc['name']] = $proc['pm2_env']['status']; 
}
?>

<div class="container mt-4">

    <div class="plesk-card-header p-3 border-bottom d-flex justify-content-between align-items-center">
        <span class="fw-bold"></span>
        <div class="d-flex gap-2">
            <a href="<?php echo $user_manage_url; ?>" class="btn btn-sm btn-outline-secondary">Kembali</a>
        </div>
    </div>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="text-muted fw-bold mb-0"><i class="bi bi-cpu-fill me-2 text-primary"></i>Node Version Manager</h6>
        <div class="row g-2">
            <h6 class="text-muted fw-bold mb-0"></h6>
            <button class="btn btn-outline-primary btn-sm rounded-pill px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#npmInstallModal">
                <i class="bi bi-plus-circle me-1"></i> Install Node
            </button>
            <button class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">
                <i class="bi bi-upload me-1"></i> Upload Node
            </button>
        </div>
    </div>
    
    <div class="card border-0 shadow-sm mb-4 rounded-4 overflow-hidden">
        <div class="card-header bg-white border-0 py-3">
            <h6 class="mb-0 fw-bold text-dark">
                <i class="bi bi-layers-half me-2 text-primary"></i>Installed Node.js Versions
            </h6>
        </div>
        <div class="card-body pt-0">
            <div class="d-flex flex-wrap gap-2">
                <?php 
                $system_node = trim(shell_exec("node -v 2>&1"), 'v');
                foreach ($available_versions as $version): 
                    $is_system = ($version == $system_node);
                ?>
                    <div class="d-flex align-items-center bg-light rounded-pill px-3 py-2 border shadow-sm">
                        <div class="bg-success rounded-circle me-2" style="width: 8px; height: 8px;"></div>
                        <span class="small fw-bold text-secondary">v<?= htmlspecialchars($version) ?></span>
                        <?php if ($is_system): ?>
                            <span class="badge bg-primary ms-2" style="font-size: 0.5rem;">DEFAULT</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="mt-3 p-2 bg-light-subtle rounded-3 border border-dashed">
                <small class="text-muted" style="font-size: 0.65rem;">
                    <i class="bi bi-info-circle me-1"></i>
                    Versi di atas dapat dipilih sebagai <b>Interpreter</b> pada masing-masing aplikasi Node Anda melalui menu NPM Manager.
                </small>
            </div>
        </div>
    </div>
    
    <?php foreach($my_node as $name => $info): 
        $node_v = $info['node'] ?? 'Not Available!';
        $status = $statuses[$name] ?? 'stopped';
        $is_online = ($status == 'online');
    ?>
    <div class="card p-3 mb-3 border-0 shadow-sm position-relative">
        <div class="position-absolute top-0 end-0 p-3 d-flex align-items-center gap-2">
            <div class="<?= $is_online ? 'spinner-grow text-success' : 'bg-danger rounded-circle' ?>" style="width: 12px; height: 12px;"></div>
            <form method="POST" onsubmit="return confirm('Hapus Node ini?')">
                <input type="hidden" name="node_name" value="<?= $name ?>">
                <button type="submit" name="delete_node" 
                    class="btn btn-danger" 
                    onclick="return confirm('PERINGATAN: Node dan SEMUA BERKAS di folder ini akan dihapus permanen. Lanjutkan?')">
                    <i class="bi bi-trash"></i>
                </button>
            </form>
        </div>
        
        <h6 class="mb-1 fw-bold text-dark"><?= strtoupper($name) ?></h6>
        
        <form method="POST" class="mb-3">
            <input type="hidden" name="node_name" value="<?= $name ?>">
            
            <small class="text-muted" style="font-size: 0.6rem;"> Jalur Path :</small>
            <div class="input-group input-group-sm">
                <span class="input-group-text bg-light border-0">
                    <i class="bi bi-file-earmark-code text-primary"></i>
                </span>
                
                <?php 
                    // Pastikan kita membersihkan path absolut menjadi relatif dengan benar
                    $current_full_path = $my_node[$name]['path'];
                    $clean_base = rtrim($base_dir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
                    $display_path = str_replace($clean_base, '', $current_full_path); 
                ?>
                
                <input type="text" name="new_path_relative" 
                    id="input-path-<?= $name ?>"
                    class="form-control border-0 bg-light-subtle shadow-none" 
                    value="<?= htmlspecialchars($display_path) ?>" 
                    onkeyup="checkFileRealtime('<?= $name ?>')"
                    placeholder="folder/index.js"
                    style="font-size: 0.75rem; font-family: 'Courier New', monospace;">
                    
                <button id="btn-save-<?= $name ?>" class="btn btn-outline-primary border-0" type="submit" name="update_path">
                    <i class="bi bi-check-lg"></i>
                </button>
            </div>
        </form>
        
        <div class="d-flex gap-2 mb-3">
            <span class="badge rounded-pill bg-<?= $is_online?'success':'secondary' ?> shadow-sm" style="font-size: 0.6rem;"><?= strtoupper($status) ?></span>
            <span class="badge rounded-pill bg-info text-dark shadow-sm" style="font-size: 0.6rem;">Node v<?= $node_v ?></span>
        </div>

        <div class="row g-2">
            <div class="col-8">
                <form method="POST" class="btn-group w-100 shadow-sm rounded-3 overflow-hidden">
                    <input type="hidden" name="node_name" value="<?= $name ?>">
                    <button name="action" value="<?= $is_online?'stop':'start' ?>" class="btn btn-<?= $is_online?'danger':'success' ?> btn-sm">
                        <i class="bi bi-<?= $is_online?'stop':'play' ?>-fill"></i>
                    </button>
                    <button name="action" value="restart" class="btn btn-warning btn-sm text-white"><i class="bi bi-arrow-clockwise"></i></button>
                    <button name="action" value="clear_logs" class="btn btn-dark btn-sm"><i class="bi bi-eraser-fill"></i></button>
                </form>
            </div>
            
            <div class="col-2">
                <button class="btn btn-sm btn-outline-dark w-100 shadow-sm" 
                        data-bs-toggle="modal" 
                        data-bs-target="#logModal<?= $name ?>" 
                        onclick="setActiveLogNode('<?= $name ?>')">
                    <i class="bi bi-terminal"></i>
                </button>
            </div>
            
            <div class="col-2">
                <button class="btn btn-sm btn-outline-primary w-100 shadow-sm" 
                    data-bs-toggle="modal" 
                    data-bs-target="#npmModal<?= $name ?>" 
                    onclick="autoDetectPackages('<?= $name ?>')">
                <i class="bi bi-box-seam"></i>
            </button>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="logModal<?= $name ?>" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content bg-dark border-0 shadow-lg rounded-4">
                <div class="modal-header border-secondary border-opacity-25">
                    <h6 class="modal-title text-white">
                        <i class="bi bi-terminal me-2 text-info"></i>Log Konsol: <?= strtoupper($name) ?>
                    </h6>
                    
                    <div class="form-check form-switch mb-0 ms-auto me-3">
                        <input class="form-check-input" type="checkbox" id="scrollToggle-<?= $name ?>" checked>
                        <label class="form-check-label text-white small" for="scrollToggle-<?= $name ?>">Auto-scroll</label>
                    </div>
                    
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                
                    <pre id="log-<?= $name ?>"
                        class="bg-dark text-info p-2 rounded-3" 
                        style="height: 450px; overflow-y: auto; font-family: monospace; font-size: 0.7rem; white-space: pre-wrap;">
                        <span class="text-muted"><b>****Log Konsol: <?= strtoupper($name) ?>****</b></span>
                    </pre>
                    
                </div>
                <div class="modal-footer border-secondary border-opacity-25">
                    <button class="btn btn-sm btn-outline-info" onclick="copyLog('<?= $name ?>', this)">
                        <i class="bi bi-clipboard me-1"></i> Copy Log
                    </button>
                    <button class="btn btn-sm btn-outline-light" onclick="fetchSingleLog('<?= $name ?>')">
                        <i class="bi bi-arrow-clockwise"></i> Refresh
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="npmModal<?= $name ?>" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4">
                <div class="modal-header border-0"><h6 class="fw-bold mb-0">NPM Manager: <?= $name ?></h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body pt-0">
                    <form method="POST" class="mb-3 p-2 bg-light rounded-3">
                        <div class="input-group input-group-sm">
                            <select name="node_version" class="form-select border-0 bg-transparent">
                                <?php foreach($available_versions as $av): ?>
                                    <option value="<?= $av ?>" <?= ($node_v == $av) ? 'selected' : '' ?>>Node v<?= $av ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="hidden" name="node_name" value="<?= $name ?>">
                            <button name="update_node_version" class="btn btn-dark">Update Node</button>
                        </div>
                    </form>
                    <div id="auto_detect_<?= $name ?>" class="mb-3 d-none">
                        <div class="p-2 border border-primary border-opacity-25 rounded-3 bg-primary-subtle bg-opacity-10 text-center">
                            <small class="d-block fw-bold text-primary mb-1">Package yang dibutuhkan:</small>
                            <div id="pkg_list_<?= $name ?>" class="mb-2"></div>
                            <button class="btn btn-primary btn-sm w-100 shadow-sm" id="btn_auto_<?= $name ?>" onclick="installDetected('<?= $name ?>')">Install Semua</button>
                        </div>
                    </div>
                    <div id="prog_box_<?= $name ?>" class="mb-3 d-none">
                        <div class="d-flex justify-content-between mb-1 small">
                            <span id="npm_stat_<?= $name ?>" class="text-muted">Menghubungkan...</span>
                            <span id="npm_perc_<?= $name ?>" class="fw-bold text-primary">0%</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div id="npm_bar_<?= $name ?>" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
                        </div>
                    </div>
                    <div class="input-group mb-2 shadow-sm">
                        <input type="text" id="pkg_<?= $name ?>" class="form-control border-0 bg-light" placeholder="Nama package">
                        
                        <button class="btn btn-primary" onclick="npmAction('<?= $name ?>', 'install')" title="Install">
                            <i class="bi bi-download"></i>
                        </button>
                        
                        <button class="btn btn-outline-danger" onclick="npmAction('<?= $name ?>', 'uninstall')" title="Uninstall">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                    <div id="status_<?= $name ?>" class="d-none mt-2">
                        <pre id="log_out_<?= $name ?>" class="bg-dark text-white p-2 rounded-3 small" style="height: 150px; overflow-y: auto; font-size: 0.65rem;"></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php endforeach; ?>
</div>

<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-body p-4 text-center">
                <div class="bg-primary-subtle text-primary rounded-circle m-auto d-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;"><i class="bi bi-cloud-upload fs-2"></i></div>
                <h5 class="fw-bold mb-3">Upload Node (.zip)</h5>
                <form method="POST" enctype="multipart/form-data">
                    <input type="text" name="new_name" class="form-control mb-2" placeholder="Nama App (e.g. my-bot)" required>
                    <div class="mb-2">
                        <input type="file" name="node_file" class="form-control" accept=".zip" required>
                    </div>
                    <select name="node_version" class="form-select mb-3">
                        <?php foreach($available_versions as $av): ?>
                            <option value="<?= $av ?>" <?= ($av == 'Not Available!') ? 'selected' : '' ?>>Node v<?= $av ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button name="add_node" class="btn btn-primary w-100 rounded-pill py-2 fw-bold">Ekstrak & Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="npmInstallModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <div class="modal-body p-4 text-center">
                <div class="bg-primary-subtle text-primary rounded-circle m-auto d-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                    <i class="bi bi-box-seam fs-2"></i>
                </div>
                <h5 class="fw-bold mb-3">Install via NPM Repository</h5>
                
                <input type="text" id="new_pkg_name" class="form-control mb-2" placeholder="Nama Package (e.g. mutasi-bca)" required>
                <select id="new_pkg_version" class="form-select mb-3">
                    <?php foreach($available_versions as $av): ?>
                        <option value="<?= $av ?>" <?= ($av == 'Not Available!') ? 'selected' : '' ?>>Gunakan Node v<?= $av ?></option>
                    <?php endforeach; ?>
                </select>

                <div id="new_install_prog" class="mb-3 d-none">
                    <div class="d-flex justify-content-between mb-1 small">
                        <span id="new_install_stat" class="text-muted">Menyiapkan...</span>
                        <span id="new_install_perc" class="fw-bold text-primary">0%</span>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div id="new_install_bar" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
                    </div>
                    <pre id="new_install_log" class="bg-dark text-white p-2 rounded-3 mt-2 text-start" style="height: 100px; overflow-y: auto; font-size: 0.6rem;"></pre>
                </div>

                <button id="btn_do_install" onclick="createNewNodeFromNPM()" class="btn btn-primary w-100 rounded-pill py-2 fw-bold">Download & Install</button>
            </div>
        </div>
    </div>
</div>>

<script>
const API_URL = 'node-manager/index.php';
const LOG_URL = 'node-manager/get_npm_log.php';
const userTarget = <?= json_encode($user_target) ?>;

let activeLogNode = null;
let logInterval = null;
function setActiveLogNode(name) {
    // Bersihkan interval lama jika ada
    if (logInterval) clearInterval(logInterval);
    
    // Ambil log pertama kali
    fetchSingleLog(name);
    
    // Set interval baru khusus untuk node yang sedang aktif
    logInterval = setInterval(() => {
        const modalEl = document.getElementById(`logModal${name}`);
        if (modalEl && modalEl.classList.contains('show')) {
            fetchSingleLog(name);
        } else {
            clearInterval(logInterval);
        }
    }, 3000); // Cek setiap 3 detik
}
function fetchSingleLog(name) {
    const el = document.getElementById('log-' + name);
    if (!el) return;

    // 1. Cek apakah user berada di posisi paling bawah sebelum update
    // Toleransi 50px agar tidak terlalu kaku
    const isAtBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < 50;

    fetch(`node-manager/get_logs.php?name=${name}&user=${userTarget}&t=${Date.now()}`)
        .then(r => r.text())
        .then(data => {
            // 2. Update konten teks log
            el.textContent = data.trim() ? data : "--- Belum ada log ---";
            
            // 3. Hanya scroll ke bawah jika user memang sedang di posisi bawah
            if (isAtBottom) {
                el.scrollTop = el.scrollHeight;
            }
        })
        .catch(err => console.error("Gagal mengambil log:", err));
}
function copyLog(name, btn) {
    const logEl = document.getElementById('log-' + name);
    if (!logEl) return;

    // Ambil teks dari log
    const textToCopy = logEl.textContent || logEl.innerText;

    // Gunakan Clipboard API
    navigator.clipboard.writeText(textToCopy).then(() => {
        // Beri feedback visual ke user
        const originalHTML = btn.innerHTML;
        btn.classList.remove('btn-outline-info');
        btn.classList.add('btn-success');
        btn.innerHTML = '<i class="bi bi-check2"></i> Copied!';

        // Kembalikan ke tombol semula setelah 2 detik
        setTimeout(() => {
            btn.classList.remove('btn-success');
            btn.classList.add('btn-outline-info');
            btn.innerHTML = originalHTML;
        }, 2000);
    }).catch(err => {
        console.error('Gagal menyalin log: ', err);
        alert('Gagal menyalin log.');
    });
}
let typingTimer;
function checkFileRealtime(nodeName) {
    clearTimeout(typingTimer);
    const inputEl = document.getElementById('input-path-' + nodeName);
    const btnSave = document.getElementById('btn-save-' + nodeName);
    const path = inputEl.value.trim();

    typingTimer = setTimeout(() => {
        if(!path) return;
        fetch(`${API_URL}?check_file=${encodeURIComponent(path)}&user=${userTarget}`)
            .then(r => r.json())
            .then(data => {
                if (data.exists) {
                    inputEl.style.borderLeft = "4px solid #198754"; // Hijau jika ada
                    btnSave.disabled = false;
                } else {
                    inputEl.style.borderLeft = "4px solid #dc3545"; // Merah jika tidak ada
                    btnSave.disabled = true;
                }
            });
    }, 500);
}

function autoDetectPackages(name) {
    fetch(`${API_URL}?detect_packages=${name}&user=${userTarget}`)
        .then(r => r.json())
        .then(data => {
            const box = document.getElementById('auto_detect_' + name);
            const list = document.getElementById('pkg_list_' + name);
            
            if(data.packages && data.packages.length > 0) {
                box.classList.remove('d-none');
                list.innerHTML = data.packages.map(p => 
                    `<span class="badge bg-primary m-1">${p}</span>`
                ).join('');
                window['detected_' + name] = data.packages;
            } else if(data.already_installed && data.already_installed.length > 0) {
                list.innerHTML += `
                    <div class="d-inline-flex align-items-center bg-white border rounded-pill px-2 py-1 m-1 shadow-sm" style="font-size: 0.7rem;">
                        <span class="text-success fw-bold me-2"><i class="bi bi-check-circle"></i> ${p}</span>
                        <button type="button" class="btn btn-link p-0 text-danger lh-1" onclick="triggerUninstall('${name}', '${p}')">
                            <i class="bi bi-x-circle-fill"></i>
                        </button>
                    </div>`;
            }
            
        })
        .catch(err => console.error("Error detecting packages:", err));
}

// Fungsi bantu untuk memicu uninstall dari daftar deteksi
function triggerUninstall(nodeName, pkgName) {
    if(confirm(`Yakin ingin menghapus package ${pkgName}?`)) {
        const input = document.getElementById('pkg_' + nodeName);
        input.value = pkgName;
        npmAction(nodeName, 'uninstall');
    }
}

async function installDetected(name) {
    const pkgs = window['detected_' + name];
    if(!pkgs || pkgs.length === 0) return;
    
    const btn = document.getElementById('btn_auto_' + name);
    const originalText = btn.innerText;
    
    btn.disabled = true;
    btn.innerHTML = `<span class="spinner-border spinner-border-sm"></span> Menginstal...`;
    
    for(let p of pkgs) {
        // Masukkan nama package ke input manual agar terlihat prosesnya
        document.getElementById('pkg_' + name).value = p;
        
        // Tunggu sampai npmAction selesai untuk package ini sebelum lanjut ke berikutnya
        await npmAction(name, 'install');
    }
    
    btn.innerText = "Semua Terinstall!";
    btn.className = "btn btn-success btn-sm w-100";
    
    // Sembunyikan box auto-detect setelah selesai
    setTimeout(() => {
        document.getElementById('auto_detect_' + name).classList.add('d-none');
    }, 2000);
}

function npmAction(nodeName, type) {
    const pkgInput = document.getElementById('pkg_' + nodeName);
    const pkg = pkgInput.value.trim(); // Gunakan .trim()
    
    if(!pkg) {
        alert("Nama package tidak boleh kosong!");
        return Promise.resolve();
    }

    const progBox = document.getElementById('prog_box_' + nodeName);
    const bar = document.getElementById('npm_bar_' + nodeName);
    const perc = document.getElementById('npm_perc_' + nodeName);
    const stat = document.getElementById('npm_stat_' + nodeName);
    const out = document.getElementById('log_out_' + nodeName);
    out.innerText = `[SYSTEM] Bersiap menginstal: ${pkg}...`;
    const statusDiv = document.getElementById('status_' + nodeName);

    progBox.classList.remove('d-none');
    statusDiv.classList.remove('d-none');
    bar.style.width = '5%';
    bar.className = "progress-bar progress-bar-striped progress-bar-animated bg-primary";
    perc.innerText = '5%';
    stat.innerText = 'Memproses: ' + pkg;

    const fd = new FormData();
    fd.append(type + '_npm', '1');
    fd.append('node_name', nodeName);
    fd.append('package_name', pkg);
    fd.append('user_target', userTarget);

    return new Promise((resolve) => {
        // Sesuaikan URL fetch ke index.php (lokasi logic POST Anda)
        fetch(API_URL+'?user='+userTarget, { method: 'POST', body: fd }).then(r => r.json()).then(() => {
            let lastLog = "";
            let errorOccurred = false;
            
            const interval = setInterval(() => {
                fetch(LOG_URL+'?name='+nodeName+'&user='+userTarget+'&t=${Date.now()}')
                .then(r => r.text())
                .then(data => {
                    if (data === lastLog || data.trim() === "") return;
                    lastLog = data;
                    out.innerText = data;
                    out.scrollTop = out.scrollHeight;

                    // Logika Progress Bar sederhana berdasarkan keyword log NPM
                    const fetchCount = (data.match(/http fetch/g) || []).length;
                    const extractCount = (data.match(/extract/g) || []).length;
                    let p = Math.min(95, 10 + (fetchCount * 3) + (extractCount * 2));
                    bar.style.width = p + '%';
                    perc.innerText = p + '%';

                    // Deteksi Selesai atau Error
                    const isDone = data.includes('added') || 
                                   data.includes('removed') || 
                                   data.includes('up to date') || 
                                   data.includes('npm info ok') || 
                                   data.includes('Completed');
                                   
                    const isError = data.toLowerCase().includes('npm err!') || 
                                    data.toLowerCase().includes('error');

                    if (isDone || isError) {
                        clearInterval(interval);
                        bar.style.width = '100%';
                        perc.innerText = '100%';
                        stat.innerText = isError ? 'Terjadi Kesalahan!' : 'Selesai!';
                        bar.classList.remove('progress-bar-animated');
                        bar.classList.add(isError ? 'bg-danger' : 'bg-success');
                        
                        pkgInput.value = "";
                        setTimeout(resolve, 1000);
                    }
                }).catch(err => {
                    console.error("Gagal mengambil log:", err);
                });
            }, 1500); // Interval 1.5 detik agar tidak membebani server
        });
    });
}

function createNewNodeFromNPM() {
    const pkg = document.getElementById('new_pkg_name').value.trim();
    const ver = document.getElementById('new_pkg_version').value;
    const btn = document.getElementById('btn_do_install');
    
    if(!pkg) return alert("Masukkan nama package!");

    btn.disabled = true;
    document.getElementById('new_install_prog').classList.remove('d-none');
    
    const fd = new FormData();
    fd.append('npm_install_plugin', '1');
    fd.append('package_name', pkg);
    fd.append('node_version', ver);

    fetch(API_URL + '?user=' + userTarget, { method: 'POST', body: fd })
    .then(r => r.json())
    .then(res => {
        let lastLog = "";
        const interval = setInterval(() => {
            fetch(`node-manager/get_npm_log.php?name=${res.node_name}&user=${userTarget}`)
            .then(r => r.text())
            .then(data => {
                if (!data || data === lastLog) return;
                lastLog = data;
                
                const logBox = document.getElementById('new_install_log');
                const bar = document.getElementById('new_install_bar');
                const perc = document.getElementById('new_install_perc');
                
                logBox.innerText = data;
                logBox.scrollTop = logBox.scrollHeight;

                // Estimasi Progress (10% per keyword yang ditemukan)
                const p = Math.min(95, (data.match(/http fetch|extract|added|POST|GET/g) || []).length * 10);
                bar.style.width = p + '%';
                perc.innerText = p + '%';

                // Deteksi Selesai atau Error
                if (data.includes('added') || data.includes('npm info ok') || data.toLowerCase().includes('npm err!')) {
                    clearInterval(interval);
                    bar.style.width = '100%';
                    perc.innerText = '100%';
                    document.getElementById('new_install_stat').innerText = data.toLowerCase().includes('err') ? "Gagal!" : "Selesai!";
                    
                    if(!data.toLowerCase().includes('err')) {
                        setTimeout(() => window.location.reload(), 1500);
                    } else {
                        btn.disabled = false;
                    }
                }
            });
        }, 1500);
    });
}
</script>