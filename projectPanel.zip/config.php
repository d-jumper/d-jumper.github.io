<?php
    date_default_timezone_set('Asia/Jakarta');
        
    $showErrorLog = true;
    if ($showErrorLog) {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(0);
    }

    $db_config = [
        'host' => 'localhost',
        'name' => 'db_panel',
        'user' => 'admin',
        'pass' => '0987654321'
    ];
    
    $conn = mysqli_connect($db_config['host'], $db_config['user'], $db_config['pass'], $db_config['name']);
        
    if (!$conn) { die('Connection Failed! : ' . mysqli_connect_error()); }
    mysqli_set_charset($conn, "utf8mb4");
    
    $db_panel = $conn->query("SELECT * FROM data_panel");
    if ($db_panel->num_rows > 0) {
        $dataPanel = $db_panel->fetch_assoc();
        $title_panel = $dataPanel['title'];
        $host_panel = $dataPanel['domain'];
        $icon_panel = $dataPanel['icon'];
        $path_panel = $dataPanel['path_panel'];
        $desc_panel = $dataPanel['description'];
        $host_server = trim(shell_exec('hostname'));
        $port_panel = 8080;
        $port_panel_ssl = 8443;
    } else { die(' Data Panel Not Found! '); }
?>