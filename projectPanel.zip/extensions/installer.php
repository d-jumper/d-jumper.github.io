<?php
/*
function checkUrl($url) {
    $headers = @get_headers($url);
    if ($headers && strpos($headers[0], '200') !== false) {
        return true;
    }
    return false;
}
function checkIcon($keyword) {
    $icon = strtolower(trim($keyword));
    $icon = str_replace(' ', '', $icon);
    $devIconBase = "https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/";
    $src = $devIconBase . $icon . "/" . $icon . "-original.svg";
    if (!checkUrl($src)) {
        $src = "https://simpleicons.org/icons/" . $icon . ".svg";
    }
    return $src;
}
if (isset($_GET['check_icon'])) {
    header('Content-Type: application/json');
    $keyword = $_GET['keyword'] ?? '';
    $iconUrl = checkIcon($keyword);
    if ($iconUrl) {
        echo json_encode(['exists' => true, 'url' => $iconUrl]);
    } else {
        echo json_encode(['exists' => false, 'url' => '']);
    }
    exit;
}

?>

<div class="container mt-4 pb-5">
    <div class="card p-3 mb-3 border-0 shadow-sm position-relative">
        <h6 class="mb-1 fw-bold text-dark">Get Icon</h6>
        
        <div id="div-image-icon" class="mb-2 text-center" style="min-height: 50px;">
            <p class="text-muted small">Type keyword to see icon...</p>
        </div>

        <form method="POST" class="mb-3" onsubmit="return false;">
            <input type="text" 
                   name="icon_keyword"  
                   id="input-image-icon"
                   class="form-control border-0 bg-light-subtle shadow-none" 
                   placeholder="e.g. nodejs, python, react..."
                   onkeyup="checkIconRealTime()"
                   style="font-size: 0.75rem; font-family: 'Courier New', monospace; border-left: 4px solid #ccc;">
        </form>
    </div>
</div>

<script>
let typingTimer;
const doneTypingInterval = 800;
function checkIconRealTime() {
    clearTimeout(typingTimer);
    const inputEl = document.getElementById('input-image-icon');
    const divIcon = document.getElementById('div-image-icon');
    const keyword = inputEl.value.trim().toLowerCase();
    if (!keyword) {
        divIcon.innerHTML = '<p class="text-muted small">Type keyword...</p>';
        inputEl.style.borderLeft = "4px solid #ccc";
        return;
    }
    typingTimer = setTimeout(() => {
        divIcon.innerHTML = '<div class="spinner-border spinner-border-sm text-secondary" role="status"></div>';
        fetch(`?check_icon=1&keyword=${encodeURIComponent(keyword)}`)
            .then(r => {
                if (!r.ok) {
                    throw new Error(`HTTP error! status: ${r.status}`);
                }
                return r.json();
            })
            .then(data => {
                if (data.exists && data.url) {
                    inputEl.style.borderLeft = "4px solid #198754"; // Hijau jika ketemu
                    divIcon.innerHTML = `
                        <img src="${data.url}" 
                             width="15" 
                             height="15" 
                             class="me-1" 
                             alt="icon"">
                    `;
                } else {
                    inputEl.style.borderLeft = "4px solid #dc3545"; // Merah jika gagal
                    divIcon.innerHTML = '<p class="text-danger small">Icon not found</p>';
                }
            })
            .catch(err => {
                console.error("Detail Error:", err);
                divIcon.innerHTML = `<p class="text-danger small">Error: ${err.message}</p>`;
                inputEl.style.borderLeft = "4px solid #dc3545";
            });
    }, doneTypingInterval);
}
</script>

buatkan fitur "PHP Extension Selector" sebelum menginstall php baru sehingga user bisa mencentang module secara dinamis dari modal
*/

/**
 * AUTHENTICATION & ROUTING
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}
if ($_SESSION['role'] === 'user') {
    $page = 'domains';
} else if($_SESSION['role'] !== 'admin') {
    $msg = "Access+denied!";
    echo "<script>window.location.href='?status=danger&msg=$msg';</script>";
}

/**
 * PARAMETER
 */
$keyword_package = $_GET['package'] ?? '';
$title_package = $_GET['title'] ?? '';
$base_page = $_GET['page'] ?? '';
$base_subpage = $_GET['subpage'] ?? '';
$base_param = "page=$base_page&subpage=$base_subpage&package=$keyword_package&title=$title_package";
$current_url = "?$base_param";
$back_button = "?page=extensions";

// --- HANDLER: START ACTION (Install/Uninstall) ---
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    $pkg = $_GET['pkg'] ?? 'unknown';
    $action = $_GET['action']; 
    
    $logFileName = "ext_{$user_target}_{$pkg}.log";
    $logFile = "/tmp/" . $logFileName;
    
    // Inisialisasi file log (Clear previous log)
    file_put_contents($logFile, "=== Memulai Sesi $action untuk $pkg ===\n");
    chmod($logFile, 0666);

    // Command Logic
    if ($action === 'install') {
        $cmd = "
            echo > $logFile 2>&1;
            echo '[10%] Menghubungi repository...' >> $logFile;
            sudo apt update >> $logFile 2>&1;
            if [ $? -eq 0 ]; then
                echo '[60%] Sinkronisasi paket selesai...' >> $logFile;
                sleep 2;
                echo '[100%] SUCCESS: Instalasi $pkg selesai.' >> $logFile;
            else
                echo '[100%] ERROR: Gagal menjalankan apt update. Periksa izin sudo.' >> $logFile;
            fi
        ";
    } else {
        $cmd = "
            echo > $logFile 2>&1;
            echo '[20%] Menghapus modul $pkg...' >> $logFile;
            sudo apt update >> $logFile 2>&1;
            sleep 1;
            echo '[100%] SUCCESS: $pkg telah dihapus.' >> $logFile;
        ";
    }

    // Jalankan di background tanpa menunggu
    shell_exec("nohup bash -c " . escapeshellarg($cmd) . " > /dev/null 2>&1 &");

    echo json_encode(['status' => 'started', 'log_ref' => $logFileName]);
    exit;
}

// --- HANDLER: UPDATE DATABASE ---
if (isset($_GET['update_db'])) {
    header('Content-Type: application/json');
    
    $pkg = $_GET['pkg'] ?? '';
    $status = $_GET['status'] ?? 'false';
    require_once("../config.php");
    $stmt = $conn->prepare("UPDATE extensions SET is_installed = ? WHERE package = ?");
    $stmt->bind_param("ss", $status, $pkg);
    $success = $stmt->execute();
    
    echo json_encode(['success' => $success, 'package' => $pkg, 'new_status' => $status]);
    exit;
}

// Handler untuk membaca log (Polling)
if (isset($_GET['read_log'])) {
    $file = "/tmp/" . preg_replace('/[^a-z0-9_.]/', '', $_GET['read_log']);
    if (file_exists($file)) {
        $content = file_get_contents($file);
        echo json_encode(['content' => $content]);
    } else {
        echo json_encode(['content' => 'Waiting for log...']);
    }
    exit;
}

function getDescription($keyword) {
    $keyword = urlencode(trim($keyword));
    // Query Wikipedia untuk mengambil extract (teks) dan infobox (untuk data versi)
    $url = "https://en.wikipedia.org/w/api.php?format=json&action=query&prop=extracts|revisions&exintro&explaintext&redirects=1&titles={$keyword}&rvprop=content&rvsection=0";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERAGENT, "MyIconPanel/1.0");
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);
    $description = "No description available.";
    $version = "Unknown";

    if (isset($data['query']['pages'])) {
        $page = reset($data['query']['pages']);
        
        // 1. Ambil Deskripsi Fungsi
        if (isset($page['extract'])) {
            $description = $page['extract'];
        }

        // 2. Ambil Versi (Mencari pola 'stable_release' dalam konten mentah)
        if (isset($page['revisions'][0]['*'])) {
            $content = $page['revisions'][0]['*'];
            // Regex sederhana untuk mencari versi di dalam infobox Wikipedia
            if (preg_match('/latest[_ ]release[_ ]version\s*=\s*([^|\n}]+)/i', $content, $matches)) {
                $version = trim(strip_tags($matches[1]));
            }
        }
    }

    return [
        'text' => $description,
        'version' => $version
    ];
}

function urlExistsss($url) {
    $headers = @get_headers($url);
    if ($headers && strpos($headers[0], '200') !== false) {
        return true;
    }
    return false;
}
function srcIconnn($keyword) {
    $icon = strtolower(trim($keyword));
    $icon = str_replace(' ', '', $icon);
    $devIconBase = "https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/";
    $src = $devIconBase . $icon . "/" . $icon . "-original.svg";
    if (!urlExistsss($src)) {
        $src = "https://simpleicons.org/icons/" . $icon . ".svg";
    }
    return $src;
}

// Update API Handler
if (isset($_GET['get_icon'])) {
    header('Content-Type: application/json');
    $keyword = $_GET['keyword'] ?? '';
    
    $iconUrl = srcIconnn($keyword);
    $descData = getDescription($keyword); 

    echo json_encode([
        'exists' => (bool)$iconUrl,
        'url' => $iconUrl,
        'description' => $descData['text'],
        'version' => $descData['version']
    ]);
    exit;
}

$package_ext = $keyword_package;
$title_ext = $title_package;
$dataExt = $conn->query("SELECT * FROM extensions WHERE package = '$keyword_package' AND title = '$title_package'");
if($dataExt && $ext = $dataExt->fetch_assoc()){
    $package_ext = $ext['package'];
    $title_ext = $ext['title'];
} else {
    $msg = "Extension+not+found!";
    echo "<script>window.location.href='$back_button&status=danger&msg=$msg';</script>";
    exit();
}

?>

<div class="container mt-4 pb-5">
        
    <div class="plesk-card-header p-3 border-bottom d-flex justify-content-between align-items-center">
        <button id="btn-install"
            data-package="<?= $ext['package'] ?>" 
            data-installed="<?= $ext['is_installed'] ?>"
            class="btn btn-sm <?= $ext['is_installed'] === 'true' ? 'btn-outline-danger' : 'btn-outline-primary' ?> rounded-pill px-3 shadow-sm">
            <i class="bi bi-<?= $ext['is_installed'] === 'true' ? 'x-circle-fill' : 'plus-circle' ?> me-1"></i> 
            <span><?= $ext['is_installed'] === 'true' ? 'Uninstall' : 'Install' ?></span>
        </button>
        <div class="d-flex gap-2">
            <a href="<?= $back_button ?>" class="btn btn-white border shadow-sm rounded-3 px-3">
                <img src="pma/themes/bootstrap/img/b_left.png" width="20" class="me-1"></img> Back
            </a>
        </div>
    </div>
    
    <div id="global_log_container" class="mt-4 d-none">
        <div class="card border-0 shadow-sm bg-dark text-white">
            <div class="card-header border-secondary d-flex justify-content-between align-items-center">
                <small id="log_title" class="fw-bold text-info">System Installer Log</small>
                <span id="log_perc" class="badge bg-primary">0%</span>
            </div>
            <div class="card-body p-0">
                <div class="progress rounded-0" style="height: 4px;">
                    <div id="log_bar" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
                </div>
                <pre id="global_log_area" class="m-0 p-3 text-success" style="height: 250px; overflow-y: auto; font-size: 11px; font-family: monospace; background: #000;"></pre>
            </div>
        </div>
    </div>
    
    <div class="card p-3 mb-3 border-0 shadow-sm">
        <h6 class="mb-1 fw-bold text-dark"><?php echo $title_package; ?></h6>
        
        <div id="preview-container" class="mb-2 text-center p-3" style="min-height: 120px; background: #fdfdfd; border-radius: 8px; border: 1px solid #eee;">
            <div id="div-image-icon" class="position-relative"></div>
            <div id="div-version" class="mt-1"></div>
            <div id="div-description" class="mt-2 text-muted" style="font-size: 0.75rem; line-height: 1.5; text-align: justify;"></div>
        </div>

        <form method="POST" onsubmit="return false;">
            <input type="hidden" value="<?php echo $keyword_package; ?>" id="input-image-icon">
        </form>
    </div>
    
</div>

<script>
let typingTimer;
const doneTypingInterval = 800;

document.addEventListener('DOMContentLoaded', function() {
    checkFileRealtime(); 
});

function checkFileRealtime() {
    clearTimeout(typingTimer);
    const inputEl = document.getElementById('input-image-icon');
    const divIcon = document.getElementById('div-image-icon');
    const divDesc = document.getElementById('div-description');
    const divVersion = document.getElementById('div-version');
    
    if (!inputEl) return;
    const keyword = inputEl.value.trim();
    if (!keyword) {
        divIcon.innerHTML = '<p class="text-muted small">Icon Preview</p>';
        divDesc.innerText = 'Type a technology keyword...';
        divVersion.innerHTML = '';
        inputEl.style.borderLeft = "4px solid #ccc";
        return;
    }

    divIcon.innerHTML = '<div class="spinner-border spinner-border-sm text-secondary"></div>';
    typingTimer = setTimeout(() => {
        fetch(`extensions/installer.php?get_icon=1&keyword=${encodeURIComponent(keyword)}`)
            .then(r => {
                if (!r.ok) throw new Error("Network response was not ok");
                return r.json();
            })
            .then(data => {
                if (data.exists && data.url) {
                    divIcon.innerHTML = `<img src="${data.url}" width="50" class="img-fluid mb-2 animate__animated animate__fadeIn">`;
                    inputEl.style.borderLeft = "4px solid #198754";
                } else {
                    divIcon.innerHTML = '<p class="text-danger small">Icon not found</p>';
                    inputEl.style.borderLeft = "4px solid #dc3545";
                }
            
                if (data.version && data.version !== "Unknown") {
                    divVersion.innerHTML = `<span class="badge rounded-pill bg-dark" style="font-size: 0.6rem;">Stable: ${data.version}</span>`;
                } else {
                    divVersion.innerHTML = '';
                }
            
                divDesc.innerText = data.description || "No description available.";
            })
            .catch(err => {
                console.error("Fetch error:", err);
                divIcon.innerHTML = '<p class="text-danger small">Error connection</p>';
            });
    }, doneTypingInterval);
}
document.getElementById('btn-install').addEventListener('click', function() {
    const btn = this;
    const pkg = btn.getAttribute('data-package');
    const isInstalled = btn.getAttribute('data-installed') === 'true';
    const action = isInstalled ? 'uninstall' : 'install';
    if (!confirm(`Apakah Anda yakin ingin ${action} ${pkg}?`)) return;
    btn.disabled = true;
    const container = document.getElementById('global_log_container');
    const logArea = document.getElementById('global_log_area');
    const progressBar = document.getElementById('log_bar');
    const percText = document.getElementById('log_perc');
    
    container.classList.remove('d-none');
    logArea.innerHTML = "Initializing command...\n";
    fetch(`extensions/installer.php?action=${action}&pkg=${pkg}`)
        .then(r => r.json())
        .then(data => {
            if (data.status === 'started') {
                const pollInterval = setInterval(() => {
                    fetch(`extensions/get_install_log.php?log_ref=${data.log_ref}`)
                        .then(r => r.json())
                        .then(logData => {
                            logArea.textContent = logData.content;
                            logArea.scrollTop = logArea.scrollHeight;
                            const match = logData.content.match(/\[(\d+)%\]/g);
                            if (match) {
                                const lastMatch = match[match.length - 1];
                                const percent = lastMatch.match(/\d+/)[0];
                                progressBar.style.width = percent + '%';
                                percText.innerText = percent + '%';
                                if (parseInt(percent) >= 100) {
                                    clearInterval(pollInterval);
                                    finishProcess(btn, action, pkg);
                                }
                            }
                            if (logData.content.includes('ERROR')) {
                                clearInterval(pollInterval);
                                progressBar.classList.add('bg-danger');
                                btn.disabled = false;
                            }
                        });
                }, 1000);
            }
        });
});
function finishProcess(btn, action, pkg) {
    const newStatus = (action === 'uninstall') ? 'false' : 'true';
    
    fetch(`extensions/installer.php?update_db=1&pkg=${encodeURIComponent(pkg)}&status=${newStatus}`)
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            btn.disabled = false;
            btn.setAttribute('data-installed', newStatus);
            
            if (newStatus === 'true') {
                btn.className = 'btn btn-sm btn-outline-danger rounded-pill px-3 shadow-sm';
                btn.querySelector('span').innerText = 'Uninstall';
                btn.querySelector('i').className = 'bi bi-x-circle-fill me-1';
            } else if (newStatus === 'false') {
                btn.className = 'btn btn-sm btn-outline-primary rounded-pill px-3 shadow-sm';
                btn.querySelector('span').innerText = 'Install';
                btn.querySelector('i').className = 'bi bi-plus-circle me-1';
            }
            
            //console.log(`Database updated: ${pkg} is now ${newStatus}`);
        } else {
            //console.error("Database update failed server-side");
            btn.disabled = false;
        }
    })
    .catch(err => {
        //console.error("AJAX Error:", err);
        btn.disabled = false;
    });
}

function clearLog() {
    document.getElementById('log-box').innerHTML = '<div class="text-secondary small">-- Log cleared --</div>';
}
</script>
