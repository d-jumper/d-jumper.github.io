<?php
ob_start();
session_start();
require_once('config.php');

// --- START: FIX AJAX CLEANER ---
if (isset($_POST['installnodejs']) || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest')) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    header('Content-Type: application/json; charset=utf-8');
    try {
        $base_nvm = "/var/www/.nvm"; 
        if (!is_dir($base_nvm)) { 
            mkdir($base_nvm, 0775, true); 
            chmod($base_nvm, 0775); 
        }
        $v_to_inst = (int)$_POST['install_version'];
        $log_file = "/tmp/node_inst.log";
        $safe_log = escapeshellarg($log_file);
        shell_exec("sudo touch $safe_log && sudo chmod 666 $safe_log");
        file_put_contents($log_file, "Persiapan instalasi Node.js v$v_to_inst...\n");
        $cmd = " (
            export NVM_DIR=$base_nvm && \
            curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash && \
            [ -s \"\$NVM_DIR/nvm.sh\" ] && \. \"\$NVM_DIR/nvm.sh\" && \
            nvm install $v_to_inst && \
            echo \"INSTALLATION_COMPLETED_SUCCESSFULLY\"
        ) > $safe_log 2>&1 &";
        shell_exec($cmd);
        echo json_encode(['status' => 'success', 'message' => 'Proses dimulai']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}
// --- END: FIX AJAX CLEANER ---

// --- LOGIKA PESAN NOTIFIKASI ---
$msg = "";
$status_url = $_GET['status'] ?? '';
$msg_text = $_GET['msg'] ?? '';
$alert_type = (strpos($status_url, 'success') !== false) ? 'success' : 'danger';

/**
 * 1. AUTHENTICATION & ROUTING
 */
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'root') {
    // Fallback logic
    $_SESSION['user'] = 'admin';
    $_SESSION['role'] = 'root';
}

// LOGIKA API UNTUK REAL-TIME MONITORING
if (isset($_GET['get_stats'])) {
    header('Content-Type: application/json');
    $load = sys_getloadavg();
    $cpu = ($load[0] * 10 > 100) ? 100 : $load[0] * 10;
    
    $free = shell_exec('free -m');
    $memory_perc = 0; $mem_used = 0; $mem_total = 0;
    
    if ($free) {
        $lines = explode("\n", trim($free));
        $mem = preg_split('/\s+/', $lines[1]);
        $mem_total = $mem[1] ?? 0;
        $mem_used = $mem[2] ?? 0;
        $memory_perc = $mem_total > 0 ? ($mem_used / $mem_total) * 100 : 0;
    }
    
    $disk_total = disk_total_space("/");
    $disk_free = disk_free_space("/");
    $disk_perc = (($disk_total - $disk_free) / $disk_total) * 100;

    echo json_encode([
        'cpu' => round($cpu, 1),
        'mem_perc' => round($memory_perc, 1),
        'mem_used' => round($mem_used / 1024, 2),
        'mem_total' => round($mem_total / 1024, 2),
        'disk_perc' => round($disk_perc, 1),
        'disk_used' => round(($disk_total - $disk_free) / (1024**3), 2),
        'disk_total' => round($disk_total / (1024**3), 2),
        'uptime' => trim(shell_exec("uptime -p") ?? "N/A")
    ]);
    exit();
}

$page = isset($_GET['page']) ? $_GET['page'] : 'home';
$msg = "";

// --- LOGIKA PROVISIONING ---
if (isset($_POST['add_user'])) {
    try {
        $new_user = preg_replace('/[^a-z0-9]/', '', strtolower($_POST['username']));
        $type = $_POST['domain_type'];
        $pwd = $_POST['password']; 
        $pwd_hash = password_hash($pwd, PASSWORD_DEFAULT);
        
        // --- LOGIKA PENENTUAN DOMAIN ---
        if ($type === 'main') {
            $domain_user = $host_server;
        } elseif ($type === 'subdomain') {
            $prefix = preg_replace('/[^a-z0-9-]/', '', strtolower($_POST['sub_prefix']));
            if(empty($prefix)) throw new Exception("Prefix subdomain tidak boleh kosong.");
            $domain_user = $prefix . "." . $host_server;
        } elseif ($type === 'custom') {
            $domain_user = preg_replace('/[^a-z0-9.-]/', '', strtolower($_POST['custom_domain']));
            if(empty($domain_user)) throw new Exception("Nama domain custom tidak boleh kosong.");
        }

        $db_name = "db_" . $new_user;
        
        // --- VALIDASI DOUBLE DOMAIN ATAU USER (PENTING) ---
        $check = $conn->prepare("SELECT id FROM db_users WHERE username = ? OR domain = ?");
        $check->bind_param("ss", $new_user, $domain_user);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            throw new Exception("Username atau Domain sudah terdaftar di sistem!");
        }

        // Simpan ke Database Panel
        $stmt = $conn->prepare("INSERT INTO db_users (username, db, pwdb, domain, role) VALUES (?, ?, ?, ?, 'user')");
        $stmt->bind_param("ssss", $new_user, $db_name, $pwd_hash, $domain_user);
        $stmt->execute();

        // 1. Database Provisioning (MySQL)
        $conn->query("CREATE DATABASE IF NOT EXISTS `$db_name` ");
        $conn->query("CREATE USER IF NOT EXISTS '$db_name'@'localhost' IDENTIFIED BY '$pwd'");
        $conn->query("GRANT ALL PRIVILEGES ON `$db_name`.* TO '$db_name'@'localhost'");
        $conn->query("FLUSH PRIVILEGES");

        // 2. Folder & Permission Provisioning
        $path_user = "/var/www/html/$new_user/httpdocs";
        shell_exec("sudo useradd -p $(openssl passwd -1 $pwd) $path_user");
        shell_exec("sudo mkdir -p $path_user");
        shell_exec("sudo chown -R $new_user:$new_user $path_user");
        
        $html = "<h1>Website $domain_user Aktif!</h1><p>Database: db_$new_user</p>";
        file_put_contents("/tmp/index.php", $html);
        shell_exec("sudo mv /tmp/index.php $path_user/index.php");

        if (!file_exists($path_user . "/index.php")) {
            file_put_contents("/tmp/index_tmp", "<?php echo '<h1>Welcome to $domain_user</h1>'; ?>");
            shell_exec("sudo mv /tmp/index_tmp $path_user/index.php");
            shell_exec("sudo chown $new_user:$new_user $path_user/index.php");
        }

            // 3. APACHE VIRTUALHOST
        $vhost = "<VirtualHost *:$port_panel>
                    ServerName $domain_user
                    DocumentRoot $path_user
                    <Directory $path_user>
                        AllowOverride All
                        Require all granted
                    </Directory>
                </VirtualHost>";
        file_put_contents("/tmp/$domain_user.conf", $vhost);
        shell_exec("sudo mv /tmp/$domain_user.conf /etc/apache2/sites-available/");
        shell_exec("sudo a2ensite $domain_user.conf");
        shell_exec("sudo service apache2 reload");

        $msg = "success|Website dan Database <b>$db_name</b> berhasil dibuat!";
    } catch (Exception $e) { 
        $msg = "danger|" . $e->getMessage(); 
    }
}

// --- LOGIKA DELETE ---
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("SELECT db, username, domain FROM db_users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if($u = $res->fetch_assoc()) {
        $db_name = $u['db'];
        $domain_user = $u['domain'];
        $new_user = $u['username'];
        $path_user = "/var/www/html/$new_user";
        
        $conn->query("DROP DATABASE IF EXISTS `$db_name` ");
        $conn->query("DROP USER IF EXISTS '$db_name'@'localhost'");
        
        shell_exec("sudo a2dissite $domain_user.conf");
        shell_exec("sudo rm /etc/apache2/sites-available/$domain_user.conf");
        shell_exec("sudo rm -rf $path_user");
        shell_exec("sudo systemctl reload apache2");

        $del_stmt = $conn->prepare("DELETE FROM db_users WHERE id = ?");
        $del_stmt->bind_param("i", $id);
        $del_stmt->execute();
        
        header("Location: ?page=domains&res=deleted"); 
        exit();
    }
}

$list_users = $conn->query("SELECT * FROM db_users WHERE role = 'user' ORDER BY id DESC");

require_once("lib/header.php");
?>
        
    <?php if($msg): $m = explode('|', $msg); ?>
        <div class="alert alert-<?php echo $m[0]; ?> alert-dismissible fade show" role="alert">
            <?php echo $m[1]; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold m-0 text-dark">
            <i class="bi bi-speedometer2 me-2"></i>
            <?php 
                if($page == 'home') echo 'Dashboard Overview';
                elseif($page == 'manage') echo 'Manage Subscription';
                elseif($page == 'installer') echo 'Installer Manager';
                else echo 'Domains List'; 
            ?>
        </h4>
        <div class="small text-muted"><i class="bi bi-clock me-1"></i> <?php echo date('d M Y, H:i'); ?></div>
    </div>

    <?php if($status_url): ?>
        <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
            <div class="d-flex align-items-center">
                <i class="bi <?php echo ($alert_type == 'success') ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'; ?> me-2 fs-5"></i>
                <div>
                    <strong><?php echo ($alert_type == 'success') ? 'Berhasil!' : 'Terjadi Kesalahan!'; ?></strong> 
                    <span class="ms-1"><?php echo htmlspecialchars(str_replace('+', ' ', $msg_text)); ?></span>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php switch($page) { 
        case 'home': ?>
            <div class="row g-4">
                <div class="col-md-8">
                    <div class="plesk-card mb-4">
                        <div class="plesk-card-header">System Information</div>
                        <div class="p-4">
                            <div class="row g-4 text-center">
                                <div class="col-6 col-sm-3 border-end">
                                    <div class="small text-muted">Hostname</div><div class="fw-bold text-truncate"><?php echo gethostname(); ?></div>
                                </div>
                                <div class="col-6 col-sm-3 border-end">
                                    <div class="small text-muted">IP Address</div><div class="fw-bold"><?php echo $_SERVER['SERVER_ADDR'] ?? '127.0.0.1'; ?></div>
                                </div>
                                <div class="col-6 col-sm-3 border-end">
                                    <div class="small text-muted">Uptime</div><div id="uptime-val" class="fw-bold text-primary">...</div>
                                </div>
                                <div class="col-6 col-sm-3">
                                    <div class="small text-muted">Active Users</div><div class="fw-bold"><?php echo $list_users->num_rows; ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="plesk-card">
                        <div class="plesk-card-header">Real-time Resource Usage</div>
                        <div class="p-4">
                            <div class="mb-4">
                                <div class="d-flex justify-content-between mb-1">
                                    <label class="small fw-bold">CPU Usage</label>
                                    <span id="cpu-text" class="small">0%</span>
                                </div>
                                <div class="progress" style="height: 8px;"><div id="cpu-bar" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div></div>
                            </div>
                            <div class="mb-2">
                                <div class="d-flex justify-content-between mb-1">
                                    <label class="small fw-bold">RAM Usage</label>
                                    <span id="mem-text" class="small">0/0 GB</span>
                                </div>
                                <div class="progress" style="height: 8px;"><div id="mem-bar" class="progress-bar bg-success" style="width: 0%"></div></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="plesk-card text-center p-4 h-100 d-flex flex-column justify-content-center">
                        <i class="bi bi-cpu display-4 text-primary mb-3"></i>
                        <h5>Server Node 01</h5>
                        <p class="text-muted small">Status: <span class="badge bg-success">Online</span></p>
                        <hr>
                        <div class="d-grid gap-2">
                            <a href="?page=domains" class="btn btn-primary btn-sm">Manage Domains</a>
                            <button class="btn btn-outline-secondary btn-sm" onclick="location.reload()">Refresh Data</button>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                function updateStats() {
                    fetch('?get_stats=1').then(r => r.json()).then(data => {
                        document.getElementById('cpu-bar').style.width = data.cpu + '%';
                        document.getElementById('cpu-text').innerText = data.cpu + '%';
                        document.getElementById('mem-bar').style.width = data.mem_perc + '%';
                        document.getElementById('mem-text').innerText = data.mem_used + ' / ' + data.mem_total + ' GB';
                        document.getElementById('uptime-val').innerText = data.uptime;
                    });
                }
                setInterval(updateStats, 3000); updateStats();
            </script>
        <?php break;

        case 'domains': ?>
            <div class="mb-4 text-end">
                <button class="btn btn-primary px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#addModal">
                    <i class="bi bi-plus-lg me-1"></i> Add Subscription
                </button>
            </div>
            <div class="plesk-card shadow-sm">
                <div class="plesk-card-header">Active Subscriptions</div>
                <div class="p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Subscriber</th>
                                    <th>Primary Domain</th>
                                    <th>Database</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($list_users->num_rows > 0): while($u = $list_users->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-soft-primary p-2 me-3 text-primary">
                                                <i class="bi bi-person-fill"></i>
                                            </div>
                                            <div>
                                                <div class="fw-bold"><?php echo $u['username']; ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><a href="http://<?php echo $u['domain']; ?>:<?php echo $port_panel; ?>" target="_blank" class="text-decoration-none"><i class="bi bi-link-45deg"></i> <?php echo $u['domain']; ?></a></td>
                                    <td><code class="text-dark bg-light px-2 py-1 rounded"><?php echo $u['db']; ?></code></td>
                                    <td class="text-center">
                                        <a href="?page=manage&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-primary me-1">
                                            <i class="bi bi-gear-fill"></i>
                                        </a>
                                        <a href="?delete=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus data website?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; else: ?>
                                <tr><td colspan="4" class="text-center py-5 text-muted">Belum ada langganan yang aktif.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php break; 

        case 'installer': ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold text-primary"><i class="bi bi-node-plus"></i></h4>
                <a href="?page=manage&id=<?php echo $id ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
            
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-header bg-white fw-bold"><i class="bi bi-download"></i> Install Node.js</div>
                        <div class="card-body">
                            <form id="installForm">
                                <label class="small text-muted mb-2">Versi Node (Contoh: 20)</label>
                                <div class="input-group">
                                    <input type="number" name="install_version" id="install_version" class="form-control" placeholder="Versi" required>
                                    <button type="submit" name="installnodejs" class="btn btn-primary">Install</button>
                                </div>
                                <div class="form-text mt-2 small">Menggunakan NVM untuk instalasi sistem.</div>
                                
                                <div id="prog_box_global_node" class="mt-4 d-none">
                                    <div class="d-flex justify-content-between mb-1 small">
                                        <span id="npm_stat_global_node" class="text-muted">Menghubungkan...</span>
                                        <span id="npm_perc_global_node" class="fw-bold text-primary">0%</span>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <div id="npm_bar_global_node" class="progress-bar progress-bar-striped progress-bar-animated bg-primary" style="width: 0%"></div>
                                    </div>
                                    <pre id="node-install-log" class="bg-black text-success p-2 mt-2 rounded border" style="max-height: 100px; overflow-y: auto; font-size: 10px; font-family: monospace;"></pre>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>

        <?php break; 
        
        case 'manage': 
                // Panggil file yang baru dibuat
                include('user/manage-user.php');
                break;
            }
?>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content border-0 shadow text-dark">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold">Provision New Website</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small">System Username</label>
                    <input type="text" name="username" class="form-control" placeholder="userweb01" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Domain Type</label>
                    <select name="domain_type" id="domain_type_select" class="form-select" onchange="toggleDomainInputs(this.value)">
                        <option value="main">Main Domain (<?php echo $host_server; ?>)</option>
                        <option value="subdomain">Subdomain (prefix.<?php echo $host_server; ?>)</option>
                        <option value="custom">Custom / Own Domain</option>
                    </select>
                </div>

                <div id="input_subdomain" class="mb-3 d-none">
                    <label class="form-label fw-bold small">Subdomain Prefix</label>
                    <div class="input-group">
                        <input type="text" name="sub_prefix" class="form-control" placeholder="mywebsite">
                        <span class="input-group-text">.<?php echo $host_server; ?></span>
                    </div>
                </div>

                <div id="input_custom" class="mb-3 d-none">
                    <label class="form-label fw-bold small">Custom Domain Name</label>
                    <input type="text" name="custom_domain" class="form-control" placeholder="example.com">
                    <div class="form-text text-danger small">Pastikan DNS A Record mengarah ke IP ini.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">Password Account & DB</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="submit" name="add_user" class="btn btn-primary w-100 fw-bold">Deploy Website Now</button>
            </div>
        </form>
    </div>
</div>

<script>
function trackNodeInstallation(userTarget) {
    const vInput = document.getElementById('install_version');
    const v = vInput.value;
    
    // Elemen UI sesuai dengan ID di Dashboard
    const progBox = document.getElementById('prog_box_global_node');
    const bar = document.getElementById('npm_bar_global_node');
    const perc = document.getElementById('npm_perc_global_node');
    const stat = document.getElementById('npm_stat_global_node');
    const out = document.getElementById('node-install-log');

    // Setup Awal Tampilan
    progBox.classList.remove('d-none');
    bar.style.width = '5%';
    bar.className = "progress-bar progress-bar-striped progress-bar-animated bg-primary";
    perc.innerText = '5%';
    stat.innerText = 'Menginstal Node.js v' + v;
    out.innerText = "Menghubungkan ke server...";

    let lastLog = "";
    
    // Interval pemantauan log
    const interval = setInterval(() => {
        // Mengarah ke file log /tmp/node_inst.log
        fetch(`node-manager/get_install_log.php?t=${Date.now()}`)
        .then(r => r.text())
        .then(data => {
            if (!data.trim() || data === lastLog) return;
            lastLog = data;
            
            // Tampilkan log di area pre
            out.innerText = data;
            out.scrollTop = out.scrollHeight;

            // Logika Progress Kalkulasi (Mirip npmAction)
            const getCount = (data.match(/Get:/g) || []).length;
            const extractCount = (data.match(/Unpacking/g) || []).length;
            let p = Math.min(95, 5 + (getCount * 10) + (extractCount * 5));
            
            bar.style.width = p + '%';
            perc.innerText = p + '%';

            // Logika Deteksi Selesai (NodeSource / APT)
            const isDone = data.includes('Processing triggers') || 
                           data.includes('INSTALLATION_COMPLETED_SUCCESSFULLY') ||
                           data.includes('Setting up nodejs');
                           
            const isError = data.includes('E: Unable to locate package') || 
                            data.includes('ERROR:') || 
                            data.includes('E: ');

            if (isDone || isError) {
                clearInterval(interval);
                bar.style.width = '100%';
                perc.innerText = '100%';
                stat.innerText = isError ? 'Error Instalasi!' : 'Instalasi Selesai!';
                
                bar.classList.remove('progress-bar-animated');
                bar.classList.replace('bg-primary', isError ? 'bg-danger' : 'bg-success');
                
                // Opsional: Kosongkan input versi
                vInput.value = "";

            }
        });
    }, 1500);
}

document.getElementById('installForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const v = document.getElementById('install_version').value;
    const btn = this.querySelector('button');
    btn.disabled = true;

    const fd = new FormData();
    fd.append('installnodejs', '1');
    fd.append('install_version', v);

    const targetUrl = window.location.origin + window.location.pathname + window.location.search.split('&status')[0];
    
    fetch(targetUrl, { 
        method: 'POST', 
        body: fd,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(async response => {
        const text = await response.text(); // Ambil teks mentah dulu
        try {
            return JSON.parse(text); // Coba parsing manual
        } catch (e) {
            console.error("Server mengembalikan bukan JSON:", text);
            throw new Error("Server Error: Output tidak valid.");
        }
    })
    .then(res => {
        if(res.status === 'success') trackNodeInstallation('<?= $user_target ?>');
    })
});
</script>

<script>
function toggleDomainInputs(val) {
    document.getElementById('input_subdomain').classList.add('d-none');
    document.getElementById('input_custom').classList.add('d-none');
    
    if (val === 'subdomain') {
        document.getElementById('input_subdomain').classList.remove('d-none');
    } else if (val === 'custom') {
        document.getElementById('input_custom').classList.remove('d-none');
    }
}
</script>

<style>
    .bg-soft-primary { background-color: rgba(13, 110, 253, 0.1); }
    .action-box { 
        border: 1px solid #e1e4e8; border-radius: 8px; padding: 20px 10px; 
        text-align: center; transition: all 0.2s; cursor: pointer; 
        text-decoration: none; color: #333; display: block; background: #fff;
    }
    .action-box:hover { background: #f0f7ff; border-color: #0d6efd; transform: translateY(-3px); color: #0d6efd; }
    .plesk-card { background: #fff; border: 1px solid #e1e4e8; border-radius: 6px; margin-bottom: 1.5rem; overflow: hidden; }
    .plesk-card-header { background: #f8f9fa; padding: 12px 20px; border-bottom: 1px solid #e1e4e8; font-weight: bold; }
</style>

<?php
require_once("lib/footer.php");
?>