<?php
/**
 * Log Reader Utility
 * Path: extensions/get_install_log.php
 */

header('Content-Type: application/json');

if (isset($_GET['log_ref'])) {
    // Sanitasi input untuk mencegah Directory Traversal
    $log_ref = preg_replace('/[^a-z0-9_.]/', '', $_GET['log_ref']);
    $file = "/tmp/" . $log_ref;

    if (file_exists($file)) {
        // Membaca file log
        $content = file_get_contents($file);
        
        // Kirimkan response
        echo json_encode([
            'status' => 'success',
            'content' => $content,
            'size' => filesize($file),
            'last_updated' => date("H:i:s", filemtime($file))
        ]);
    } else {
        echo json_encode([
            'status' => 'waiting',
            'content' => '[SYSTEM] Menunggu output dari installer...'
        ]);
    }
} else {
    echo json_encode(['status' => 'error', 'content' => 'No log reference provided.']);
}
exit;