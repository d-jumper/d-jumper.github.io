<?php
session_start();
require_once('config.php'); 

if (isset($_SESSION['user']) && $_SESSION['role'] == 'root') {
    header("Location: dashboard.php");
    exit();
}
$msg = "";
$msg_type = "danger";

$is_root_exists = false;
$check_root = $conn->query("SELECT id FROM admin WHERE role='root' LIMIT 1");
if ($check_root && $check_root->num_rows > 0) {
    $is_root_exists = true;
}

if (isset($_POST['register_root']) && !$is_root_exists) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $db_user = "db_" . $username;
    $pwd = mysqli_real_escape_string($conn, $_POST['password']);
    $pwd_hash = password_hash($pwd, PASSWORD_DEFAULT);
    $host_panel = mysqli_real_escape_string($conn, $_POST['host_panel']);
    
    $conn->begin_transaction();

    try {
        $stmt1 = $conn->prepare("INSERT INTO admin (username, password, role) VALUES (?, ?, 'root')");
        $stmt1->bind_param("ss", $username, $pwd_hash);
        $stmt1->execute();

        $stmt2 = $conn->prepare("INSERT INTO db_users (username, db, pwdb, domain, role) VALUES (?, ?, ?, ?, 'root')");
        $stmt2->bind_param("ssss", $username, $db_user, $pwd_hash, $host_panel);
        $stmt2->execute();
        
        $conn->query("DROP USER IF EXISTS '$db_user'@'localhost'");
        $conn->query("CREATE USER '$db_user'@'localhost' IDENTIFIED BY '$pwd'");
        // ON 'database' TO 'user BY 'pw_user 
        $conn->query("GRANT ALL PRIVILEGES ON `".$db_config['name']."`.* TO `$db_user`@'localhost' IDENTIFIED BY '$pwd'");
        $conn->query("FLUSH PRIVILEGES");
        $config_file = $path_panel . 'config.php';
        if (file_exists($config_file)) {
            $content = file_get_contents($config_file);
            $content = preg_replace("/'user' => '.*'/", "'user' => '$db_user'", $content);
            $content = preg_replace("/'pass' => '.*'/", "'pass' => '".addslashes($pwd)."'", $content);
            file_put_contents($config_file, $content);
        }
        $conn->commit();
        $msg = "Administrator berhasil didaftarkan!<br/><b>Username:</b> $username<br/><b>DB User:</b> $db_user<br/><b>Panel & Db Password:</b> $pwd";
        $msg_type = "success";
        $is_root_exists = true; 

    } catch (Exception $e) {
        $conn->rollback();
        $msg = "Gagal Setup: " . $e->getMessage();
    }
}

// 3. LOGIKA LOGIN
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']); 
    $pass = $_POST['password'];

    $res = $conn->query("SELECT * FROM admin WHERE username='$username'");
    if ($res && $res->num_rows > 0) {
        $data = $res->fetch_assoc();
        if (password_verify($pass, $data['password'])) {
            if ($data['role'] === 'root') {
                $_SESSION['user'] = $data['username'];
                $_SESSION['role'] = $data['role'];
                header("Location: dashboard.php");
                exit();
            } else {
                $msg = "Akses ditolak: Anda bukan administrator.";
            }
        } else {
            $msg = "Username atau Password salah!";
        }
    } else {
        $msg = "Akun tidak ditemukan.";
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <title>CP Panel - <?php echo $is_root_exists ? 'Login' : 'System Setup'; ?></title>
    <style>
        body { background: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .auth-card { max-width: 400px; margin: 100px auto; border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); overflow: hidden; }
        .setup-header { background: #00a8e0; color: white; padding: 40px 20px; text-align: center; }
        .btn-primary { background: #00a8e0; border: none; padding: 12px; font-weight: 600; transition: 0.3s; }
        .btn-primary:hover { background: #008dbd; transform: translateY(-2px); }
        .form-control { padding: 12px; border-radius: 8px; }
        .alert { border-radius: 10px; }
    </style>
</head>
<body>

<div class="container">
    <div class="card auth-card">
        <div class="setup-header">
            <i class="bi bi-cpu-fill" style="font-size: 3.5rem;"></i>
            <h4 class="mt-3 fw-bold">CP PANEL</h4>
            <p class="mb-0 opacity-75 small text-uppercase tracking-wider">
                <?php echo $is_root_exists ? 'Secure Authentication' : 'Initial System Setup'; ?>
            </p>
        </div>
        <div class="card-body p-4">

            <?php if($msg): ?>
                <div class="alert alert-<?php echo $msg_type; ?> small shadow-sm mb-4">
                    <i class="bi bi-info-circle me-2"></i> <?php echo $msg; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Username</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-person text-primary"></i></span>
                        <input type="text" name="username" class="form-control border-start-0" placeholder="Masukkan username" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted">Password</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-shield-lock text-primary"></i></span>
                        <input type="password" name="password" class="form-control border-start-0" placeholder="Masukkan password" required>
                    </div>
                </div>
                
                <?php if (!$is_root_exists): ?>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Domain / Host Panel</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-globe text-primary"></i></span>
                            <input type="text" name="host_panel" class="form-control border-start-0" value="<?php echo $host_panel; ?>" required readonly>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!$is_root_exists): ?>
                    <button name="register_root" class="btn btn-primary w-100 mb-3 shadow-sm">
                        <i class="bi bi-rocket-takeoff me-2"></i> Install System Now
                    </button>
                    <div class="p-2 bg-light rounded text-center">
                        <small class="text-muted" style="font-size: 0.75rem;">
                            <i class="bi bi-exclamation-triangle-fill text-warning"></i> 
                            Pendaftaran ini hanya tersedia satu kali untuk akun administrator utama.
                        </small>
                    </div>
                <?php else: ?>
                    <button name="login" class="btn btn-primary w-100 shadow-sm">
                        <i class="bi bi-box-arrow-in-right me-2"></i> Sign In
                    </button>
                <?php endif; ?>
            </form>
        </div>
        <div class="card-footer bg-white border-0 text-center pb-4">
            <small class="text-muted" style="font-size: 0.7rem;">&copy; <?php echo date('Y'); ?> PanelControl. All Rights Reserved.</small>
        </div>
    </div>
</div>

</body>
</html>