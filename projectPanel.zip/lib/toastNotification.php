<div id="toastContainer" class="toast-container position-fixed bottom-0 end-0 p-5" style="z-index: 9999;"></div>
<div id="toastTemplate" class="d-none">
    <div class="toast border-0 shadow-lg rounded-4 overflow-hidden mb-3" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false">
        <div class="toast-body bg-white p-4 pb-2">
            <div class="d-flex justify-content-between mb-2">
                <label></label>
                <button type="button" class="btn-close btn-close-dark shadow-none" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="d-flex align-items-center">
                <i class="bi bi-info-circle me-2 text-info fs-5 toast-icon-ref"></i>
                <strong class="lh-1">
                    <label class="text-muted mb-1 toast-detail-ref"></label>
                </strong>
            </div>
        </div>
        <div class="toast-body-progress bg-white p-4 pt-0">
            <strong><label class="text-muted toast-status-ref"></label></strong>
            <div class="progress_container_ref">
                <div class="progress mb-2" style="height: 8px; border-radius: 10px; background-color: #f0f0f0;">
                    <div class="progress-bar progress-bar-striped progress-bar-animated transition-all prog-bar-ref" style="width: 0%"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let logIntervals = {};
document.addEventListener('DOMContentLoaded', function() {
    const savedTasks = JSON.parse(localStorage.getItem('active_progress_toast') || '{}');
    Object.keys(savedTasks).forEach(taskId => {
        const task = savedTasks[taskId];
        const toastEl = createToastUI(taskId, task.msg);
        startPolling(task.buttonName, taskId, toastEl);
    });
});
function tryAction(action, btnName, formId, msg) {
    const form = document.getElementById(formId);
    form.querySelector('input[name="action_type"]').value = action;
    
    const btnMap = { [action]: btnName };
    const msgAction = { [action]: msg };
    const targetBtn = document.querySelector(`button[name="${btnMap[action]}"]`);
    
    form.dataset.currentMsg = msgAction[action] || 'Please wait, the Action will take a few minutes..';
    progressToast(form);
    
    let event;
    try {
        event = new SubmitEvent('submit', {
            'bubbles': true,
            'cancelable': true,
            'submitter': targetBtn
        });
    } catch (e) {
        event = new Event('submit', { bubbles: true, cancelable: true });
        Object.defineProperty(event, 'submitter', { value: targetBtn, writable: false });
    }
    
    form.dispatchEvent(event);
}
function progressToast(formElement, alertMsg = null) {
    if (formElement.dataset.hasHandler) return;
    formElement.dataset.hasHandler = 'true';
    formElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const btn = e.submitter;
        if(!btn) return;
        const buttonName = btn.name;
        const taskId = 'task_' + Date.now();
        buttonAction('disabled', btn);
        
        const currentMsg = this.dataset.currentMsg || 'Please wait, the Action will take a few minutes..';
        const newToastEl = createToastUI(taskId, currentMsg);
        
        saveTask(taskId, {
            msg: currentMsg, 
            buttonName: buttonName 
        });
        
        const formData = new FormData(this);
        const csrf_token = '<?= $access_token ?>';
        formData.append('csrf_token', csrf_token);
        formData.append('action_with_progress', '1');
        formData.append('task_id', taskId);
    
        fetch(window.location.href, { 
            method: 'POST', 
            body: formData 
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 'started') {
                startPolling(data, buttonName, taskId, newToastEl);
            } else {
                resetSubmitButton(data, buttonName, newToastEl, taskId);
                const inst = bootstrap.Toast.getInstance(newToastEl);
                if(inst) inst.hide();
                if(data.message) alert(data.message);
            }
        })
        .catch(err => {
            handleUIError(buttonName, "Network Connection Error", newToastEl, taskId);
        });
    });
}
function startPolling(dataAlert, buttonName, taskId, toastEl) {
    updateBar(10, "Starting", toastEl);
    let lastStatus = "";
    let url = new URL(window.location.href);
    url.searchParams.set('read_log', '1');
    url.searchParams.set('task_id', taskId);
    
    logIntervals[taskId] = setInterval(() => {
        fetch(url)
        .then(res => res.json())
        .then(data => {
            const rawLog = data.log;
            const progBar = toastEl.querySelector('.prog-bar-ref');

            if (rawLog.toUpperCase().includes('ERROR')) {
                const errorMatch = rawLog.split('<br />').find(line => line.toUpperCase().includes('ERROR'));
                handleUIError(dataAlert, buttonName, errorMatch || "Process Failed", toastEl, taskId);
                return;
            }
            if (rawLog.includes('Initializing') && lastStatus !== "Initializing") {
                updateBar(25, "Initializing", toastEl);
                lastStatus = "Initializing";
            }
            if (rawLog.includes('Processing') && lastStatus !== "Processing") {
                updateBar(60, 'Processing', toastEl);
                lastStatus = "Processing";
            }
            if (rawLog.includes('Finish') && lastStatus !== "Finish") {
                updateBar(90, "Finish", toastEl);
                lastStatus = "Finish";
            }
            if (data.done === true) {
                resetSubmitButton(dataAlert, buttonName, toastEl, taskId);
                updateBar(100, "Completed", toastEl);
                
                progBar.classList.replace('bg-primary', 'bg-success');
                progBar.classList.remove('progress-bar-animated', 'progress-bar-striped');
            }
        });
    }, 2000);
}
function createToastUI(taskId, msg) {
    const template = document.querySelector('#toastTemplate .toast');
    const newToastEl = template.cloneNode(true);
    newToastEl.id = taskId;
    document.getElementById('toastContainer').appendChild(newToastEl);
    const newToastInstance = new bootstrap.Toast(newToastEl);
    newToastInstance.show();
    newToastEl.querySelector('.toast-detail-ref').innerText = msg;
    return newToastEl;
}
function saveTask(taskId, data) {
    const tasks = JSON.parse(localStorage.getItem('active_progress_toast') || '{}');
    tasks[taskId] = data;
    localStorage.setItem('active_progress_toast', JSON.stringify(tasks));
}
function removeTask(taskId) {
    const tasks = JSON.parse(localStorage.getItem('active_progress_toast') || '{}');
    delete tasks[taskId];
    localStorage.setItem('active_progress_toast', JSON.stringify(tasks));
}
function alertHandle(alertMessage) {
    const alertEl = document.querySelector('.alert');
    if(!alertEl) return;
    alertEl.classList.remove('d-none', 'alert-success', 'alert-danger', 'show');
    setTimeout(() => {
        if (alertMessage.alert === 'success') {
            alertEl.classList.add('alert-success');
            alertEl.querySelector('.icon-alert').innerText = '🎉';
        } else if (alertMessage.alert === 'danger' || alertMessage.status === 'error') {
            alertEl.classList.add('alert-danger');
            alertEl.querySelector('.icon-alert').innerText = '⚠️';
        }
        alertEl.querySelector('.alert-msg').innerText = alertMessage.msg || alertMessage.message || "Action Completed";
        alertEl.classList.add('show');
    }, 100);
}
function handleUIError(dataAlert, buttonName, message, toastEl, taskId) {
    toastEl.classList.add('bg-danger');
    toastEl.querySelector('.toast-icon-ref').className = "bi bi-exclamation-octagon-fill me-2";
    toastEl.querySelector('.toast-detail-ref').innerText = message;
    const toastBody = toastEl.querySelector('.toast-body');
    toastBody.classList.replace('bg-white', 'bg-danger');
    const toastBodyProgress = toastEl.querySelector('.toast-body-progress');
    toastBodyProgress.classList.replace('bg-white', 'bg-danger');
    const progBar = toastEl.querySelector('.prog-bar-ref');
    progBar.classList.remove('progress-bar-animated', 'bg-primary');
    progBar.classList.add('bg-dark');
    progBar.style.width = '100%';
    updateBar(100, message, toastEl);
    resetSubmitButton(dataAlert, buttonName, toastEl, taskId);
}
function updateBar(val, msg, toastEl) {
    if(!toastEl) return;
    const bar = toastEl.querySelector('.prog-bar-ref');
    const statusLabel = toastEl.querySelector('.toast-status-ref');
    if(bar) bar.style.width = val + '%';
    if(msg && statusLabel) statusLabel.innerText = msg;
}
function resetSubmitButton(dataAlert, buttonName, toastEl, taskId) {
    clearInterval(logIntervals[taskId]);
    removeTask(taskId);
    alertHandle(dataAlert)
    updateData();
    const btn = document.querySelector(`button[name="${buttonName}"]`);
    buttonAction('enabled', btn);
    if (toastEl) {
        setTimeout(() => {
            const inst = bootstrap.Toast.getInstance(toastEl);
            if (inst) {
                inst.hide();
                setTimeout(() => toastEl.remove(), 500);
            }
        }, 10000);
    }
}

function updateData(inputs = []) {
    fetch(window.location.href)
        .then(res => res.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const newTbody = doc.querySelector('tbody');
            const currentTbody = document.querySelector('tbody');
            if (newTbody && currentTbody) {
                currentTbody.innerHTML = newTbody.innerHTML;
            }
            const divId = doc.getElementById('classRefresh');
            const currentId = document.getElementById('classRefresh');
            if (divId && currentId) {
                currentId.innerHTML = divId.innerHTML;
            }
            if (Array.isArray(inputs)) {
                inputs.forEach(id => {
                    const newElement = doc.getElementById(id);
                    const currentElement = document.getElementById(id);
                    if (newElement && currentElement) {
                        currentElement.innerHTML = newElement.innerHTML;
                    }
                });
            }
        })
}
function buttonAction(action, btn, innerHtml = null, innerText = null, btnClass = null) {
    if (!btn) return;
    if (action === 'disabled') {
        btn.dataset.originalText = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
        if(innerHtml) btn.innerHTML = innerHtml;
        if(innerText) btn.innerText = innerText;
        if(btnClass) btn.className = btnClass;
    } 
    else if (action === 'enabled') {
        const originalText = btn.getAttribute('data-original-text');
        btn.disabled = false;
        btn.innerHTML = originalText;
        if(innerHtml) btn.innerHTML = innerHtml;
        if(innerText) btn.innerText = innerText;
        if(btnClass) btn.className = btnClass;
    }
}
function btnFilled(formId, btnName, inputs = []) {
    const inputForm = document.getElementById(formId);
    if (!inputForm) return;
    const btnSubmit = inputForm.querySelector(`button[name="${btnName}"]`);
    const selector = inputs.map(name => `[name="${name}"]`).join(', ');
    const requiredInputs = inputForm.querySelectorAll(selector);
    const checkInputs = () => {
        let allFilled = true;
        requiredInputs.forEach(input => {
            if (input.value.trim() === '') {
                allFilled = false;
            }
        });
        btnSubmit.disabled = !allFilled;
    };
    requiredInputs.forEach(input => {
        input.addEventListener('input' || 'chamge', checkInputs);
    });
    checkInputs();
}
function bsModal(modalId, action) {
    const el = document.getElementById(modalId);
    if (!el) return;
    let modalInstance = bootstrap.Modal.getInstance(el);
    if (!modalInstance) modalInstance = new bootstrap.Modal(el); 
    if (action === 'hide') { modalInstance.hide(); } else { modalInstance.show(); }
}

</script>