<?php
$clientData = [
    "client" => [
        [
            "clientId" => 1,
            "clientName" => "WEB",
            "clientVersion" => "2.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 2,
            "clientName" => "MWEB",
            "clientVersion" => "2.20220918",
            "userAgent" => "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 3,
            "clientName" => "ANDROID",
            "clientVersion" => "20.42.40",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
        ],
        [
            "clientId" => 5,
            "clientName" => "IOS",
            "clientVersion" => "17.36.4",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 7,
            "clientName" => "TVHTML5",
            "clientVersion" => "7.20220918",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 8,
            "clientName" => "TVLITE",
            "clientVersion" => "2",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 10,
            "clientName" => "TVANDROID",
            "clientVersion" => "2",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 13,
            "clientName" => "XBOXONEGUIDE",
            "clientVersion" => "2",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 14,
            "clientName" => "ANDROID_CREATOR",
            "clientVersion" => "22.36.102",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 15,
            "clientName" => "IOS_CREATOR",
            "clientVersion" => "22.36.102",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 16,
            "clientName" => "TVAPPLE",
            "clientVersion" => "22.36.102",
            "userAgent" => "Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 18,
            "clientName" => "ANDROID_KIDS",
            "clientVersion" => "7.36.1",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyBbZV_fZ3an51sF-mvs5w37OqqbsTOzwtU"
        ],
        [
            "clientId" => 19,
            "clientName" => "IOS_KIDS",
            "clientVersion" => "7.36.1",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 21,
            "clientName" => "ANDROID_MUSIC",
            "clientVersion" => "5.26.1",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyAOghZGza2MQSZkY_zfZ370N-PUdXEo8AI"
        ],
        [
            "clientId" => 23,
            "clientName" => "ANDROID_TV",
            "clientVersion" => "2.19.1.303051424",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 26,
            "clientName" => "IOS_MUSIC",
            "clientVersion" => "5.26.1",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyBAETezhkwP0ZWA02RsqT1zu78Fpt0bC_s"
        ],
        [
            "clientId" => 27,
            "clientName" => "MWEB_TIER_2",
            "clientVersion" => "9.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 28,
            "clientName" => "ANDROID_VR",
            "clientVersion" => "1.37",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
        ],
        [
            "clientId" => 29,
            "clientName" => "ANDROID_UNPLUGGED",
            "clientVersion" => "6.36",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
        ],
        [
            "clientId" => 30,
            "clientName" => "ANDROID_TESTSUITE",
            "clientVersion" => "1.9",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
        ],
        [
            "clientId" => 31,
            "clientName" => "WEB_MUSIC_ANALYTICS",
            "clientVersion" => "1.9",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
        ],
        [
            "clientId" => 33,
            "clientName" => "IOS_UNPLUGGED",
            "clientVersion" => "6.36",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 38,
            "clientName" => "ANDROID_LITE",
            "clientVersion" => "3.26.1",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
        ],
        [
            "clientId" => 39,
            "clientName" => "IOS_EMBEDDED_PLAYER",
            "clientVersion" => "2.4",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 41,
            "clientName" => "WEB_UNPLUGGED",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 42,
            "clientName" => "WEB_EXPERIMENTS",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 43,
            "clientName" => "TVHTML5_CAST",
            "clientVersion" => "1.1",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 55,
            "clientName" => "ANDROID_EMBEDDED_PLAYER",
            "clientVersion" => "17.36.4",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw"
        ],
        [
            "clientId" => 56,
            "clientName" => "WEB_EMBEDDED_PLAYER",
            "clientVersion" => "9.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw"
        ],
        [
            "clientId" => 57,
            "clientName" => "TVHTML5_AUDIO",
            "clientVersion" => "2.0",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 58,
            "clientName" => "TV_UNPLUGGED_CAST",
            "clientVersion" => "2.0",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 59,
            "clientName" => "TVHTML5_KIDS",
            "clientVersion" => "3.20220918",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyBbZV_fZ3an51sF-mvs5w37OqqbsTOzwtU"
        ],
        [
            "clientId" => 60,
            "clientName" => "WEB_HEROES",
            "clientVersion" => "3.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 61,
            "clientName" => "WEB_MUSIC",
            "clientVersion" => "3.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
        ],
        [
            "clientId" => 62,
            "clientName" => "WEB_CREATOR",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyBUPetSUmoZL-OhlxA7wSac5XinrygCqMo"
        ],
        [
            "clientId" => 63,
            "clientName" => "TV_UNPLUGGED_ANDROID",
            "clientVersion" => "1.37",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 64,
            "clientName" => "IOS_LIVE_CREATION_EXTENSION",
            "clientVersion" => "17.36.4",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 65,
            "clientName" => "TVHTML5_UNPLUGGED",
            "clientVersion" => "6.36",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 66,
            "clientName" => "IOS_MESSAGES_EXTENSION",
            "clientVersion" => "17.36.4",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 67,
            "clientName" => "WEB_REMIX", // sig
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 68,
            "clientName" => "IOS_UPTIME",
            "clientVersion" => "1.20220918",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 69,
            "clientName" => "WEB_UNPLUGGED_ONBOARDING",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 70,
            "clientName" => "WEB_UNPLUGGED_OPS",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 71,
            "clientName" => "WEB_UNPLUGGED_PUBLIC",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 72,
            "clientName" => "TVHTML5_VR",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 74,
            "clientName" => "ANDROID_TV_KIDS",
            "clientVersion" => "1.19.1",
            "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
            "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
        ],
        [
            "clientId" => 75,
            "clientName" => "TVHTML5_SIMPLY",
            "clientVersion" => "1.0",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 76,
            "clientName" => "WEB_KIDS",
            "clientVersion" => "2.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyBbZV_fZ3an51sF-mvs5w37OqqbsTOzwtU"
        ],
        [
            "clientId" => 77,
            "clientName" => "MUSIC_INTEGRATIONS",
            "clientVersion" => "2.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 80,
            "clientName" => "TVHTML5_YONGLE",
            "clientVersion" => "2.20220918",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 84,
            "clientName" => "GOOGLE_ASSISTANT",
            "clientVersion" => "2.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 85,
            "clientName" => "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            "clientVersion" => "2.0",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw"
        ],
        [
            "clientId" => 87,
            "clientName" => "WEB_INTERNAL_ANALYTICS",
            "clientVersion" => "2.0",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 88,
            "clientName" => "WEB_PARENT_TOOLS", // muxed
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 89,
            "clientName" => "GOOGLE_MEDIA_ACTIONS",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 90,
            "clientName" => "WEB_PHONE_VERIFICATION",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 92,
            "clientName" => "IOS_PRODUCER",
            "clientVersion" => "1.20220918",
            "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
        ],
        [
            "clientId" => 93,
            "clientName" => "TVHTML5_FOR_KIDS",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 94,
            "clientName" => "GOOGLE_LIST_RECS",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ],
        [
            "clientId" => 95,
            "clientName" => "MEDIA_CONNECT_FRONTEND",
            "clientVersion" => "1.20220918",
            "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
        ]
    ]
];