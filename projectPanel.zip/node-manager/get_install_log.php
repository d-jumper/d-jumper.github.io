<?php
// node-manager/get_install_log.php
header('Content-Type: text/plain');
header('Cache-Control: no-cache');

if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

$log_file = "/tmp/node_inst.log";
if (file_exists($log_file)) {
    $output = shell_exec("tail -n 20 " . escapeshellarg($log_file));
    echo $output ?: "Menunggu output...";
} else {
    echo "Initializing installation log...";
}
exit;