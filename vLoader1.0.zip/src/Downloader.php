<?php

namespace DJumPer;

use DJumPer\Client\Client;
use DJumPer\Utils\Utils;
use DJumPer\Platform\Facebook;
use DJumPer\Platform\Instagram;
use DJumPer\Platform\TikTok;
use DJumPer\Platform\Youtube;

use Exception;

class Downloader
{

    // Guzzle
    private $client;
    
    // Platform
    private $fb; private $ig;
    private $tiktok; private $yt;
    
    public function __construct()
    {
        $this->client = new Client();
        $this->fb = new Facebook($this);
        $this->ig = new Instagram($this);
        $this->tiktok = new TikTok($this);
        $this->yt = new Youtube($this);
    }

    public function getVideoInfo($url, $type, $itag = null)
    {
        $options = [];
        try {
            if (strpos($url, 'youtube.com') === false && strpos($url, 'youtu.be') === false) {
                $url = strtok($url, '?');
                
            } 
            if (strpos($url, 'facebook.com') !== false) {
                $url = str_replace(['web.facebook.com', 'www.facebook.com'], 'm.facebook.com', $url);
                
            } 
            if (strpos($url, 'tiktok.com') !== false) {
                if(strpos($url, 'vt.tiktok.com') !== false) {
                    $options = [
                        'headers' => [
                            'User-Agent' => $this->isUA($url),
                            'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                            'Accept-Language' => 'id-ID,id;q=0.9,en-US;q=0.8',
                            'Referer' => 'https://www.tiktok.com/',
                        ],
                        'allow_redirects' => [
                            'max'             => 10,
                            'protocols'       => ['http', 'https'],
                            'track_redirects' => true
                        ]
                    ];
                    $response = $this->client->get($url, $options);
                    $history = $response->getHeader('X-Guzzle-Redirect-History');
                    if (!empty($history)) {
                        $url = end($history);
                    } else {
                        $url = (string)$response->getEffectiveUri();
                    }
                }
                
            }
            if (strpos($url, 'instagram.com') !== false) {
                $url = strtok($url, '?');
                preg_match('/\/reels?\/([^\/]+)/', $url, $matches);
                $shortcode = $matches[1] ?? '';
                $doc_id = "8845758582119845";
                $variables = json_encode([
                    "shortcode" => $shortcode,
                    "fetch_comment_count" => 40,
                    "has_threaded_comments" => true
                ]);
                $url = "https://www.instagram.com/graphql/query/?doc_id={$doc_id}&variables=" . urlencode($variables);
            }
            
            if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) {
                $data = $this->yt->scrape($url);
                
            } else {
                // ----------------------------------
                $response = $this->client->get($url, $options);
                $html = (string)$response->getBody();
                
                $cookieJar = $this->client->jar->toArray();
                $cookieString = '';
                foreach ($cookieJar as $c) {
                    $cookieString .= $c['Name'] . '=' . $c['Value'] . '; ';
                }
                
                if (strpos($url, 'instagram.com') !== false) {
                    $data = $this->ig->scrape($html);
                } elseif (strpos($url, 'facebook.com') !== false || strpos($url, 'fb.watch') !== false) {
                    $data = $this->fb->scrape($html);
                } elseif (strpos($url, 'tiktok.com') !== false) {
                    $data = $this->tiktok->scrape($html);
                } else {
                    throw new Exception("Platform tidak didukung.");
                }
            }

            return $this->action($type, $data, $itag, $cookieString);
            
        } catch (Exception $e) {
            //return $this->fallBack($url, $type, $itag);
            throw new Exception("Error: " . $e->getMessage());
        }
    }
    
    public function fallBack($url, $type, $itag = null)
    {
        return $this->getVideoInfo($url, $type, $itag);
    }
    
    public function action($type, $resultData, $itag = null, $cookie = null)
    {
        $title = Utils::limitString($resultData['title'], 50);
        if ($type == 'getData') {
            return $resultData;
            
        } else if ($type == 'streaming') {
            foreach ($resultData['streaming_data'] as $s) {
                if (isset($s['url'])) {
                    $urlData = $s['url'];
                    $formatType = $s['type'];
                    break;
                }
            }
            if (empty($urlData)) {
                throw new Exception("Video streaming tidak ditemukan.");
            }
            return $this->download($urlData, true, null, $formatType, $cookie);

        } else if ($type == 'download_video') {
            foreach ($resultData['video_data'] as $v) {
                if ((int)$v['itag'] == (int)$itag) {
                    $urlData = $v['url'];
                    $formatType = $v['type'];
                    break;
                }
            }
            if (empty($urlData)) {
                throw new Exception("Video quality tidak ditemukan.");
            }
            return $this->download($urlData, false, "Video - $title", $formatType, $cookie);
            
        } else if ($type == 'download_audio') {
            foreach ($resultData['audio_data'] as $a) {
                if ((int)$a['itag'] == (int)$itag) {
                    $urlData = $a['url'];
                    $formatType = $a['type'];
                    break;
                }
            }
            if (empty($urlData)) {
                throw new Exception("Audio quality tidak ditemukan.");
            }
            return $this->download($urlData, false, "Audio - $title", $formatType, $cookie);
            
        }
    }
        
    public function downloadAndMux($videoUrl, $audioUrl, $title = "Video")
    {
        // Hilangkan batasan waktu karena download file besar butuh waktu
        set_time_limit(0); 

        // Bersihkan nama file dari karakter ilegal
        $cleanTitle = preg_replace('/[^A-Za-z0-9_\- \(\)\[\]]/', '_', $title);
        $outputFilename = $cleanTitle . ".mp4";

        // Buat file temporary di server
        $tempDir = sys_get_temp_dir();
        $tempVideo = tempnam($tempDir, 'yt_vid_') . '.mp4';
        $tempAudio = tempnam($tempDir, 'yt_aud_') . '.m4a';
        $tempOutput = tempnam($tempDir, 'yt_out_') . '.mp4';

        try {
            // 1. Download Video (Tanpa Suara) ke Temp File
            // Gunakan Guzzle client Anda agar User-Agent dan Header ikut terkirim
            $this->client->request('GET', $videoUrl, ['sink' => $tempVideo, 'headers' => $this->yt->ytHeaders()]);
            
            // 2. Download Audio ke Temp File
            $this->client->request('GET', $audioUrl, ['sink' => $tempAudio, 'headers' => $this->yt->ytHeaders()]);

            // 3. Gabungkan menggunakan FFmpeg
            $vTemp = escapeshellarg($tempVideo);
            $aTemp = escapeshellarg($tempAudio);
            $out   = escapeshellarg($tempOutput);

            // Perintah FFmpeg: -c copy berarti HANYA menyalin stream (tidak render ulang), jadi prosesnya cuma 1-3 detik!
            $cmd = "ffmpeg -y -i $vTemp -i $aTemp -c copy $out 2>&1";
            exec($cmd, $output, $return_var);

            if ($return_var !== 0) {
                throw new Exception("FFmpeg error: " . implode("\n", $output));
            }

            // 4. Kirim file final ke Browser User
            header('Content-Type: video/mp4');
            header('Content-Disposition: attachment; filename="' . $outputFilename . '"');
            header('Content-Length: ' . filesize($tempOutput));
            
            // Baca file dan buang ke output buffer (browser)
            readfile($tempOutput);
            exit;

        } catch (Exception $e) {
            echo "Gagal memproses video: " . $e->getMessage();
        } finally {
            // 5. BERSIHKAN FILE SAMPAH (Sangat penting agar server tidak penuh)
            if (file_exists($tempVideo)) unlink($tempVideo);
            if (file_exists($tempAudio)) unlink($tempAudio);
            if (file_exists($tempOutput)) unlink($tempOutput);
        }
    }

    private function isAllowedHost($url)
    {
        $parsed_url = parse_url($url); 
        if (!in_array($parsed_url['scheme'] ?? '', ['http', 'https'])) {
            http_response_code(403);
            die("Forbidden: Invalid protocol.");
        }
        
        $host = $parsed_url['host'] ?? '';
        
        $allowedHosts = [
            'googlevideo.com', 'youtube.com',
            'tiktok.com', 'tiktokcdn.com',
            'fbcdn.net', 'facebook.com',
            'instagram.com'
        ];
        $valid = false;
        foreach ($allowedHosts as $h) {
            if (substr($host, -strlen($h)) === $h) {
                $valid = true;
                break;
            }
        }
        if (!$valid) { throw new Exception("Host not allowed."); }
        return $host;
    }
    
    private function isUA($url = null)
    {
        $desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
        $iPhoneUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1';
        $androidUA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
                
        $ua = $androidUA;
        if (strpos($url, 'googlevideo.com') !== false || strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) {
            $ua = $this->yt->ytUA();
        } elseif (strpos($url, 'tiktok.com') !== false || strpos($url, 'tiktokcdn.com') !== false || strpos($url, 'vt.tiktok.com') !== false) {
            $ua = $iPhoneUA;
        }
        return $ua;
    }

    public function download($url, $streaming = true, $title = null, $formatType = null, $cookie = null)
    {        
        $host = $this->isAllowedHost($url);
        $ua = $this->isUA($url);        

        $http_v = CURL_HTTP_VERSION_2_0;
        if (strpos($host, 'googlevideo.com') !== false || strpos($host, 'youtube.com') !== false) {
            $http_v = CURL_HTTP_VERSION_1_1;
            $headers = $this->yt->ytHeaders();
            
        } else {
                
            $headers = [
                "User-Agent: " . $ua,
                "Accept: */*",
                "Accept-Language: en-US,en;q=0.9",
                "Connection: keep-alive"
            ];
            
            if (strpos($host, 'tiktok.com') !== false || strpos($host, 'tiktokcdn.com') !== false) {
                $headers[] = "Referer: https://www.tiktok.com/";
            }
            $headers[] = "Sec-Fetch-Dest: video";
            $headers[] = "Sec-Fetch-Mode: no-cors";
            $headers[] = "Sec-Fetch-Site: cross-site";
        
            if (!empty($cookie)) {
                $headers[] = (strpos($cookie, '=') === false) ? "Cookie: ttwid=" . $cookie : "Cookie: " . $cookie;
            }
            if (isset($_SERVER['HTTP_RANGE'])) {
                $headers[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
            }
    
        }
                    
        while (ob_get_level()) { ob_end_clean(); }
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_HTTP_VERSION => $http_v,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_BUFFERSIZE => 262144,
            CURLOPT_ENCODING => "", 
            CURLOPT_TCP_KEEPALIVE => 1,
            CURLOPT_TCP_KEEPIDLE => 120,
            CURLOPT_TCP_KEEPINTVL => 60,
            CURLOPT_HEADERFUNCTION => function($curl, $header) use ($title, $streaming, $formatType) {
                $len = strlen($header);
                $h = strtolower($header);
                
                if (preg_match('/^http\/(1\.[01]|2|3)\s+(\d+)/', $h, $matches)) {
                    http_response_code(intval($matches[2]));
                    return $len;
                }
                
                $allowed = ['content-type:', 'content-length:', 'content-range:', 'accept-ranges:'];
                foreach ($allowed as $a) {
                    if (strpos($h, $a) === 0) {
                        if ($a === 'content-type:') {
                            $ext = $formatType ?: "mp4";
                            header($streaming ? "Content-Type: video/{$ext}" : "Content-Type: application/octet-stream");
                            if (!$streaming) {
                                $title = str_replace('#', '_', $title);
                                $title = preg_replace('/[\/\\\\:*?"<>|]/u', '', $title);
                                $title = preg_replace('/\s+/', ' ', $title);
                                $title = trim($title);
                                $filename = "{$title}.{$ext}";
                                header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode($filename));
                            }
                        } else {
                            header($header, false);
                        }
                        break;
                    }
                }
                return $len;
            }
        ]);
        
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($curl, $data) {
            if (connection_aborted()) { return -1; }
            echo $data; 
            ob_flush(); 
            flush(); 
            return strlen($data);
        });
        
        $result = curl_exec($ch);
        curl_close($ch);
    }
    
}