<?php

namespace DJumPer\Client;

class ytClient
{
        
    public function getRandomClient()
    {
        $clients = $this->client();
        $keys = array_keys($clients);
        $randomKey = $keys[array_rand($keys)];
    
        return $this->getClientByName($randomKey);
    }
    
    
    public function getClientByName($name)
    {
        $clients = $this->client();
        if (!isset($clients[$name])) {
            return null;
        }
        return [
            "client" => $clients[$name]['client'],
            "data" => $clients[$name]['data']
        ];
    }
    
    public function clientHeader($data)
    {
        $clientName = $data['client']['clientName'];
        $headers = [
            "User-Agent" => $data['data']['userAgent'],
            "Content-Type" => "application/json"
        ];
    
        if ($clientName === 'WEB_REMIX') {
            $headers["Origin"] = "https://music.youtube.com";
            $headers["Referer"] = "https://music.youtube.com/";
        }
    
        if (in_array($clientName, ['ANDROID','ANDROID_EMBEDDED_PLAYER','IOS'])) {
            $headers["X-YouTube-Client-Name"] = $data['data']['clientId'];
            $headers["X-YouTube-Client-Version"] = $data['client']['clientVersion'];
        }
    
        if ($clientName === 'TVHTML5') {
            $headers["Origin"] = "https://www.youtube.com";
        }
    
        return $headers;
    }
     
    public function client()
    {
        return [
        
            "ANDROID" => [ // muxed
                "client" => [
                    "clientName" => "ANDROID",
                    "clientVersion" => "20.42.40",
                    "platform" => "MOBILE",
                    "osName" => "Android",
                    "osVersion" => "14",
                    "androidSdkVersion" => 34,
                    "hl" => "en",
                    "gl" => "US"
                ],
                "data" => [
                    "clientId" => 3,
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ]
            ]
            
            /*"ANDROID" => [ // muxed
                "client" => [
                    "clientName" => "ANDROID",
                    "clientVersion" => "20.42.40",
                    "platform" => "MOBILE",
                    "osName" => "Android",
                    "osVersion" => "14",
                    "androidSdkVersion" => 34,
                    "hl" => "en",
                    "gl" => "US"
                ],
                "data" => [
                    "clientId" => 3,
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ]
            ],

            "IOS" => [ // adaptiveFormats
                "client" => [
                    "clientName" => "IOS",
                    "clientVersion" => "20.10.4",
                    "osName" => "iPhone",
                    "osVersion" => "18.3.2"
                ],
                "data" => [
                    "clientId" => 5,
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ]
            ],
            
            "WEB_REMIX" => [ // muxed
                "client" => [
                    "clientName" => "WEB_REMIX",
                    "clientVersion" => "1.20220918",
                    "platform" => "DESKTOP",
                    "clientScreen" => "WATCH",
                    "hl" => "en",
                    "gl" => "US"
                ],
                "data" => [
                    "clientId" => 67,
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ]
            ],
            
            "ANDROID_EMBEDDED_PLAYER" => [
                "client" => [
                    "clientName" => "ANDROID_EMBEDDED_PLAYER",
                    "clientVersion" => "17.36.4",
                    "platform" => "MOBILE",
                    "osName" => "Android",
                    "osVersion" => "14"
                ],
                "data" => [
                    "clientId" => 55,
                    "userAgent" => "com.google.android.youtube/17.36.4 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw"
                ]
            ],
            
            "TVHTML5" => [
                "client" => [
                    "clientName" => "TVHTML5",
                    "clientVersion" => "7.20220918",
                    "platform" => "TV",
                    "clientScreen" => "WATCH",
                    "hl" => "en",
                    "gl" => "US"
                ],
                "data" => [
                    "clientId" => 7,
                    "userAgent" => "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0)",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ]
            ]*/
            
        ];
    }
}

/*

    https://youtu.be/Zv11L-ZfrSg

    private function solveNParameter($url)  
    {  
        if (!preg_match('/[?&]n=([^&]+)/', $url, $nMatch)) {  
            //return $url;  
        }  
        $nVal = $nMatch[1];  
        if (strpos($url, 'ratebypass') === false) {  
            $url .= '&ratebypass=yes';  
        }  
        if (strpos($url, '&c=') !== false) {  
            $url = preg_replace('/&c=[^&]+/', '&c=TVHTML5&cver=7.20240701', $url);  
        } else {  
            $url .= '&c=TVHTML5&cver=7.20240701';  
        }  
        return $url;  
    }  
    
            "WEB_EMBEDDED_PLAYER" => [
                "client" => [
                    "hl" => "en",
                    "gl" => "ID",
                    "remoteHost" => "114.10.28.96",
                    "deviceMake" => "",
                    "deviceModel" => "",
                    "visitorData" => "CgszUnBqWVhXeEJPTSjfwMvNBjIKCgJJRBIEGgAgL2LfAgrcAjE2LllUPVNoZTF2Y1RfSVNRWFhDWWdwY2hpc1c0dWFCcktWWEhmdk1fblNmVWExYlZ5V1lNamIyNTdzTTVSYnZwSFJuQ1ZaMG5hVjkyMWo1WTZoaUp5RWpRWmM2bi1QckhGMzdqZWtjSTdyaVdBS0NYemo0enNXbnViMHZCOWVsZHNNNWN1NVZTRVRVWmtULWE0SVdDS1V0YTFnMEdFMThnTE41Z21aOWZMRXZBU2Nfb1JBdThtcVdPZzZoNGotRGpEdlY5U1FLWTJ6QWNQN2dTdnhLRFI5R000SE8xQ0hvTWlybndBMVZ2VTd1aXhpTktCazE3MjRDdEx3TVNVZTM0ZHE1TnZiLWs3TDNTLVRlUS1EQTRTREdnb0lWM2xhWkU4QU1WQlc4c242NExRUzgzRmprUHAzVmkzOFUzZnJJZmY3OFd1SlVvRHBnNHVIYTlmUU1QZTY3SENDQQ%3D%3D",
                    "userAgent" => "Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/124.0.0.0 Safari\/537.36,gzip(gfe)",
                    "clientName" => "WEB_EMBEDDED_PLAYER",
                    "clientVersion" => "1.20260310.04.00",
                    "osName" => "Windows",
                    "osVersion" => "10.0",
                    "originalUrl" => "https:\/\/www.youtube.com\/embed\/wAnfpeUavRU",
                    "platform" => "DESKTOP",
                    "clientFormFactor" => "UNKNOWN_FORM_FACTOR",
                    "configInfo" => [
                        "appInstallData" => "CN_Ay80GEK7WzxwQzPnQHBCJsM4cELjkzhwQlLbQHBD79tAcEJSD0BwQ0-7QHBDa984cEN68zhwQrPXQHBDb1NAcEMj3zxwQu9nOHBCd0LAFEL2ZsAUQ0MKAExDxtNAcEJjd0BwQmY2xBRCU_rAFEKbr0BwQ9quwBRCa-dAcENX_0BwQjOnPHBDM364FEKa20BwQn8-AExC9irAFEPyyzhwQwY_QHBCL988cEJn60BwQxsbPHBC9tq4FEOvm0BwQntCAExCBzc4cEPCcsAUQh6zOHBCV988cELyk0BwQxfnQHBCF04ATELC7gBMQ45XQHCpAQ0FNU0t4VWctWnEtRE1lVUVwVUNuQTc1RmIwR1dlT3k4QXN5b0t3RUE4M19CY3UzQnZzbXR1UUduNGtOSFFjPTAA"
                    ],
                    "browserName" => "Chrome",
                    "browserVersion" => "124.0.0.0",
                    "acceptHeader" => "text\/html,application\/xhtml+xml,application\/xml;q=0.9,*\/*;q=0.8",
                    "deviceExperimentId" => "ChxOell4TmpNNU5qWXhPRGd5TWpnNU5UUTJNUT09EN_Ay80GGN_Ay80G",
                    "rolloutToken" => "CPCvvqLqmo66ggEQ0cOwgduakwMY0cOwgduakwM%3D"
                ],
                "data" => [
                    "clientId" => 56,
                    "userAgent" => "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ]
            ]
            
            
curl --http1.1 \
-H "User-Agent: com.google.ios.youtube/20.10.4" \
-H "Range: bytes=0-1024" \
-o test.mp4 \
"https://rr3---sn-poqvn5u-jb3y.googlevideo.com/videoplayback?expire=1773330535&ei=B4yyaaTRLYDg9fwP_K2gwAU&ip=114.10.28.96&id=o-AFM-C8dDK012-HY32DPGZACLlmyJZHYcZvMs-5igyPOH&itag=137&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&cps=542&met=1773308935%2C&mh=jp&mm=31%2C26&mn=sn-poqvn5u-jb3y%2Csn-30a7rne6&ms=au%2Conr&mv=m&mvi=3&pcm2cms=yes&pl=23&rms=au%2Cau&initcwndbps=508750&bui=AVNa5-w4ERLjEIG8i47HBN4DGSF6LcWcwAEDJPkC8uMI7LgXHtBHf7aNK4-1t02p6Zz048VMbCfMvrdb&spc=6dlaFE-VBUJQtD0amTha7AgIjcRVPXFJzRD6tNHeoHsWb2Mxa2uCJNCc2cENkQ&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=21414715&dur=313.566&lmt=1773012332813809&mt=1773308498&fvip=5&keepalive=yes&fexp=51565116%2C51565681%2C51791334&c=IOS&txp=5535534&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AHEqNM4wRAIgdseO-yOC8nmTDRtk8HXFJ4xhf1N2XQv1XWgJcinT4hoCIDrhBICOerCHNzSOcnHrvdc6yrNACowM68FkLdzzPO91&lsparams=cps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpcm2cms%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRgIhANsvE6wK61nmchC7-zzGhS6Y2vJCx2Braeub553-ZP4hAiEA5hOJ0lRVMBGZ3EaqV1kknVp5JmwdNGcAwxkqDW7kFpU%3D"

curl -v \
-H "User-Agent: com.google.ios.youtube/20.10.4" \
-H "Range: bytes=0-1024" \
-o test.mp4 \
"https://rr3---sn-poqvn5u-jb3y.googlevideo.com/videoplayback?expire=1773330535&ei=B4yyaaTRLYDg9fwP_K2gwAU&ip=114.10.28.96&id=o-AFM-C8dDK012-HY32DPGZACLlmyJZHYcZvMs-5igyPOH&itag=137&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&cps=542&met=1773308935%2C&mh=jp&mm=31%2C26&mn=sn-poqvn5u-jb3y%2Csn-30a7rne6&ms=au%2Conr&mv=m&mvi=3&pcm2cms=yes&pl=23&rms=au%2Cau&initcwndbps=508750&bui=AVNa5-w4ERLjEIG8i47HBN4DGSF6LcWcwAEDJPkC8uMI7LgXHtBHf7aNK4-1t02p6Zz048VMbCfMvrdb&spc=6dlaFE-VBUJQtD0amTha7AgIjcRVPXFJzRD6tNHeoHsWb2Mxa2uCJNCc2cENkQ&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=21414715&dur=313.566&lmt=1773012332813809&mt=1773308498&fvip=5&keepalive=yes&fexp=51565116%2C51565681%2C51791334&c=IOS&txp=5535534&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AHEqNM4wRAIgdseO-yOC8nmTDRtk8HXFJ4xhf1N2XQv1XWgJcinT4hoCIDrhBICOerCHNzSOcnHrvdc6yrNACowM68FkLdzzPO91&lsparams=cps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpcm2cms%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRgIhANsvE6wK61nmchC7-zzGhS6Y2vJCx2Braeub553-ZP4hAiEA5hOJ0lRVMBGZ3EaqV1kknVp5JmwdNGcAwxkqDW7kFpU%3D"

date -d @1773330535

curl -v \                                                          -H "User-Agent: com.google.ios.youtube/20.10.4" \                                        -H "Range: bytes=0-1024" \                                                               -o test.mp4 \                                                                            "https://rr3---sn-poqvn5u-jb3y.googlevideo.com/videoplayback?expire=1773330535&ei=B4yyaaTRLYDg9fwP_K2gwAU&ip=114.10.28.96&id=o-AFM-C8dDK012-HY32DPGZACLlmyJZHYcZvMs-5igyPOH&itag=137&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&cps=542&met=1773308935%2C&mh=jp&mm=31%2C26&mn=sn-poqvn5u-jb3y%2Csn-30a7rne6&ms=au%2Conr&mv=m&mvi=3&pcm2cms=yes&pl=23&rms=au%2Cau&initcwndbps=508750&bui=AVNa5-w4ERLjEIG8i47HBN4DGSF6LcWcwAEDJPkC8uMI7LgXHtBHf7aNK4-1t02p6Zz048VMbCfMvrdb&spc=6dlaFE-VBUJQtD0amTha7AgIjcRVPXFJzRD6tNHeoHsWb2Mxa2uCJNCc2cENkQ&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=21414715&dur=313.566&lmt=1773012332813809&mt=1773308498&fvip=5&keepalive=yes&fexp=51565116%2C51565681%2C51791334&c=IOS&txp=5535534&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AHEqNM4wRAIgdseO-yOC8nmTDRtk8HXFJ4xhf1N2XQv1XWgJcinT4hoCIDrhBICOerCHNzSOcnHrvdc6yrNACowM68FkLdzzPO91&lsparams=cps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpcm2cms%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRgIhANsvE6wK61nmchC7-zzGhS6Y2vJCx2Braeub553-ZP4hAiEA5hOJ0lRVMBGZ3EaqV1kknVp5JmwdNGcAwxkqDW7kFpU%3D"
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0*   Trying 114.10.0.110:443...
* Connected to rr3---sn-poqvn5u-jb3y.googlevideo.com (114.10.0.110) port 443 (#0)
* ALPN, offering h2
* ALPN, offering http/1.1
*  CAfile: /etc/ssl/certs/ca-certificates.crt
*  CApath: /etc/ssl/certs
* TLSv1.0 (OUT), TLS header, Certificate Status (22):
} [5 bytes data]
* TLSv1.3 (OUT), TLS handshake, Client hello (1):
} [512 bytes data]
  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0* TLSv1.2 (IN), TLS header, Certificate Status (22):
{ [5 bytes data]
* TLSv1.3 (IN), TLS handshake, Server hello (2):
{ [122 bytes data]
* TLSv1.2 (IN), TLS header, Finished (20):
{ [5 bytes data]
* TLSv1.2 (IN), TLS header, Supplemental data (23):
{ [5 bytes data]
* TLSv1.3 (IN), TLS handshake, Encrypted Extensions (8):
{ [6 bytes data]
* TLSv1.3 (IN), TLS handshake, Certificate (11):
{ [4239 bytes data]
* TLSv1.3 (IN), TLS handshake, CERT verify (15):
{ [80 bytes data]
* TLSv1.3 (IN), TLS handshake, Finished (20):
{ [52 bytes data]
* TLSv1.2 (OUT), TLS header, Finished (20):
} [5 bytes data]
* TLSv1.3 (OUT), TLS change cipher, Change cipher spec (1):
} [1 bytes data]
* TLSv1.2 (OUT), TLS header, Supplemental data (23):
} [5 bytes data]
* TLSv1.3 (OUT), TLS handshake, Finished (20):
} [52 bytes data]
* SSL connection using TLSv1.3 / TLS_AES_256_GCM_SHA384
* ALPN, server did not agree to a protocol
* Server certificate:
*  subject: CN=*.googlevideo.com
*  start date: Mar  3 14:30:49 2026 GMT
*  expire date: May 12 14:30:48 2026 GMT
*  subjectAltName: host "rr3---sn-poqvn5u-jb3y.googlevideo.com" matched cert's "*.googlevideo.com"
*  issuer: C=US; O=Google Trust Services; CN=WR2
*  SSL certificate verify ok.
* TLSv1.2 (OUT), TLS header, Supplemental data (23):
} [5 bytes data]
> GET /videoplayback?expire=1773330535&ei=B4yyaaTRLYDg9fwP_K2gwAU&ip=114.10.28.96&id=o-AFM-C8dDK012-HY32DPGZACLlmyJZHYcZvMs-5igyPOH&itag=137&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&cps=542&met=1773308935%2C&mh=jp&mm=31%2C26&mn=sn-poqvn5u-jb3y%2Csn-30a7rne6&ms=au%2Conr&mv=m&mvi=3&pcm2cms=yes&pl=23&rms=au%2Cau&initcwndbps=508750&bui=AVNa5-w4ERLjEIG8i47HBN4DGSF6LcWcwAEDJPkC8uMI7LgXHtBHf7aNK4-1t02p6Zz048VMbCfMvrdb&spc=6dlaFE-VBUJQtD0amTha7AgIjcRVPXFJzRD6tNHeoHsWb2Mxa2uCJNCc2cENkQ&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=21414715&dur=313.566&lmt=1773012332813809&mt=1773308498&fvip=5&keepalive=yes&fexp=51565116%2C51565681%2C51791334&c=IOS&txp=5535534&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AHEqNM4wRAIgdseO-yOC8nmTDRtk8HXFJ4xhf1N2XQv1XWgJcinT4hoCIDrhBICOerCHNzSOcnHrvdc6yrNACowM68FkLdzzPO91&lsparams=cps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpcm2cms%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRgIhANsvE6wK61nmchC7-zzGhS6Y2vJCx2Braeub553-ZP4hAiEA5hOJ0lRVMBGZ3EaqV1kknVp5JmwdNGcAwxkqDW7kFpU%3D HTTP/1.1
> Host: rr3---sn-poqvn5u-jb3y.googlevideo.com
> Accept: /*
> User-Agent: com.google.ios.youtube/20.10.4
> Range: bytes=0-1024
>
* TLSv1.2 (IN), TLS header, Supplemental data (23):
{ [5 bytes data]
* Mark bundle as not supporting multiuse
< HTTP/1.1 206 Partial Content
< Last-Modified: Sun, 08 Mar 2026 23:25:32 GMT
< Content-Type: video/mp4
< Date: Thu, 12 Mar 2026 10:12:03 GMT
< Expires: Thu, 12 Mar 2026 10:12:03 GMT
< Cache-Control: private, max-age=19912
< Content-Range: bytes 0-1024/21414715
< Accept-Ranges: bytes
< Content-Length: 1025
< Connection: keep-alive
< Alt-Svc: h3=":443"; ma=2592000,h3-29=":443"; ma=2592000,h3-Q046=":443"; ma=2592000,quic=":443"; ma=2592000; v="46"
< Vary: Origin
< Cross-Origin-Resource-Policy: cross-origin
< X-Content-Type-Options: nosniff
< Server: gvs 1.0
<
* TLSv1.2 (IN), TLS header, Supplemental data (23):
{ [5 bytes data]
100  1025  100  1025    0     0   2613      0 --:--:-- --:--:-- --:--:--  2614
* Connection #0 to host rr3---sn-poqvn5u-jb3y.googlevideo.com left intact
    // MWEB 2.20260304
    // 21.08.265
    $ANDROID = 'com.google.android.youtube/21.08.265 (Linux; U; Android 14) gzip';
    // 1.65.10
    $ANDROID_VR = 'com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip';
    // 20.10.4
    $IOS = 'com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)';
    
    // WEB 2.20260303 -> MUXED ONLY
    // 7.20250923.13.00
    $TVHTML5 = 'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version';
    // 2.20250925.01.00
    $WEB = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15';
    $SMARTTVUA = 'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.5)';
    
    $desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
    $iPhoneUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1';
    $androidUA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
    $apkUA = 'com.google.android.youtube/19.09.37 (Linux; U; Android 11) gzip';
    $apkUA2 = 'com.google.android.youtube/21.08.265 (Linux; U; Android 12; id_ID; SM-G998B) gzip';
    $smartTvUA= 'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.5)';
            
    YouTube Web	AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8
    YouTube Web Kids	AIzaSyBbZV_fZ3an51sF-mvs5w37OqqbsTOzwtU
    YouTube Web Music	AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30
    YouTube Web Creator	AIzaSyBUPetSUmoZL-OhlxA7wSac5XinrygCqMo
    
    YouTube Android	AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w
    YouTube Android Music	AIzaSyAOghZGza2MQSZkY_zfZ370N-PUdXEo8AI
    YouTube Android Embedded	AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw
    YouTube Android Creator	AIzaSyD_qjV8zaaUMehtLkrKFgVeSX_Iqbtyws8
    
    YouTube IOS	AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc
    YouTube IOS Music	AIzaSyBAETezhkwP0ZWA02RsqT1zu78Fpt0bC_s
    
    public function clientData()
    {
    
        return [
            "client" => [
                [
                    "clientId" => 67,
                    "clientName" => "WEB_REMIX", // sig
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 3,
                    "clientName" => "ANDROID",
                    "clientVersion" => "20.42.40",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 55,
                    "clientName" => "ANDROID_EMBEDDED_PLAYER",
                    "clientVersion" => "17.36.4",
                    "userAgent" => "com.google.android.youtube/17.36.4 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw"
                ],
                [
                    "clientId" => 5,
                    "clientName" => "IOS",
                    "clientVersion" => "17.36.4",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 7,
                    "clientName" => "TVHTML5",
                    "clientVersion" => "7.20220918",
                    "userAgent" => "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0)",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 1,
                    "clientName" => "WEB",
                    "clientVersion" => "2.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 76,
                    "clientName" => "WEB_KIDS",
                    "clientVersion" => "2.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyBbZV_fZ3an51sF-mvs5w37OqqbsTOzwtU"
                ],
                [
                    "clientId" => 31,
                    "clientName" => "WEB_MUSIC_ANALYTICS",
                    "clientVersion" => "1.9",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
                ],
                [
                    "clientId" => 61,
                    "clientName" => "WEB_MUSIC",
                    "clientVersion" => "3.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
                ],
                [
                    "clientId" => 62,
                    "clientName" => "WEB_CREATOR",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyBUPetSUmoZL-OhlxA7wSac5XinrygCqMo"
                ],
                [
                    "clientId" => 41,
                    "clientName" => "WEB_UNPLUGGED",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 42,
                    "clientName" => "WEB_EXPERIMENTS",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 56,
                    "clientName" => "WEB_EMBEDDED_PLAYER",
                    "clientVersion" => "9.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 60,
                    "clientName" => "WEB_HEROES",
                    "clientVersion" => "3.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 69,
                    "clientName" => "WEB_UNPLUGGED_ONBOARDING",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 70,
                    "clientName" => "WEB_UNPLUGGED_OPS",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 71,
                    "clientName" => "WEB_UNPLUGGED_PUBLIC",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 87,
                    "clientName" => "WEB_INTERNAL_ANALYTICS",
                    "clientVersion" => "2.0",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 88,
                    "clientName" => "WEB_PARENT_TOOLS", // muxed
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 90,
                    "clientName" => "WEB_PHONE_VERIFICATION",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 2,
                    "clientName" => "MWEB",
                    "clientVersion" => "2.20220918",
                    "userAgent" => "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 27,
                    "clientName" => "MWEB_TIER_2",
                    "clientVersion" => "9.20220918",
                    "userAgent" => "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 21,
                    "clientName" => "ANDROID_MUSIC",
                    "clientVersion" => "5.26.1",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyAOghZGza2MQSZkY_zfZ370N-PUdXEo8AI"
                ],
                [
                    "clientId" => 14,
                    "clientName" => "ANDROID_CREATOR",
                    "clientVersion" => "22.36.102",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyD_qjV8zaaUMehtLkrKFgVeSX_Iqbtyws8"
                ],
                [
                    "clientId" => 18,
                    "clientName" => "ANDROID_KIDS",
                    "clientVersion" => "7.36.1",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 23,
                    "clientName" => "ANDROID_TV",
                    "clientVersion" => "2.19.1.303051424",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 28,
                    "clientName" => "ANDROID_VR",
                    "clientVersion" => "1.65.10",
                    "userAgent" => "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 29,
                    "clientName" => "ANDROID_UNPLUGGED",
                    "clientVersion" => "6.36",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 30,
                    "clientName" => "ANDROID_TESTSUITE",
                    "clientVersion" => "1.9",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 38,
                    "clientName" => "ANDROID_LITE",
                    "clientVersion" => "3.26.1",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 74,
                    "clientName" => "ANDROID_TV_KIDS",
                    "clientVersion" => "1.19.1",
                    "userAgent" => "com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip",
                    "apiKey" => "AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w"
                ],
                [
                    "clientId" => 26,
                    "clientName" => "IOS_MUSIC",
                    "clientVersion" => "5.26.1",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyBAETezhkwP0ZWA02RsqT1zu78Fpt0bC_s"
                ],
                [
                    "clientId" => 15,
                    "clientName" => "IOS_CREATOR",
                    "clientVersion" => "22.36.102",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 19,
                    "clientName" => "IOS_KIDS",
                    "clientVersion" => "7.36.1",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 33,
                    "clientName" => "IOS_UNPLUGGED",
                    "clientVersion" => "6.36",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 39,
                    "clientName" => "IOS_EMBEDDED_PLAYER",
                    "clientVersion" => "2.4",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 64,
                    "clientName" => "IOS_LIVE_CREATION_EXTENSION",
                    "clientVersion" => "17.36.4",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 66,
                    "clientName" => "IOS_MESSAGES_EXTENSION",
                    "clientVersion" => "17.36.4",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 68,
                    "clientName" => "IOS_UPTIME",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 92,
                    "clientName" => "IOS_PRODUCER",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                    "apiKey" => "AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc"
                ],
                [
                    "clientId" => 8,
                    "clientName" => "TVLITE",
                    "clientVersion" => "2",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 10,
                    "clientName" => "TVANDROID",
                    "clientVersion" => "2",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 13,
                    "clientName" => "XBOXONEGUIDE",
                    "clientVersion" => "2",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 16,
                    "clientName" => "TVAPPLE",
                    "clientVersion" => "22.36.102",
                    "userAgent" => "Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 43,
                    "clientName" => "TVHTML5_CAST",
                    "clientVersion" => "1.1",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 57,
                    "clientName" => "TVHTML5_AUDIO",
                    "clientVersion" => "2.0",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 58,
                    "clientName" => "TV_UNPLUGGED_CAST",
                    "clientVersion" => "2.0",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 59,
                    "clientName" => "TVHTML5_KIDS",
                    "clientVersion" => "3.20220918",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyBbZV_fZ3an51sF-mvs5w37OqqbsTOzwtU"
                ],
                [
                    "clientId" => 63,
                    "clientName" => "TV_UNPLUGGED_ANDROID",
                    "clientVersion" => "1.37",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 65,
                    "clientName" => "TVHTML5_UNPLUGGED",
                    "clientVersion" => "6.36",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 72,
                    "clientName" => "TVHTML5_VR",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 75,
                    "clientName" => "TVHTML5_SIMPLY",
                    "clientVersion" => "1.0",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 77,
                    "clientName" => "MUSIC_INTEGRATIONS",
                    "clientVersion" => "2.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 80,
                    "clientName" => "TVHTML5_YONGLE",
                    "clientVersion" => "2.20220918",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 84,
                    "clientName" => "GOOGLE_ASSISTANT",
                    "clientVersion" => "2.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 85,
                    "clientName" => "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
                    "clientVersion" => "2.0",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyCjc_pVEDi4qsv5MtC2dMXzpIaDoRFLsxw"
                ],
                [
                    "clientId" => 89,
                    "clientName" => "GOOGLE_MEDIA_ACTIONS",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 93,
                    "clientName" => "TVHTML5_FOR_KIDS",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 94,
                    "clientName" => "GOOGLE_LIST_RECS",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ],
                [
                    "clientId" => 95,
                    "clientName" => "MEDIA_CONNECT_FRONTEND",
                    "clientVersion" => "1.20220918",
                    "userAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    "apiKey" => "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
                ]
            ]
        ];
        
    }
    */