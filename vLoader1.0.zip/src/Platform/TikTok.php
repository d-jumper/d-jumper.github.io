<?php

namespace DJumPer\Platform;

use DJumPer\Utils\Utils;
use Exception;

class TikTok
{

    public function scrape($html)
    {

        $platform = 'TikTok'; $title = null; $thumbnail = null;
        $videoUrl = null; $videoUrlNoWm = null; $audioUrl = null;
        $videoWatermark = []; $videoNoWatermark = [];
        $videoQualities = null; $audioQualities = []; $streamingQualities = [];
        $audioAddr = null; //$titleAudio = "TikTok Audio";
        $reason = 'Video tidak dapat diputar (Private/Age Restricted).';
            
        //if (strpos($html, 'verify-container') !== false || strpos($html, 'captcha') !== false) {
            //throw new Exception("Gagal mengambil video. Tunggu beberapa saat, dan coba lagi.");
        //}
        
        if (preg_match('/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application\/json">(.*?)<\/script>/s', $html, $matches)) {
            $allData = json_decode($matches[1], true);
            
            if (json_last_error() === JSON_ERROR_NONE) {
                $base = $allData['__DEFAULT_SCOPE__']['webapp.video-detail'] 
                        ?? $allData['__DEFAULT_SCOPE__']['webapp.reflow-video']
                        ?? $allData['__DEFAULT_SCOPE__']['videoDetail']
                        ?? null;
    
                $itemStruct = $base['itemInfo']['itemStruct'] ?? $base['itemStruct'] ?? null;
                if ($itemStruct) {
                    $videoUrl = $itemStruct['video']['downloadAddr'] ?? null;
                    $videoUrlNoWm = $itemStruct['video']['playAddr'] ?? null;
                    $thumbnail = $itemStruct['video']['originCover'] ?? $itemStruct['video']['cover'] ?? null;
                    $title = $itemStruct['desc'] ?? $title;
                    $audioAddr = $itemStruct['music']['playUrl'] ?? null;
                    //$titleAudio = $itemStruct['music']['title'] ?? $titleAudio;
                }
            }
        }
        if (!$videoUrl) {
            if (preg_match('/"downloadAddr":"([^"]+)"/', $html, $m)) $videoUrl = $m[1];
            if (preg_match('/"playAddr":"([^"]+)"/', $html, $m)) $videoUrlNoWm = $m[1];
            if (preg_match('/"originCover":"([^"]+)"/', $html, $m)) $thumbnail = $m[1];
            if (preg_match('/"desc":"([^"]+)"/', $html, $m)) $title = $m[1];
            if (preg_match('/"playUrl":"([^"]+)"/', $html, $m)) $audioAddr = $m[1];
        }
    
        if ($title === "TikTok Video" && preg_match('/<meta property="og:description" content="([^"]+)"/', $html, $m)) {
            $title = $m[1];
        }
        if (!$thumbnail && preg_match('/<meta property="og:image" content="([^"]+)"/', $html, $m)) {
            $thumbnail = $m[1];
        }
    
        if (!$videoUrl) {
            throw new Exception($platform . ": " . $reason);
        } else {
            $reason = "OK";
            $audioUrl = $audioAddr ?? $videoUrl;
        }
                
        $videoWatermark[] = [
            "itag" => 1,
            "type" => "mp4",
            "qualityLabel" => "Video MP4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎥 720p",
            "url" => Utils::cleanString($videoUrl)
        ];
        $videoNoWatermark[] = [
            "itag" => 2,
            "type" => "mp4",
            "qualityLabel" => "Video MP4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎥 No Watermark",
            "url" => Utils::cleanString($videoUrlNoWm)
        ];
        $videoQualities = array_merge(
            $videoWatermark ?? [],
            $videoNoWatermark ?? []
        );
        $streamingQualities[] = [
            "type" => "mp4",
            "url" => Utils::cleanString($videoUrlNoWm)
        ];
        parse_str(parse_url($audioUrl, PHP_URL_QUERY), $q);
        $bitrate = (int)$q['bitrate'] ?? 1080;
        $bitrate = $bitrate / 1000;
        $audioQualities[] = [
            "itag" => 1,
            "type" => "mp3",
            "qualityLabel" => "Audio MP3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎵 High",
            "url" => Utils::cleanString($audioUrl)
        ];
        
        $title = Utils::cleanString($title);
        return [
            'status' => $reason,
            'platform' => $platform,
            'title' => Utils::limitString($title, 100),
            'thumbnail' => Utils::cleanString($thumbnail),
            'streaming_data' => $streamingQualities,
            'video_data' => $videoQualities,
            'audio_data' => $audioQualities
        ];
                
    }
    
}