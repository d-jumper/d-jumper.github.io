<?php

/**
 * AUTHENTICATION & ROUTING
 */
if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

$page = $_GET['page'] ?? 'home';
if ($_SESSION['role'] === 'user') {
    $page = 'manage';
    $_GET['id'] = $_SESSION['id_user'];
} else if ($_SESSION['role'] === 'root' && $page === 'manage' && !isset($_GET['id'])) {
    echo "<script>window.location.href=?page=domains&status=danger&msg=Pilih+user+terlebih+dahulu.";
    exit();
}

$user_target ="";
$back_button = "?page=home";

function getInstalledPHPVersions() {
    $versions = [];
    $path = '/etc/php/';
    
    if (is_dir($path)) {
        // Menggunakan glob untuk list folder yang hanya berisi angka/titik
        $dirs = glob($path . '*', GLOB_ONLYDIR);
        foreach ($dirs as $dirPath) {
            $v = basename($dirPath);
            // Cek apakah folder tersebut versi PHP (contoh: 7.4, 8.1)
            if (preg_match('/^[0-9.]+$/', $v)) {
                // Pastikan fpm socket atau binary-nya ada
                if (is_dir($dirPath . '/fpm') || is_dir($dirPath . '/cli')) {
                    $versions[] = $v;
                }
            }
        }
    }
    
    if (empty($versions)) {
        $cmd = "ls /etc/php/ 2>/dev/null";
        $output = shell_exec($cmd);
        if ($output) {
            $lines = explode("\n", trim($output));
            foreach ($lines as $line) {
                if (preg_match('/^[0-9.]+$/', trim($line))) {
                    $versions[] = trim($line);
                }
            }
        }
    }

    sort($versions);
    return array_unique($versions);
}
$available_php = getInstalledPHPVersions();

function getActivePHPVersion($user_target) {
    $vhost_file = "/etc/apache2/sites-available/$user_target.conf";
    if (file_exists($vhost_file)) {
        $content = file_get_contents($vhost_file);
        if (preg_match('/php([0-9.]+)-fpm\.sock/', $content, $matches)) {
            return $matches[1];
        }
    }
    return null;
}
$current_active_v = getActivePHPVersion($user_target);

// --- LOGIKA 1: SET PHP INSTALL ---
if (isset($_POST['set_php_vhost'])) {
    // Pastikan koneksi DB tersedia, jika tidak sertakan file koneksi Anda
    // include_once('../includes/db.php'); 

    $v_selected = preg_replace('/[^0-9.]/', '', $_POST['php_vhost']);
    
    // 1. Cek apakah versi sudah terinstall
    if (!in_array($v_selected, $available_php)) {
        // Proses instalasi (tambahkan output redirect agar user tahu proses berjalan)
        shell_exec("sudo add-apt-repository -y ppa:ondrej/php > /dev/null 2>&1");
        shell_exec("sudo apt-get update > /dev/null 2>&1");
        
        // Jalankan install di background agar tidak timeout, atau biarkan sinkron jika spek server kuat
        $install_cmd = "sudo apt-get install -y php$v_selected-fpm php$v_selected-mysql php$v_selected-curl php$v_selected-gd php$v_selected-mbstring php$v_selected-xml php$v_selected-zip php$v_selected-bcmath > /dev/null 2>&1";
        shell_exec($install_cmd);
    }
}

?>

    <div class="plesk-card-header p-3 border-bottom d-flex justify-content-between align-items-center">
        <span class="fw-bold"></span>
        <div class="d-flex gap-2">
            <a href="<?php echo $back_button; ?>" class="btn btn-sm btn-outline-secondary">Kembali</a>
        </div>
    </div>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h6 class="text-muted fw-bold mb-0"><i class="bi bi-cpu-fill me-2 text-primary"></i>New Page</h6>
    </div>
    
    <div class="col-md-12">
        <div class="row g-4 text-dark">
        
            <div class="col-md-6">
                <div class="plesk-card h-100">
                    <div class="card shadow-sm border-0">
                        <div class="card-header bg-white fw-bold">
                            <i class="bi bi-download"></i> Install Node.js
                        </div>
                        <div class="card-body">
                            <form id="installForm">
                                <label class="small text-muted mb-2"></label>
                                <label class="form-label small fw-bold">
                                    <i class="bi bi-check2-circle me-1"></i> Versi Node (Contoh: 20)
                                </label>
                                <div class="input-group">
                                    <input type="number" name="install_version" id="install_version" class="form-control" placeholder="Versi" required>
                                    <button type="submit" name="installnodejs" class="btn btn-primary">Install</button>
                                </div>
                                <div class="form-text mt-2 small">Menggunakan NVM untuk instalasi sistem.</div>
                                
                                <div id="prog_box_global_node" class="mt-4 d-none">
                                    <div class="d-flex justify-content-between mb-1 small">
                                        <span id="npm_stat_global_node" class="text-muted">Menghubungkan...</span>
                                        <span id="npm_perc_global_node" class="fw-bold text-primary">0%</span>
                                    </div>
                                    <div class="progress" style="height: 8px;">
                                        <div id="npm_bar_global_node" class="progress-bar progress-bar-striped progress-bar-animated bg-primary" style="width: 0%"></div>
                                    </div>
                                    <pre id="node-install-log" class="bg-black text-success p-2 mt-2 rounded border" style="max-height: 100px; overflow-y: auto; font-size: 10px; font-family: monospace;"></pre>
                                </div>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="plesk-card h-100">
                    <div class="card shadow-sm border-0">
                        <div class="card-header bg-white fw-bold">
                            <i class="bi bi-layers-half me-2"></i> PHP Version Handler
                        </div>
                        <div class="card-body">
                            <form method="POST" class="row g-3 align-items-end">
                                <label class="form-label small fw-bold">
                                    <i class="bi bi-check2-circle me-1"></i> Pilih Versi PHP
                                </label>
                                <div class="input-group">
                                    <select name="php_vhost" class="form-select">
                                        <optgroup label="Sudah Terinstall">
                                            <?php foreach($available_php as $v): ?>
                                                <option value="<?php echo $v; ?>" <?php echo ($current_active_v == $v) ? 'selected' : ''; ?>>
                                                    PHP v<?php echo $v; ?> <?php echo ($current_active_v == $v) ? '(Aktif)' : ''; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                        <optgroup label="Tersedia untuk Diinstall">
                                            <?php 
                                            $repo = ['5.6', '7.4', '8.0', '8.1', '8.2', '8.3'];
                                            foreach($repo as $r) {
                                                // Hanya tampilkan jika belum terinstall
                                                if(!in_array($r, $available_php)) {
                                                    echo "<option value='$r'>Install PHP $r</option>";
                                                }
                                            }
                                            ?>
                                        </optgroup>
                                    </select>
                                    <button name="set_php_vhost" class="btn btn-primary"></i> Install PHP</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>