<?php
// Pastikan hanya user yang diizinkan yang mengakses log ini jika perlu
// node-manager/get_logs.php
$name = isset($_GET['name']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['name']) : '';
if ($name) {
    $raw_log = shell_exec("sudo pm2 logs " . escapeshellarg($name) . " --lines 20 --nostream --raw 2>&1");
    if (empty($raw_log)) {
        echo "No logs available. Application might be stopped.";
    } else {
        $clean_log = preg_replace('/^\[TAILING\].*$/m', '', $raw_log);
        $clean_log = preg_replace('/^\/root\/.pm2\/logs\/.*$/m', '', $clean_log);
        echo trim($clean_log);
    }
}

?>