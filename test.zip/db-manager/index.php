<?php
require_once("../config.php");
session_start();

// Proteksi Halaman
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'root') {
    header("Location: ../index.php");
    exit();
}

// Ambil User Target dari URL
$user_target = isset($_GET['db']) ? preg_replace('/[^a-z0-9]/', '', $_GET['db']) : '';
if (empty($user_target)) {
    die("Error: Parameter User tidak ditemukan.");
}

// Ambil detail user dari database untuk ditampilkan di header
$stmt = $conn->prepare("SELECT db FROM db_users WHERE db = ?");
$stmt->bind_param("s", $user_target);
$stmt->execute();
$user_info = $stmt->get_result()->fetch_assoc();

if (!$user_info) {
    die("Error: Data user tidak ditemukan di database.");
}

require_once("../lib/header.php"); 
?>

<style>
    .plesk-menu-card {
        transition: all 0.2s ease-in-out;
        border: 1px solid #e1e4e8;
        border-radius: 8px;
        background: #fff;
        height: 100%;
        text-decoration: none;
        color: inherit;
        display: flex;
        flex-direction: column;
        padding: 20px;
    }
    .plesk-menu-card:hover {
        border-color: #00a8e0;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        transform: translateY(-2px);
        color: inherit;
    }
    .plesk-menu-card i {
        font-size: 2.5rem;
        margin-bottom: 15px;
    }
    .icon-files { color: #f39c12; }
    .icon-db { color: #3498db; }
    .icon-php { color: #8e44ad; }
    .icon-node { color: #2ecc71; }
    .icon-sec { color: #e74c3c; }
    .icon-log { color: #7f8c8d; }
</style>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item"><a href="../dashboard.php">Dashboard</a></li>
                    <li class="breadcrumb-item active"><?php echo $user_info['domain']; ?></li>
                </ol>
            </nav>
            <h4 class="fw-bold m-0"><i class="bi bi-globe2 me-2 text-primary"></i> Hosting Settings: <?php echo $user_info['username']; ?></h4>
        </div>
        <div class="text-end">
            <span class="badge bg-success mb-1">Active</span>
            <div class="small text-muted">IP Address: <?php echo $_SERVER['SERVER_ADDR']; ?></div>
        </div>
    </div>

    <div class="plesk-card mb-4">
        <div class="p-3 bg-light d-flex gap-4 border-bottom">
            <div class="small"><strong>Document Root:</strong> <code>/var/www/html/<?php echo $user_target; ?></code></div>
            <div class="small"><strong>System User:</strong> <code><?php echo $user_target; ?></code></div>
            <div class="small"><strong>Port:</strong> <code><?php echo $user_info['port']; ?></code></div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-6 col-md-4 col-lg-3">
            <a href="../file-manager/index.php?user=<?php echo $user_target; ?>" class="plesk-menu-card text-center">
                <i class="bi bi-folder2-open icon-files"></i>
                <h6 class="fw-bold mb-1">File Manager</h6>
                <p class="small text-muted m-0">Upload, edit, dan kelola file website.</p>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-3">
            <a href="../database-manager/index.php?user=<?php echo $user_target; ?>" class="plesk-menu-card text-center">
                <i class="bi bi-database-fill icon-db"></i>
                <h6 class="fw-bold mb-1">Databases</h6>
                <p class="small text-muted m-0">Kelola tabel MySQL dan phpMyAdmin.</p>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-3">
            <a href="../php-manager/index.php?user=<?php echo $user_target; ?>" class="plesk-menu-card text-center">
                <i class="bi bi-filetype-php icon-php"></i>
                <h6 class="fw-bold mb-1">PHP Settings</h6>
                <p class="small text-muted m-0">Ganti versi PHP dan konfigurasi .ini.</p>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-3">
            <a href="../node-version-manager/index.php?user=<?php echo $user_target; ?>" class="plesk-menu-card text-center">
                <i class="bi bi-hexagon-fill icon-node"></i>
                <h6 class="fw-bold mb-1">Node.js Manager</h6>
                <p class="small text-muted m-0">Kelola bot atau aplikasi backend Node.js.</p>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-3">
            <a href="#" class="plesk-menu-card text-center">
                <i class="bi bi-shield-lock-fill icon-sec"></i>
                <h6 class="fw-bold mb-1">SSL/TLS Certificates</h6>
                <p class="small text-muted m-0">Pasang Let's Encrypt atau SSL Custom.</p>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-3">
            <a href="#" class="plesk-menu-card text-center">
                <i class="bi bi-journal-text icon-log"></i>
                <h6 class="fw-bold mb-1">Logs Viewer</h6>
                <p class="small text-muted m-0">Pantau Access Log dan Error Log Apache.</p>
            </a>
        </div>

        <div class="col-6 col-md-4 col-lg-3">
            <a href="http://<?php echo $user_info['domain']; ?>:<?php echo $user_info['port']; ?>" target="_blank" class="plesk-menu-card text-center">
                <i class="bi bi-box-arrow-up-right text-dark"></i>
                <h6 class="fw-bold mb-1">Open Website</h6>
                <p class="small text-muted m-0">Buka domain di tab browser baru.</p>
            </a>
        </div>
    </div>

    <div class="mt-5 p-4 bg-white border rounded shadow-sm">
        <h6 class="fw-bold"><i class="bi bi-info-circle me-2"></i> Petunjuk Penggunaan</h6>
        <p class="small text-muted mb-0">
            Halaman ini adalah pusat kendali untuk domain <strong><?php echo $user_info['domain']; ?></strong>. 
            Semua perubahan yang dilakukan melalui menu di atas hanya akan berdampak pada user <strong><?php echo $user_target; ?></strong>. 
            Pastikan untuk selalu melakukan backup database sebelum melakukan perubahan besar.
        </p>
    </div>
</div>

<?php require_once("../lib/footer.php"); ?>