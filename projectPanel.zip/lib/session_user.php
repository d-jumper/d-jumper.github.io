<?php

if ($_SESSION['role'] === 'user') {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id_session, $user_session);
} else if ($_SESSION['role'] === 'admin') {
    $id_user = isset($_GET['id']) ? (int)$_GET['id'] : 0;    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id_user);
}
    $stmt->execute();
    $res_user = $stmt->get_result();
    if($data_users = $res_user->fetch_assoc()){
        $id_user = $data_users['id'];
        $stmt2 = $conn->prepare("SELECT * FROM data_website WHERE user_id = ?");
        $stmt2->bind_param("i", $id_user);
        $stmt2->execute();
        $res_user2 = $stmt2->get_result();
        if(!$data_website = $res_user2->fetch_assoc()){
            header("Location: dashboard.php?page=domains");
            exit();
        }
    } else {
        header("Location: dashboard.php?page=domains");
        exit();
    }
    
    // Data User :
    $id_user = $data_users['id'];
    $username_user = $data_users['username'];
    $email_user = $data_users['email'];
    $type_server = $data_website['type_server'];
    $domain_user = $data_website['domain'];
    $type_domain = $data_website['type_domain'];
    $php_v_user = $data_website['php_version'];
    $path_user = $data_website['path_web'];
    
    /**
    * PARAMETER
    **/
    $base_page = $page ?? '';
    $base_subpage = $subpage ?? '';
    $base_extensions = $_GET['extensions'] ?? '';
    $user_manage_url = "?page=$base_page&subpage=$base_subpage&id=$id_user";
    $current_url = "?page=$base_page&subpage=$base_subpage&extensions=$base_extensions&id=$id_user";
    $fetch_url = $current_url . "&user=$username_user&path_user=$path_user&domain=$domain_user&php_version=$php_v_user";
    $msg = "";
    
    $alias_php = "/usr/bin/php" . $php_v_user;
    $alias_composer = "export PHP_BINARY=$alias_php && alias php=$alias_php && $alias_php $path_composer";
    
?>