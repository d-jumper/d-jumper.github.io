</div>

<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>

<script>
function toggleDomainInputs(val) {
    const subDiv = document.getElementById('input_subdomain');
    const customDiv = document.getElementById('input_custom');
    
    // Sembunyikan semua dulu
    if(subDiv) subDiv.classList.add('d-none');
    if(customDiv) customDiv.classList.add('d-none');
    
    // Tampilkan yang dipilih
    if (val === 'subdomain' && subDiv) {
        subDiv.classList.remove('d-none');
    } else if (val === 'custom' && customDiv) {
        customDiv.classList.remove('d-none');
    }
}
/*function toggleSubInput() {
    const selector = document.getElementById('domainTypeSelector');
    const div = document.getElementById('subPrefixDiv');
    if(selector.value === 'subdomain') div.classList.remove('d-none');
    else div.classList.add('d-none');
}*/
</script>

<script>
    function toggleSidebarDesktop() {
        document.body.classList.toggle('sidebar-toggled');
    }
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>