<?php
/**
Example :

## BACKEND
if (isset($_POST['action_with_progress'])) {
    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json');
    
    $log_file = "/var/www/control-panel.localhost/progress.log"; 
    file_put_contents($log_file, "Initializing\n");
    chmod($log_file, 0666);
    
    $cmd = "cd /var/www/control-panel.localhost/ && (" .
        "echo 'Initializing' > " . escapeshellarg($log_file) . " && " . 
        "sleep 1 && " .
        "echo 'Processing' >> " . escapeshellarg($log_file) . " && " . 
        "(sudo apt update >> /dev/null 2>&1 || (echo 'ERROR: apt update failed!' >> " . escapeshellarg($log_file) . " && exit 1)) && " .
        "echo 'Finish' >> " . escapeshellarg($log_file) . " && " . 
        "sleep 1 && " .
        "echo 'Completed' >> " . escapeshellarg($log_file) . 
        ") > /dev/null 2>&1 &";
    shell_exec($cmd);
        
    echo json_encode(['status' => 'started']);
    exit();
}

if (isset($_GET['read_log'])) {
    while (ob_get_level()) { ob_end_clean(); }
    $log_path = "/var/www/control-panel.localhost/progress.log";
    if (file_exists($log_path)) {
        $content = file_get_contents($log_path);
        $is_done = (strpos($content, 'Completed') !== false);
        $lines = explode("\n", $content);
        $output = nl2br(htmlspecialchars(implode("\n", array_slice($lines, -20))));
        echo json_encode(['log' => $output, 'done' => $is_done]);
        if ($is_done) {
            unlink($log_path);
        }
    } else {
        echo json_encode(['log' => 'Waiting for log...', 'done' => false]);
    }
    exit();
}

## FRONTED
    <form method="POST" id="id_form">
        <button class="btn btn-primary btn-sm w-100"
            type="submit"
            name="example_button" 
            data-bs-toggle="modal"
            data-bs-target="#progressModal" 
            onclick="progressAction()">
            Submit
        </button>
    </form>
**/
?>

    <div class="modal fade" id="progressModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4">
                <div id="progress_container" class="modal-body p-0">
                    <div class="card border-0 shadow-sm rounded-4 border-top border-4 mb-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-1">
                                <small id="prog_label" class="fw-bold text-muted"></small>
                                <small id="prog_perc" class="badge bg-primary">0%</small>
                            </div>
                            <div class="progress" style="height: 10px; border-radius: 10px;">
                                <div id="prog_bar" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <div id="status-checklist">
                                <div class="d-flex align-items-center mb-3 text-muted" id="step-1">
                                    <i class="bi bi-circle me-3 icon-status" id="icon-1"></i>
                                    <span>Initializing</span>
                                    <small class="ms-auto status-text">Pending</small>
                                </div>
                                <div class="d-flex align-items-center mb-3 text-muted" id="step-2">
                                    <i class="bi bi-circle me-3 icon-status" id="icon-2"></i>
                                    <span>Processing</span>
                                    <small class="ms-auto status-text">Pending</small>
                                </div>
                                <div class="d-flex align-items-center mb-3 text-muted" id="step-3">
                                    <i class="bi bi-circle me-3 icon-status" id="icon-3"></i>
                                    <span>Finalizing Process</span>
                                    <small class="ms-auto status-text">Pending</small>
                                </div>
                                <div class="d-flex align-items-center text-muted" id="step-finish">
                                    <i class="bi bi-circle me-3 icon-status" id="icon-finish"></i>
                                    <span>Completed</span>
                                    <small class="ms-auto status-text">Pending</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
let logInterval;
function progressAction(formElement) {
    if (formElement.dataset.hasHandler) return;
    formElement.dataset.hasHandler = 'true';
    
    formElement.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const btn = e.submitter;
        if(!btn) return;
        const buttonName = btn.name;
        btn.disabled = true;
        
        resetChecklist();
                
        const formData = new FormData(this);
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        formData.append('csrf_token', csrfToken);
        formData.append('action_with_progress', '1');
    
        fetch(window.location.href, { 
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 'started') {
                startPolling(buttonName);
            } else {
                btn.disabled = false;
            }
        })
        .catch(err => {
            console.error("Error:", err);
            btn.disabled = false;
        });
    });
}
function startPolling(buttonName) {
    if (logInterval) clearInterval(logInterval);
    const container = document.getElementById('progress_container');
    container.classList.remove('d-none');
    resetChecklist();
    
    updateStep('step-1', 'loading');
    updateBar(10, 'Starting system...');

    let lastStatus = "";
    let url = new URL(window.location.href);
    url.searchParams.set('read_log', '1');
    
    logInterval = setInterval(() => {
        fetch(url)
        .then(res => res.json())
        .then(data => {
            const rawLog = data.log;

            // --- LOGIKA DETEKSI ERROR ---
            if (rawLog.toUpperCase().includes('ERROR')) {
                clearInterval(logInterval);
                logInterval = null;
                const errorMatch = rawLog.split('<br />').find(line => line.toUpperCase().includes('ERROR'));
                handleUIError(buttonName, errorMatch);
                return;
            }

            // Tahap 1: Initializing
            if (rawLog.includes('Initializing') && lastStatus !== "Initializing") {
                updateBar(25, 'Initializing environment...');
                lastStatus = "Initializing";
            }

            // Tahap 2: Processing
            if (rawLog.includes('Processing') && lastStatus !== "Processing") {
                updateStep('step-1', 'done');
                updateStep('step-2', 'loading');
                updateBar(50, 'Processing...');
                lastStatus = "Processing";
            }

            // Tahap 3: Finish
            if (rawLog.includes('Finish') && lastStatus !== "Finish") {
                updateStep('step-2', 'done');
                updateStep('step-3', 'loading');
                updateBar(85, 'Finish...');
                lastStatus = "Finish";
            }

            // Tahap 4: Completed
            if (data.done === true) {
                clearInterval(logInterval);
                logInterval = null;
                updateStep('step-3', 'done');
                updateStep('step-finish', 'done');
                updateBar(100, 'All tasks completed successfully!');
                
                const progBar = document.getElementById('prog_bar');
                progBar.classList.remove('progress-bar-animated', 'progress-bar-striped');
                progBar.classList.add('bg-success');
                
                updateTable();
                resetSubmitButton(buttonName);
            }
        });
    }, 1000);
}
function handleUIError(buttonName, message) {
    if (logInterval) {
        clearInterval(logInterval);
        logInterval = null;
    }
    const progBar = document.getElementById('prog_bar');
    const progLabel = document.getElementById('prog_label');
    
    progBar.classList.remove('progress-bar-animated', 'bg-primary');
    progBar.classList.add('bg-danger');
    progBar.style.width = '100%';
    progLabel.innerText = "Error Detected!";
    progLabel.classList.replace('text-muted', 'text-danger');

    updateStep('step-1', 'error');
    updateStep('step-2', 'error');
    updateStep('step-3', 'error');
    updateStep('step-finish', 'error');
    updateBar(100, message.replace(/<br\s*\/?>/gi, ' '));
    resetSubmitButton(buttonName);
}
function resetSubmitButton(buttonName) {
    const btn = document.querySelector(`button[name="${buttonName}"]`);
    btn.disabled = false;
}
function updateStep(stepId, status) {
    const el = document.getElementById(stepId);
    const icon = document.getElementById('icon-' + stepId.split('-')[1]);
    const text = el.querySelector('.status-text');

    if (status === 'loading') {
        el.classList.remove('text-muted');
        el.classList.add('step-active');
        icon.className = 'spinner-step me-3 text-info';
        text.innerText = 'Processing...';
    } else if (status === 'done') {
        el.classList.remove('step-active', 'text-muted');
        el.classList.add('step-completed');
        icon.className = 'bi bi-check-circle-fill me-3 text-success';
        text.innerText = 'Done';
    } else if (status === 'error') {
        el.classList.remove('step-active', 'text-danger');
        el.classList.add('step-error');
        icon.className = 'bi bi-exclamation-triangle me-3 text-danger';
        text.innerText = 'Failed';
    }
}
function updateBar(val, label) {
    document.getElementById('prog_bar').style.width = val + '%';
    document.getElementById('prog_perc').innerText = val + '%';
    if(label) document.getElementById('prog_label').innerText = label;
}
function resetChecklist() {
    const steps = ['step-1', 'step-2', 'step-3', 'step-finish'];
    steps.forEach(s => {
        const el = document.getElementById(s);
        const icon = document.getElementById('icon-' + s.split('-')[1]);
        el.className = 'd-flex align-items-center mb-3 text-muted';
        icon.className = 'bi bi-circle me-3';
        el.querySelector('.status-text').innerText = 'Pending';
    });
    const progBar = document.getElementById('prog_bar');
    progBar.style.width = '0%';
    progBar.classList.add('progress-bar-animated');
    progBar.classList.remove('bg-success', 'bg-danger');
    const progLabel = document.getElementById('prog_label');
    progLabel.classList.remove('text-danger', 'text-success', 'text-info', 'text-primary');
    progLabel.classList.add('text-muted');
    updateBar(0, '');
}
function updateTable() {
    fetch(window.location.href)
    .then(res => res.text())
    .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        //const newBodyContent = doc.querySelector('body').innerHTML;
        //document.body.innerHTML = newBodyContent;
        //document.querySelector('tbody').innerHTML = doc.querySelector('tbody').innerHTML;
        const newTbody = doc.querySelector('tbody');
        if (newTbody) {
            document.querySelector('tbody').innerHTML = newTbody.innerHTML;;
        }
    });
}
</script>