<?php
ob_start(); 
/**
 * DATABASE MANAGER ULTIMATE - Full Controller with phpMyAdmin Link
 * Path: db-manager/index.php
 */

/**
 * AUTHENTICATION & ROUTING
 */
if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

if ($_SESSION['role'] === 'root') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $user_target = isset($_GET['user']) ? preg_replace('/[^a-z0-9]/', '', $_GET['user']) : '';
    if (empty($user_target)) { $user_target = $_SESSION['user']; }
} else {
    $id = (int)$_SESSION['id_user'];
    $user_target = $_SESSION['username_user'];
}

// Ubah path ini sesuai dengan folder instalasi phpMyAdmin Anda
$pma_base_url = "/phpmyadmin/"; 
$pma_full_url = $pma_base_url . "index.php"; 

// State Management URL
$base_param = "page=manage&id=$id&subpage=database&user=$user_target";
$current_url = "?$base_param";
$user_manage_url = "?page=manage&id=$id";

// --- LOGIKA BACKEND ---

// A. Fitur Maintenance: Optimize & Repair
if (isset($_GET['action_db']) && isset($_GET['db_name'])) {
    $db_name = preg_replace('/[^a-z0-9_]/', '', $_GET['db_name']);
    $action = ($_GET['action_db'] === 'optimize') ? 'OPTIMIZE' : 'REPAIR'; 
    
    if (strpos($db_name, $user_target . "_") === 0) {
        // Gunakan mysqli_real_escape_string untuk nama tabel di dalam loop
        $tables_res = mysqli_query($conn, "SHOW TABLES FROM `$db_name`");
        while ($t = mysqli_fetch_array($tables_res)) {
            $table = $t[0];
            mysqli_query($conn, "$action TABLE `$db_name`.`$table`");
        }
        $msg = ($action === 'optimize' ? "Optimasi" : "Perbaikan") . " selesai untuk $success_count tabel.";
        echo "<script>window.location.href='$current_url&status=success&msg=" . urlencode($msg) . "';</script>";
    }
}

// B. Export Database
if (isset($_GET['export_db'])) {
    $db_name = $_GET['export_db'];
    if (strpos($db_name, $user_target . "_") === 0) {
        $filename = $db_name . "_" . date('Y-m-d') . ".sql";
        header('Content-Type: application/octet-stream');
        header("Content-disposition: attachment; filename=\"$filename\"");
        l
        $cmd = sprintf(
            "mysqldump -u %s -p%s %s",
            escapeshellarg($db_config['user']),
            escapeshellarg($db_config['pass']),
            escapeshellarg($db_name)
        );
        passthru($cmd);
        echo "<script>window.location.href='$current_url&status=success&msg=Database+telah+diexport';</script>";
        exit;
    }
}

// C. Tambah Database & User
if (isset($_POST['create_db'])) {
    $db_name = $user_target . "_" . preg_replace('/[^a-z0-9_]/', '', $_POST['db_name']);
    $db_user = $user_target . "_" . preg_replace('/[^a-z0-9_]/', '', $_POST['db_user']);
    $db_pass = mysqli_real_escape_string($conn, $_POST['db_pass']);

    $queries = [
        "CREATE DATABASE IF NOT EXISTS `$db_name`",
        "CREATE USER IF NOT EXISTS '$db_user'@'localhost' IDENTIFIED BY '$db_pass'",
        "GRANT ALL PRIVILEGES ON `$db_name`.* TO '$db_user'@'localhost'",
        "FLUSH PRIVILEGES"
    ];

    foreach ($queries as $q) { mysqli_query($conn, $q); }
    echo "<script>window.location.href='$current_url&status=success&msg=Database+berhasil+dibuat';</script>";
    exit;
}

// D. Ganti Password User DB
if (isset($_POST['change_pass_db'])) {
    $db_user = mysqli_real_escape_string($conn, $_POST['db_user']);
    $new_pass = mysqli_real_escape_string($conn, $_POST['new_pass']);
    if (strpos($db_user, $user_target . "_") === 0) {
        mysqli_query($conn, "ALTER USER '$db_user'@'localhost' IDENTIFIED BY '$new_pass'");
        echo "<script>window.location.href='$current_url&status=success&msg=Password+user+berhasil+diperbarui';</script>";
    }
    exit;
}

// E. Import Database
if (isset($_POST['import_db'])) {
    $db_name = mysqli_real_escape_string($conn, $_POST['target_db']);
    if (strpos($db_name, $user_target . "_") === 0 && isset($_FILES['sql_file'])) {
        $tmp_file = $_FILES['sql_file']['tmp_name'];
        $cmd = "mysql -u " . escapeshellarg($db_config['user']) . " -p" . escapeshellarg($db_config['pass']) . " " . escapeshellarg($db_name) . " < " . escapeshellarg($tmp_file);
        shell_exec($cmd);
        echo "<script>window.location.href='$current_url&status=success&msg=Restore+database+selesai';</script>";
    }
    exit;
}

// F. Hapus Database
if (isset($_GET['delete_db'])) {
    $db_to_delete = mysqli_real_escape_string($conn, $_GET['delete_db']);
    if (strpos($db_to_delete, $user_target . "_") === 0) {
        mysqli_query($conn, "DROP DATABASE `$db_to_delete`");
        mysqli_query($conn, "DROP USER IF EXISTS '$db_to_delete'@'localhost'");
        echo "<script>window.location.href='$current_url&status=success&msg=Database+dihapus';</script>";
    }
    exit;
}

// G. Fetch List
$db_list = [];
$res = mysqli_query($conn, "SHOW DATABASES LIKE '{$user_target}\_%'");
while ($row = mysqli_fetch_array($res)) {
    $name = $row[0];
    $stats = mysqli_query($conn, "SELECT COUNT(*) as tbl_count, SUM(DATA_LENGTH + INDEX_LENGTH) as total_size, SUM(TABLE_ROWS) as row_count FROM information_schema.TABLES WHERE TABLE_SCHEMA = '$name'");
    $s = mysqli_fetch_assoc($stats);
    $user_res = mysqli_query($conn, "SELECT USER FROM mysql.db WHERE Db = '$name' LIMIT 1");
    $u = mysqli_fetch_assoc($user_res);
    
    $db_list[] = [
        'name' => $name,
        'user' => $u['USER'] ?? 'N/A',
        'tables' => $s['tbl_count'] ?? 0,
        'rows' => $s['row_count'] ?? 0,
        'size' => number_format(($s['total_size'] ?? 0) / 1024 / 1024, 2) . " MB"
    ];
}
?>

<div class="container mt-4 pb-5">
    <div class="d-flex justify-content-between align-items-center mb-4 p-4 bg-white rounded-4 shadow-sm border-bottom border-primary border-3">
        <div>
            <h4 class="fw-bold mb-1 text-dark"><i class="bi bi-layers-half me-2"></i>Database Manager Pro</h4>
            <p class="text-muted small mb-0">User: <span class="badge bg-primary-subtle text-primary"><?= htmlspecialchars($user_target) ?></span></p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= $pma_full_url ?>" target="_blank" class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i> Buka phpMyAdmin
            </a>
            <button class="btn btn-outline-success btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#modalImport">
                <i class="bi bi-cloud-arrow-up me-1"></i> Import SQL
            </button>
            <a href="<?= $user_manage_url; ?>" class="btn btn-dark btn-sm rounded-pill px-3">Kembali</a>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-xl-9 col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 text-nowrap">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted small text-uppercase">
                                <tr>
                                    <th class="ps-4 py-3">Database</th>
                                    <th>User & Stats</th>
                                    <th class="text-center">Size</th>
                                    <th class="text-end pe-4">Aksi Cepat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($db_list)): ?>
                                    <tr><td colspan="4" class="text-center py-5">Belum ada database untuk user ini.</td></tr>
                                <?php else: foreach($db_list as $db): ?>
                                    <tr>
                                        <td class="ps-4">
                                            <div class="fw-bold text-dark"><?= $db['name'] ?></div>
                                            <div class="small text-muted italic"><?= $db['tables'] ?> Tabel | <?= number_format($db['rows']) ?> Baris</div>
                                        </td>
                                        <td>
                                            <span class="badge bg-info-subtle text-info border border-info-subtle mb-1">
                                                <i class="bi bi-person me-1"></i><?= $db['user'] ?>
                                            </span>
                                        </td>
                                        <td class="text-center fw-medium text-secondary"><?= $db['size'] ?></td>
                                        <td class="text-end pe-4">
                                            <div class="btn-group shadow-sm rounded-3 overflow-hidden border">                                                
                                                <a href="<?= $current_url ?>&export_db=<?= $db['name'] ?>" class="btn btn-sm btn-white text-success" title="Backup .sql">
                                                    <i class="bi bi-download"></i>
                                                </a>
                                                
                                                <a href="<?= $current_url ?>&action_db=optimize&db_name=<?= $db['name'] ?>" class="btn btn-sm btn-white text-info" title="Optimasi">
                                                    <i class="bi bi-lightning-auto"></i>
                                                </a>
                                                
                                                <button type="button" onclick="modalPass('<?= $db['user'] ?>')" class="btn btn-sm btn-white text-warning" title="Ubah Password User">
                                                    <i class="bi bi-key"></i>
                                                </button>
                                                
                                                <a href="<?= $current_url ?>&delete_db=<?= $db['name'] ?>" class="btn btn-sm btn-white text-danger" onclick="return confirm('Hapus database permanen?')" title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 border-top border-primary border-4 mb-4">
                <div class="card-body">
                    <h6 class="fw-bold mb-3"><i class="bi bi-plus-circle me-2"></i>Database Baru</h6>
                    <form method="POST">
                        <div class="mb-2">
                            <label class="small text-muted fw-bold">Nama DB</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text"><?= $user_target ?>_</span>
                                <input type="text" name="db_name" class="form-control" required placeholder="data">
                            </div>
                        </div>
                        <div class="mb-2">
                            <label class="small text-muted fw-bold">User DB</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text"><?= $user_target ?>_</span>
                                <input type="text" name="db_user" class="form-control" required placeholder="user">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="small text-muted fw-bold">Password</label>
                            <div class="input-group input-group-sm">
                                <input type="password" name="db_pass" id="db_pass_main" class="form-control" required>
                                <button class="btn btn-outline-secondary" type="button" onclick="genPass('db_pass_main')"><i class="bi bi-shuffle"></i></button>
                            </div>
                        </div>
                        <button type="submit" name="create_db" class="btn btn-primary btn-sm w-100 rounded-pill fw-bold">Deploy Sekarang</button>
                    </form>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="modal fade" id="modalPass" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form method="POST">
                <div class="modal-body p-4 text-center">
                    <div class="bg-warning-subtle text-warning rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                        <i class="bi bi-shield-lock fs-4"></i>
                    </div>
                    <h6 class="fw-bold">Update Password</h6>
                    <p class="small text-muted mb-3">User: <span id="display_user_pass" class="fw-bold text-primary"></span></p>
                    <input type="hidden" name="db_user" id="pass_db_user">
                    
                    <div class="input-group input-group-sm mb-3">
                        <input type="password" name="new_pass" id="new_db_pass" class="form-control text-center rounded-start" placeholder="Password Baru" required>
                        <button class="btn btn-outline-secondary" type="button" onclick="genPass('new_db_pass')"><i class="bi bi-shuffle"></i></button>
                    </div>
                    
                    <button type="submit" name="change_pass_db" class="btn btn-warning w-100 rounded-pill fw-bold">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="modalImport" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header border-0 pb-0">
                    <h6 class="fw-bold mb-0">Import Database SQL</h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body py-4">
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">DATABASE TUJUAN</label>
                        <select name="target_db" class="form-select rounded-3" required>
                            <?php foreach($db_list as $db): ?>
                                <option value="<?= $db['name'] ?>"><?= $db['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-0">
                        <label class="small fw-bold text-muted">FILE SQL (.sql)</label>
                        <input type="file" name="sql_file" class="form-control rounded-3" accept=".sql" required>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="submit" name="import_db" class="btn btn-success w-100 rounded-pill fw-bold">Jalankan Import</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function genPass(targetId) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    let pass = "";
    for (let i = 0; i < 16; i++) {
        pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const input = document.getElementById(targetId);
    input.value = pass;
    input.type = "text"; 
}

function modalPass(user) {
    const modalEl = document.getElementById('modalPass');
    if (modalEl) {
        document.getElementById('pass_db_user').value = user;
        document.getElementById('display_user_pass').innerText = user;
        const myModal = new bootstrap.Modal(modalEl);
        myModal.show();
    }
}
function showLoading(form) {
    const btn = form.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sedang Memproses...';
}
</script>