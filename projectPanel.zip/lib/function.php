<?php

/**
 * PARAMETER
 */
$ip_Server = $_SERVER['SERVER_ADDR'];
$dashboard = "dashboard.php?page=home";
$page = $_GET['page'] ?? 'home';
$page_ext = $_GET['page'] ?? 'extensions';
$page_services = $_GET['page'] ?? 'services';
$page_domains = $_GET['page'] ?? 'domains';
$subpage = $_GET['subpage'] ?? '';

$path_vhost = "/var/www/vhost/";
$path_server = "/var/server/";
$path_logs = $path_server . ".logs/";
$path_nvm = $path_server . ".nvm/";
$path_sock = "/run/php/";

$path_apache = "/etc/apache2/";
$apache_available = $path_apache . "sites-available/";
$apache_enabled = $path_apache . "sites-enabled/";
function symlinkApache($conf_apache) {
    $conf_name = basename($conf_apache, ".conf");
    return shell_exec("sudo a2ensite " . escapeshellarg($conf_name) . ".conf 2>&1");
}
function unlinkApache($conf_apache) {
    $conf_name = basename($conf_apache, ".conf");
    shell_exec("sudo a2dissite " . escapeshellarg($conf_name) . ".conf 2>&1");
    return shell_exec("sudo rm -f /etc/apache2/sites-available/" . escapeshellarg($conf_name) . ".conf");
}

$path_nginx = "/etc/nginx/";
$nginx_available = $path_nginx . "sites-available/";
$nginx_enabled = $path_nginx . "sites-enabled/";
function symlinkNginx($conf_nginx) {
    $source = "/etc/nginx/sites-available/" . basename($conf_nginx);
    $target = "/etc/nginx/sites-enabled/" . basename($conf_nginx);
    return shell_exec("sudo ln -sf " . escapeshellarg($source) . " " . escapeshellarg($target) . " 2>&1");
}
function unlinkNginx($conf_nginx) {
    $filename = basename($conf_nginx);
    $cmd = "sudo rm -f /etc/nginx/sites-enabled/" . escapeshellarg($filename) . " && ";
    $cmd .= "sudo rm -f /etc/nginx/sites-available/" . escapeshellarg($filename);
    return shell_exec($cmd . " 2>&1");
}

$path_acme = "/root/.acme.sh/";
$path_composer = "/usr/local/bin/composer";
$pma = "/pma/";
$timestamp = date('d-m-Y_H-i-s');
$alert = "";
$msg = "";

/**
 * FUNCTION SERVER
 */
function actionServer($app, $version = "", $action) {
    $cmd = "sudo /usr/local/bin/vhost $app $version $action > /dev/null 2>&1 &";
    exec($cmd, $output, $return_var);
    return ($return_var === 0);
}

/**
 * GET ICON
 */
function urlExists($url) {
    $headers = @get_headers($url);
    if ($headers && strpos($headers[0], '200') !== false) {
        return true;
    }
    return false;
}
function srcIcon($keyword) {
    $icon = strtolower(trim($keyword));
    $icon = str_replace(' ', '', $icon);
    $devIconBase = "https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/";
    $src = $devIconBase . $icon . "/" . $icon . "-original.svg";
    if (!urlExists($src)) {
        $src = "https://simpleicons.org/icons/" . $icon . ".svg";
    }
    return $src;
}
if (isset($_GET['check_icon'])) {
    header('Content-Type: application/json');
    $keyword = $_GET['keyword'] ?? '';
    $iconUrl = srcIcon($keyword);
    if ($iconUrl) {
        echo json_encode(['exists' => true, 'url' => $iconUrl]);
    } else {
        echo json_encode(['exists' => false, 'url' => '']);
    }
    exit;
}

/**
 * FUNCTION PHP-FPM
 */
function getInstalledPHPVersions() {
    $versions = [];
    $path = '/etc/php/';
    
    if (is_dir($path)) {
        $dirs = glob($path . '*', GLOB_ONLYDIR);
        foreach ($dirs as $dirPath) {
            $v = basename($dirPath);
            if (preg_match('/^[0-9.]+$/', $v)) {
                if (is_dir($dirPath . '/fpm') || is_dir($dirPath . '/cli')) {
                    $versions[] = $v;
                }
            }
        }
    }
    
    if (empty($versions)) {
        $cmd = "ls /etc/php/ 2>/dev/null";
        $output = shell_exec($cmd);
        if ($output) {
            $lines = explode("\n", trim($output));
            foreach ($lines as $line) {
                if (preg_match('/^[0-9.]+$/', trim($line))) {
                    $versions[] = trim($line);
                }
            }
        }
    }

    sort($versions);
    return array_unique($versions);
}
function getRunningSockPHPVersions() {
    $versions = [];
    $socketPath = '/run/php/'; 
    
    if (is_dir($socketPath)) {
        $sockets = glob($socketPath . 'php*-fpm.sock');
        
        foreach ($sockets as $socket) {
            $filename = basename($socket);
            if (preg_match('/php([0-9.]+)-fpm\.sock/', $filename, $matches)) {
                $versions[] = $matches[1];
            }
        }
    }
    
    if (empty($versions)) {
        $output = shell_exec("ls $socketPath | grep fpm.sock 2>/dev/null");
        if ($output) {
            $lines = explode("\n", trim($output));
            foreach ($lines as $line) {
                if (preg_match('/php([0-9.]+)-fpm\.sock/', $line, $matches)) {
                    $versions[] = $matches[1];
                }
            }
        }
    }

    sort($versions);
    return array_unique($versions);
}
$available_php = getInstalledPHPVersions();
$available_sock = getRunningSockPHPVersions();

/**
 * AUTO DETECTION NODE.JS VERSION
 */
function getInstalledNodeVersions() {
    $versions = [];
    $nvm_path = "/var/server/.nvm/versions/node/";
    if (is_dir($nvm_path)) {
        $dirs = glob($nvm_path . 'v*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            $versions[] = str_replace('v', '', basename($dir));
        }
    }
    $versions = array_unique($versions);
    sort($versions, SORT_NATURAL);
    return !empty($versions) ? $versions : ['Not Available!'];
}
$available_node_version = getInstalledNodeVersions();

/**
 * HELPER FUNCTIONS
 */
function getFolderSize($path) {
    if(!is_dir($path)) return 0;
    $io = popen("/usr/bin/du -sk " . escapeshellarg($path), "r");
    $size = fgets($io, 4096);
    $size = substr($size, 0, strpos($size, "\t"));
    pclose($io);
    return round($size / 1024, 2);
}
function getTrafficUsage($domain) {
    $log_path = "/var/log/apache2/access." . $domain . ".log";
    if (!file_exists($log_path)) return "0 B";
    $command = "awk '{sum+=$10} END {print sum}' " . escapeshellarg($log_path);
    $bytes = (float) shell_exec($command);
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . " GB";
    if ($bytes >= 1048576) return round($bytes / 1048576, 2) . " MB";
    return round($bytes / 1024, 2) . " KB";
}

/**
 * ALERT HANDLE
 */
function setAlert($msg, $status = 'success', $redirect = null) {
    if (session_status() === PHP_SESSION_NONE) { session_start(); }
    $_SESSION['msg'] = $msg; $_SESSION['status'] = $status;
    if ($redirect) { header("Location: $redirect"); exit(); }
}

?>