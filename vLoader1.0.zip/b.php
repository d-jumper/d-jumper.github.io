<?php
date_default_timezone_set('Asia/Jakarta');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ==========================================
// CLASS HTTP CLIENT (ALA GUZZLE)
// ==========================================

class Response {
    protected $body;
    protected $info;

    public function __construct($body, $info) {
        $this->body = $body;
        $this->info = $info;
    }

    public function getBody() {
        return $this->body;
    }

    public function json() {
        return json_decode($this->body, true);
    }

    public function getStatusCode() {
        return $this->info['http_code'];
    }
}

class Client {
    protected $defaultHeaders;

    public function __construct($headers = null) {
        $this->defaultHeaders = $headers ? (is_array($headers) ? $headers : [$headers]) : [
            "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "Accept-Language: en-US,en;q=0.9"
        ];
    }

    private function request($method, $url, $options = []) {
        $ch = curl_init($url);
        $headers = $options['headers'] ?? $this->defaultHeaders;
        $postFields = null;

        if (isset($options['json'])) {
            $postFields = json_encode($options['json']);
            $headers[] = 'Content-Type: application/json';
        } elseif (isset($options['form_params'])) {
            $postFields = http_build_query($options['form_params']);
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }

        $curlOptions = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_ENCODING       => '',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_FOLLOWLOCATION => true
        ];

        if ($postFields) {
            $curlOptions[CURLOPT_POSTFIELDS] = $postFields;
        }

        curl_setopt_array($ch, $curlOptions);
        $result = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);

        return new Response($result, $info);
    }

    public function get($url, $options = []) {
        return $this->request('GET', $url, $options);
    }

    public function post($url, $options = []) {
        return $this->request('POST', $url, $options);
    }
}
/**
  * EXAMPLE
  
$userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
$client = new Client(["User-Agent: $userAgent"]);

// POST & GET ACTION
# $option -> header or header with post field in array
# post field suuport : json (payload) || form_params (files)

$response = $client->post($url, $option);
$response = $client->get($url, $option);

// GET STATUS CODE
$status = $response->getStatusCode();

// GET BODY REQUEST
$html = $response->getBody();

// JSON_DECODE
$data = $response->json();

<iframe id="player" type="text/html" width="640" height="390"
  src="http://www.youtube.com/embed/M7lc1UVf-VE?enablejsapi=1&origin=http://example.com"
  frameborder="0"></iframe>

**/


// ==========================================
// LOGIKA UTAMA YOUTUBE
// ==========================================

$client_name = "ANDROID";
require_once("clientData.php");
foreach($clientData['client'] as $c){
    if($c['clientName'] == $client_name) {
        $int_client_name = $c['clientId'];
        $client_version = $c['clientVersion'];
        $client_userAgent = $c['userAgent'];
        $apiKey = $c['apiKey'];
    }
}

// Inisialisasi Client dengan UserAgent khusus YouTube
$client = new Client();

// 1. Ekstrak Video ID
$url = "https://youtu.be/wAnfpeUavRU";
preg_match('%(?:youtube\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/\s]{11})%i', $url, $match);
$videoId = $match[1] ?? null;
if (!$videoId) die("Video ID tidak ditemukan");

// 2. Ambil konten base.js
function getContentData($client, $videoId, $userAgent) {
    $apiKey = null; $payload = []; $sigTimestamp = time();
    
    $whatchUrl = "https://www.youtube.com/watch?v=" . $videoId;
    $response = $client->get($whatchUrl, [
        'headers' => [
            "User-Agent: " . $userAgent,
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language: en-US,en;q=0.5"
        ]
    ]);
    $html = $response->getBody();
    
    $pattern = '/ytcfg\.set\(\s*({.*?})\s*\)\s*;/s';
    if (preg_match($pattern, $html, $matches)) {
        $jsonString = $matches[1];
        $ytcfgArray = json_decode($jsonString, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $apiKey = $ytcfgArray['INNERTUBE_API_KEY'] ?? null;
            $client = $ytcfgArray['INNERTUBE_CONTEXT'];
            $visitorData = $ytcfgArray['VISITOR_DATA'];
            $sigTimestamp = $ytcfgArray['STS'];
            $jsUrl = $ytcfgArray['PLAYER_JS_URL'] ?? '';
        }
    }
    /** get base.js
    if (strpos($jsUrl, 'http') !== 0) $jsUrl = "https://www.youtube.com" . $jsUrl;
    $jsContent = $client->get($jsUrl)->getBody();
    **/

    return [
        "apiKey" => $apiKey,
        "context" => $client,
        "visitorData" => $visitorData,
        "sigTimestamp" => $sigTimestamp,
        "player_js_url" => $jsUrl,
        "ytcfg" => $ytcfgArray
    ];
}
$ct_data = getContentData($client, $videoId, $client_userAgent);
$apiKey = $apiKey ?? $ct_data['apiKey'];
$visitorData = $ct_data['visitorData'];
$sigTimestamp = $ct_data['sigTimestamp'];
$ct_client = $ct_data['context']['client'];
$accept_headers = $ct_client['acceptHeader'] ?? "*/*";
// header('Content-Type: application/json; charset=utf-8'); echo json_encode($ct_data, JSON_PRETTY_PRINT); exit();

function getBaseJs($client, $jsUrl){
    if (strpos($jsUrl, 'http') !== 0) {
        $jsUrl = "https://www.youtube.com" . $jsUrl;
    }
    $jsResponse = $client->get($jsUrl);
    return $jsResponse->getBody();
}
$jsUrl = $ct_data['player_js_url'];
$baseJs = getBaseJs($client, $jsUrl);
$regexSig = '/([$\w]{2,})=function\(\w\)\{\w=\w\.split\(""\)/';
preg_match($regexSig, $baseJs, $matches);
 header('Content-Type: application/json; charset=utf-8'); echo json_encode($matches, JSON_PRETTY_PRINT); exit();
 
$apiUrl = "https://www.youtube.com/youtubei/v1/player?key=" . $apiKey;
$payload = [
    "videoId" => $videoId,
    "context" => [
        "client" => [
            /*// com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip
            "userAgent" => $ct_client['userAgent'],
            'clientName' => 'ANDROID',
            'clientVersion' => '20.42.40',
            "osName" => $ct_client['osName'],
            "osVersion" => $ct_client['osVersion']*/
            
            // com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)
            /*"userAgent" => $ct_client['userAgent'],
            "clientName" => "IOS",
            "clientVersion" => "20.10.4",
            "osName" => $ct_client['osName'],
            "osVersion" => $ct_client['osVersion']*/

            "clientName" => $client_name,
            "clientVersion" => $client_version,
            "osName" => $ct_client['osName'],
            "osVersion" => $ct_client['osVersion'],
            "clientScreen" => "WATCH",
            "platform" => "MOBILE"
        ],
        "user" => [
            "lockedSafetyMode" => false
        ],
        "request" => [
            "useSsl" => true
        ]
    ],
    "playbackContext" => [
        "contentPlaybackContext" => [
            "signatureTimestamp" => $sigTimestamp
        ]
    ],
    "racyCheckOk" => true,
    "contentCheckOk" => true
];

$response = $client->post($apiUrl, [
    'json' => $payload,
    'headers' => [
        "User-Agent: " . $client_userAgent,
        "Accept: " . $accept_headers,
        "Content-Type: application/json",
        "x-youtube-client-name: " . $int_client_name,
        "x-youtube-client-version: " . $client_version,
        'Referer: https://www.youtube.com/'
    ]
]);
$data = $response->json();
// header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_PRETTY_PRINT); exit();

$dataUrl = null;
$adaptive = $data['streamingData']['formats'] ?? [];
foreach($adaptive as $f){
    if(isset($f['itag']) && $f['itag'] == 18) { $dataUrl = $f['url']; break; }
}
if (!$dataUrl) {
    foreach($adaptive as $f) {
        if(isset($f['url']) && strpos($f['mimeType'], 'video/mp4') !== false) { $dataUrl = $f['url']; break; }
    }
}
if (!$dataUrl) die("itag tidak ditemukan atau video diblokir.");
// header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_PRETTY_PRINT); exit;

// ==========================================
// PROSES STREAMING (PASSTHROUGH)
// ==========================================
// Bagian ini menggunakan cURL manual karena kita butuh streaming langsung (CURLOPT_RETURNTRANSFER => false)
$isStream = false;
$parsedUrl = parse_url($dataUrl);
$host = $parsedUrl['host'];
$headersData = [
    "Host: " . $host,
    "User-Agent: " . $client_userAgent,
    "Accept: " . $accept_headers,
    "Accept-Language: en-US,en;q=0.9",
    "Connection: keep-alive"
];

if (isset($_SERVER['HTTP_RANGE'])) {
    $headersData[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
}

if (ob_get_level()) ob_end_clean();
$ch = curl_init($dataUrl);
curl_setopt_array($ch, [
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_RETURNTRANSFER => false, 
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_BUFFERSIZE => 262144,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_HTTPHEADER => $headersData,
    CURLOPT_HEADERFUNCTION => function($curl, $header) use ($isStream) {
        $len = strlen($header);
        $h = strtolower($header);
        
        if (preg_match('/^http\/(1\.[01]|2|3)\s+(\d+)/', $h, $matches)) {
            http_response_code(intval($matches[2]));
            return $len;
        }
        
        $allowed = ['content-type:', 'content-length:', 'content-range:', 'accept-ranges:'];
        foreach ($allowed as $a) {
            if (strpos($h, $a) === 0) {
                if ($a === 'content-type:') {
                    header($isStream ? "Content-Type: video/mp4" : "Content-Type: application/octet-stream");
                    if (!$isStream) header("Content-Disposition: attachment; filename=\"video.mp4\"");
                } else {
                    header($header, false);
                }
                break;
            }
        }
        return $len;
    }
]);

curl_exec($ch);
curl_close($ch);