<?php
/**
 * Path: /var/www/cpanel/node-manager/get_npm_log.php
 */
$name = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['name'] ?? '');
$user = preg_replace('/[^a-z0-9]/', '', $_GET['user'] ?? 'root');

$json_file = "/var/www/html/$user/node_apps/node_config.json";
$log_path = "";

if (file_exists($json_file)) {
    $config = json_decode(file_get_contents($json_file), true);
    if (isset($config[$name]['npm_log'])) {
        $log_path = $config[$name]['npm_log'];
    } else {
        // Fallback jika belum ada di config: gunakan folder dari entry path
        $log_path = dirname($config[$name]['path']) . "/npm_action.log";
    }
}

if ($log_path && file_exists($log_path)) {
    header('Content-Type: text/plain');
    // Tambahkan pembersihan cache agar log selalu fresh
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    echo shell_exec("tail -n 100 " . escapeshellarg($log_path));
} else {
    echo "Log tidak ditemukan di: " . $log_path;
}