<?php
// node-manager/get_install_log.php
header('Content-Type: text/plain');
header('Cache-Control: no-cache');

// 1. Sanitasi input user
$user = preg_replace('/[^a-z0-9]/', '', $_GET['user'] ?? 'root');
$log_file = "/tmp/node_inst.log";

if (file_exists($log_file)) {
    // 2. Gunakan perintah tail agar hanya mengirimkan baris-baris terakhir
    // Ini jauh lebih ringan daripada mengirim seluruh isi file setiap 2 detik
    $output = shell_exec("tail -n 20 " . escapeshellarg($log_file));
    echo $output ?: "Menunggu output...";
} else {
    echo "Initializing installation log...";
}
exit;