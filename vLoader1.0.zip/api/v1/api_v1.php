<?php
date_default_timezone_set('Asia/Jakarta');
// error_reporting(E_ALL); ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../vendor/autoload.php';
use DJumPer\Downloader;

$response = [
    'status'  => false,
    'message' => 'Parameter URL diperlukan',
    'data'    => null
];

if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']) === false) {
    http_response_code(403);
    die("Access Denied.");
}

$url = filter_input(INPUT_GET, 'url', FILTER_SANITIZE_URL) 
    ?: filter_input(INPUT_POST, 'url', FILTER_SANITIZE_URL);  // url video
    
if (!isset($url)) {
    http_response_code(400);
    die("Bad Request: URL parameter is missing.");
}
        
if ($url) {
    try {
        $dl = new Downloader();
        $result = $dl->getVideoInfo($url, 'getData');

        if ($result) {
            $response = [
                'status'  => true,
                'data'    => $result
            ];
        } else {
            $response['message'] = 'Gagal mengambil informasi video.';
        }

    } catch (Exception $e) {
        $response['message'] = $e->getMessage();
    }
}

echo json_encode($response, JSON_UNESCAPED_SLASHES);