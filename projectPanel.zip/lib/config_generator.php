<?php

// --- Template Apache ---
$apache_config = "<VirtualHost *:8080>
    ServerName $domain_user
    ServerAlias www.$domain_user
    DocumentRoot $path_user

    <Directory $path_user>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler \"proxy:unix:/run/php/php$php_version-fpm.sock|fcgi://localhost\"
    </FilesMatch>

    <Files \".user.ini\">
        Require all denied
    </Files>
    
    ErrorLog \${APACHE_LOG_DIR}/{$domain_user}_error.log
    CustomLog \${APACHE_LOG_DIR}/{$domain_user}_access.log combined
</VirtualHost>";
$apache_config_main = "<VirtualHost *:8080>
    ServerName $domain_user
    DocumentRoot $path_user

    <Directory $path_user>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch \.php$>
        SetHandler \"proxy:unix:/run/php/php$php_version-fpm.sock|fcgi://localhost\"
    </FilesMatch>

    <Files \".user.ini\">
        Require all denied
    </Files>
    
    ErrorLog \${APACHE_LOG_DIR}/{$domain_user}_error.log
    CustomLog \${APACHE_LOG_DIR}/{$domain_user}_access.log combined
</VirtualHost>";

// --- Template Nginx ---
$nginx_blok = "server {
    listen 80;
    server_name $domain_user www.$domain_user;
    root $path_user;
    index index.php index.html;
            
    location / {
        try_files \$uri \$uri/ =404;
    }
            
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php$php_version-fpm.sock;
    }
        
    location ~ /\.user\.ini {
        deny all;
    }
    
    access_log /var/log/nginx/{$domain_user}_access.log;
    error_log /var/log/nginx/{$domain_user}_error.log;
}";
$nginx_blok_main = "server {
    listen 80;
    server_name $domain_user;
    root $path_user;
    index index.php index.html;
            
    location / {
        try_files \$uri \$uri/ =404;
    }
            
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php$php_version-fpm.sock;
    }
        
    location ~ /\.user\.ini {
        deny all;
    }
    
    access_log /var/log/nginx/{$domain_user}_access.log;
    error_log /var/log/nginx/{$domain_user}_error.log;
}";
$nginx_blok_proxy = "server {
    listen 80;
    server_name $domain_user www.$domain_user;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 600;
        proxy_send_timeout 600;
        proxy_read_timeout 600;
        send_timeout 600;
    }
}";
$nginx_blok_proxy_main = "server {
    listen 80;
    server_name $domain_user;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 600;
        proxy_send_timeout 600;
        proxy_read_timeout 600;
        send_timeout 600;
    }
}";

if($type_server == 'apache') {
    $server_config = ($type == 'main') ? $apache_config_main : $apache_config;
    $dir_config = $apache_available . $domain_user . ".conf";
    $tmp_ap = "/tmp/ap_" . bin2hex(random_bytes(4));
    file_put_contents($tmp_ap, $server_config);
    $cmd_ap = "sudo mv $tmp_ap $dir_config";
    
    $proxy_config = ($type == 'main') ? $nginx_blok_proxy_main : $nginx_blok_proxy;
    $dir_proxy = $nginx_available . $domain_user;
    $tmp_ng = "/tmp/cfg_" . bin2hex(random_bytes(8));
    file_put_contents($tmp_ng, $proxy_config);
    $cmd_ng = "sudo mv $tmp_ng $dir_proxy";
    
    $command = $cmd_ap . " && " . $cmd_ng . " 2>&1";
    shell_exec($command . " 2>&1");
    symlinkApache($domain_user . ".conf");
    symlinkNginx($domain_user);
    
} else if($type_server == 'nginx') {
    $server_config = ($type == 'main') ? $nginx_blok_main : $nginx_blok;
    $dir_config = $nginx_available . $domain_user;
    
    $tmp_file = "/tmp/cfg_" . bin2hex(random_bytes(8));
    file_put_contents($tmp_file, $server_config);
    $command = "sudo mv $tmp_file $dir_config";
    shell_exec($command . " 2>&1");
    symlinkNginx($domain_user);
}

#www-data ALL=(ALL) NOPASSWD: /usr/sbin/a2ensite, /usr/sbin/apache2ctl, /usr/bin/systemctl, /usr/sbin/nginx, /usr/bin/ln, /usr/bin/mv
?>