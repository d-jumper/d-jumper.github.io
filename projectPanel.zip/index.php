<?php
session_start();
require_once('config.php'); 

if (isset($_SESSION['user'])) {
    header("Location: dashboard.php");
    exit();
}

$msg = "";
$msg_type = "";

$is_root_exists = false;
$check_root = $conn->query("SELECT id FROM users WHERE role='admin' LIMIT 1");
if ($check_root && $check_root->num_rows > 0) {
    $is_root_exists = true;
}

if (isset($_POST['register_admin']) && !$is_root_exists) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $pwd = $_POST['password'];
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    if (strlen($pwd) < 6) {
        $msg = "Password must be at least 6 characters!";
    } else {
        $pwd_hash = password_hash($pwd, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'admin')");
        $stmt->bind_param("sss", $username, $pwd_hash, $email);
        if ($stmt->execute()) {
            $msg = "<b>Administrator</b> successfully registered! Please log in.";
            $msg_type = "success";
            $is_root_exists = true; 
        } else {
            $msg = "Failed registered! : " . $conn->error;
            $msg_type = "danger";
        }
    }
}

if (isset($_POST['login'])) {
    $userInput = mysqli_real_escape_string($conn, $_POST['userInput']); 
    $pass = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $userInput, $userInput);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows > 0) {
        $data = $res->fetch_assoc();
        
        if (password_verify($pass, $data['password'])) {
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['user'] = $data['username'];
            $_SESSION['role'] = $data['role'];
                        
            $_SESSION['result'] = array(
                'status' => 'success',
                'message' => "Welcome: $userInput"
            );
            header("Location: dashboard.php");
            exit();
        } else { $msg = "Wrong Username/Password!"; 
            $msg_type = "danger"; }
    } else { $msg = "Email/Username not found!"; 
            $msg_type = "danger"; }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <title><?php echo $title_panel; ?> | <?php echo $is_root_exists ? 'Login' : 'System Setup'; ?></title>
    <style>
        body { background: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .auth-card { max-width: 400px; margin: 100px auto; border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); overflow: hidden; }
        .setup-header { background: #00a8e0; color: white; padding: 40px 20px; text-align: center; }
        .btn-primary { background: #00a8e0; border: none; padding: 12px; font-weight: 600; transition: 0.3s; }
        .btn-primary:hover { background: #008dbd; transform: translateY(-2px); }
        .form-control { padding: 12px; border-radius: 8px; }
        .alert { border-radius: 10px; }
    </style>
</head>
<body>

<div class="container">
    <div class="card auth-card">
        <div class="setup-header">
            <i class="bi bi-cpu-fill" style="font-size: 3.5rem;"></i>
            <h4 class="mt-3 fw-bold"><?php echo $title_panel; ?></h4>
            <p class="mb-0 opacity-75 small text-uppercase tracking-wider">
                <?php echo $is_root_exists ? 'Secure Authentication' : 'Initial System Setup'; ?>
            </p>
        </div>
        <div class="card-body p-4">

            <?php if($msg): ?>
                <div class="alert alert-<?php echo $msg_type; ?> small shadow-sm mb-4">
                    <i class="bi bi-info-circle me-2"></i> <?php echo $msg; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
            
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted"><?php echo $is_root_exists ? 'Email/Username' : 'Username'; ?></label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-person text-primary"></i></span>
                        <input type="text" name="<?php echo $is_root_exists ? 'userInput' : 'username'; ?>" class="form-control border-start-0" placeholder="<?php echo $is_root_exists ? 'Email/Username' : 'Username'; ?>" required>
                    </div>
                </div>
                
                <?php if (!$is_root_exists): ?>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">Email</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white border-end-0"><i class="bi bi-envelope text-primary"></i></span>
                            <input type="text" name="email" class="form-control border-start-0" placeholder="e.g. admin@gmail.com" required>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted">Password</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-shield-lock text-primary"></i></span>
                        <input type="password" name="password" class="form-control border-start-0" placeholder="password" required>
                        <input type="hidden" name="host_panel" class="form-control border-start-0" value="<?php echo $host_panel; ?>" required readonly>
                    </div>
                </div>
                                
                <?php if (!$is_root_exists): ?>
                    <button name="register_admin" class="btn btn-primary w-100 mb-3 shadow-sm">
                        <i class="bi bi-rocket-takeoff me-2"></i> Install System Now
                    </button>
                    <div class="p-2 bg-light rounded text-center">
                        <small class="text-muted" style="font-size: 0.75rem;">
                            <i class="bi bi-exclamation-triangle-fill text-warning"></i> 
                            Register for Administrator Account.
                        </small>
                    </div>
                <?php else: ?>
                    <button name="login" class="btn btn-primary w-100 shadow-sm">
                        <i class="bi bi-box-arrow-in-right me-2"></i> Sign In
                    </button>
                <?php endif; ?>
            </form>
        </div>
        <div class="card-footer bg-white border-0 text-center pb-4">
            <small class="text-muted" style="font-size: 0.7rem;">&copy; <?php echo date('Y'); ?> PanelControl. All Rights Reserved.</small>
        </div>
    </div>
</div>

</body>
</html>