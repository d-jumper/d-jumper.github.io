<?php

namespace DJumPer\Platform;

use DJumPer\Utils\Utils;
use Exception;

class Instagram
{

    public function scrape($html)
    {

        $platform = 'Instagram'; $title = null; $thumbnail = null;
        $videoUrl = null; $audioUrl = null; $streamingQualities = []; 
        $videoQualities = []; $audioQualities = [];
        $reason = 'Video tidak dapat diputar (Private/Age Restricted).';
        
        //if (strpos($html, 'Oops, an error occurred') !== false || strpos($html, '500 Internal Server Error') !== false) {
            //throw new Exception("Gagal mengambil video. Tunggu beberapa saat, dan coba lagi.");
        //}

        if (preg_match('/"video_url":"([^"]+)"/', $html, $matches)) $videoUrl = $matches[1];
        if (!$videoUrl && preg_match('/https:\/\/[^"]+?\.mp4[^"]+/', $html, $matches)) $videoUrl = $matches[0];
        if (preg_match('/"display_url":"([^"]+)"/', $html, $matches)) $thumbnail = $matches[1];
        if (preg_match('/"audio_src":"([^"]+)"/', $html, $matches)) $audioSrc = $matches[1];
        if (preg_match('/<meta property="og:title" content="([^"]+)"/', $html, $matches)) {
            $title = $matches[1];
        } elseif (preg_match('/"text":"([^"]+)"/', $html, $matches)) {
            $title = $matches[1];
        }
        
        if (!$videoUrl) {
            throw new Exception($platform . ": " . $reason);
        } else {
            $reason = "OK";
            $audioUrl = $audioSrc ?? $videoUrl;
            $streamingUrl = $videoUrl;
        }
                
        $videoQualities[] = [
            "itag" => 1,
            "type" => "mp4",
            "qualityLabel" => "Video MP4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎥 720p",
            "url" => Utils::cleanString($videoUrl)
        ];
        
        $streamingQualities[] = [
            "type" => "mp4",
            "url" => Utils::cleanString($videoUrl)
        ];

        $audioQualities[] = [
            "itag" => 1,
            "type" => "mp3",
            "qualityLabel" => "Audio MP3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎵 High",
            "url" => Utils::cleanString($audioUrl)
        ];
        
        $title = Utils::cleanString($title);
        return [
            'status' => $reason,
            'platform' => $platform,
            'title' => Utils::limitString($title, 100),
            'thumbnail' => Utils::cleanString($thumbnail),
            'streaming_data' => $streamingQualities,
            'video_data' => $videoQualities,
            'audio_data' => $audioQualities
        ];
                
    }
    
}