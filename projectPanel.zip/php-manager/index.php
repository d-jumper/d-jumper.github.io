<?php
ob_start(); 
/**
 * PHP SETTINGS - PHP MANAGER
 * Perbaikan Backend dengan Notifikasi Redirect
 */

// 1. INITIALIZATION & SECURITY
$id = isset($_GET['id']) ? preg_replace('/[^a-zA-Z0-9]/', '', $_GET['id']) : '';
$user_target = isset($_GET['user']) ? preg_replace('/[^a-z0-9]/', '', $_GET['user']) : '';

if (empty($user_target)) {
    header("Location: dashboard.php?status=error&msg=Parameter+User+tidak+ditemukan");
    exit;
}

// Environment Paths
$path_domain_user = "/var/www/html/vhost/$user_target/httpdocs";
$user_ini_path = $path_domain_user . "/.user.ini";

// State Management URL
$user_manage_url = "?page=manage&id=$id&user=$user_target";
$current_url = "?page=manage&id=$id&subpage=php-settings&user=$user_target";

$stmt_init = $conn->prepare("SELECT domain FROM db_users WHERE id = ?");
$stmt_init->bind_param("s", $id);
$stmt_init->execute();
$res_init = $stmt_init->get_result();
$dataUser = $res_init->fetch_assoc();

if (!$dataUser) {
    header("Location: dashboard.php?status=error&msg=User+tidak+ditemukan");
    exit;
}
$domain_user = $dataUser['domain'];
$apache_conf = "zzz." . $domain_user . ".conf";

function getActivePHPVersion($user_target, $apache_conf) {
    
    $vhost_file = "/etc/apache2/sites-available/$apache_conf";
    if (file_exists($vhost_file)) {
        $content = file_get_contents($vhost_file);
        if (preg_match('/php([0-9.]+)-fpm\.sock/', $content, $matches)) {
            return $matches[1];
        }
    }
    return null;
}

function getInstalledPHPVersions() {
    $versions = [];
    $path = '/etc/php/';
    
    if (is_dir($path)) {
        // Menggunakan glob untuk list folder yang hanya berisi angka/titik
        $dirs = glob($path . '*', GLOB_ONLYDIR);
        foreach ($dirs as $dirPath) {
            $v = basename($dirPath);
            // Cek apakah folder tersebut versi PHP (contoh: 7.4, 8.1)
            if (preg_match('/^[0-9.]+$/', $v)) {
                // Pastikan fpm socket atau binary-nya ada
                if (is_dir($dirPath . '/fpm') || is_dir($dirPath . '/cli')) {
                    $versions[] = $v;
                }
            }
        }
    }
    
    // Fallback: Jika scan folder gagal karena permission, coba via terminal
    if (empty($versions)) {
        $cmd = "ls /etc/php/ 2>/dev/null";
        $output = shell_exec($cmd);
        if ($output) {
            $lines = explode("\n", trim($output));
            foreach ($lines as $line) {
                if (preg_match('/^[0-9.]+$/', trim($line))) {
                    $versions[] = trim($line);
                }
            }
        }
    }

    sort($versions);
    return array_unique($versions);
}
$available_php = getInstalledPHPVersions();

function getCurrentSettings($file) {
    $defaults = [
        'memory_limit' => '128M', 'max_execution_time' => '30', 'post_max_size' => '8M',
        'upload_max_filesize' => '2M', 'max_input_time' => '60', 'display_errors' => 'Off',
        'log_errors' => 'On', 'allow_url_fopen' => 'On', 'file_uploads' => 'On',
        'short_open_tag' => 'Off', 'opcache.enable' => '1', 'session.gc_maxlifetime' => '1440',
        'zlib.output_compression' => 'Off', 'disable_functions' => 'exec,passthru,shell_exec,system',
        'open_basedir' => 'none', 'max_input_vars' => '1000', 'fastcgi.logging' => '1', 'cgi.fix_pathinfo' => '1'
    ];
    if (file_exists($file) && is_readable($file)) {
        $content = file_get_contents($file);
        foreach ($defaults as $key => $val) {
            $key_regex = str_replace('.', '\.', $key);
            if (preg_match("/^$key_regex\s*=\s*[\"']?([^\\n;\"']+)[\"']?/m", $content, $matches)) {
                $defaults[$key] = trim($matches[1]);
            }
        }
    }
    return $defaults;
}
$current_val = getCurrentSettings($user_ini_path);
$current_active_v = getActivePHPVersion($user_target, $apache_conf);

function getServiceStatus($version) {
    // Perbaikan: Gunakan pgrep untuk mengecek proses secara langsung
    // Ini lebih handal daripada mengecek file socket
    $cmd = "pgrep -f php$version-fpm";
    $output = shell_exec($cmd);
    
    return !empty(trim($output));
}

// Update pada Logika Restart
if (isset($_POST['restart_service'])) {
    $v_to_restart = preg_replace('/[^0-9.]/', '', $_POST['target_v']);
    
    // Gunakan service atau systemctl jika tersedia, 
    // Jika di UserLAnd/Termux gunakan path binari langsung
    shell_exec("sudo service php$v_to_restart-fpm restart"); 
    
    // Fallback jika 'service' tidak ada (untuk UserLAnd/WSL)
    shell_exec("sudo pkill -f php$v_to_restart-fpm");
    shell_exec("sudo /usr/sbin/php-fpm$v_to_restart -D"); 
    
    $msg = urlencode("Service PHP $v_to_restart-fpm telah dipicu ulang.");
    echo "<script>window.location.href='$current_url&status=success&msg=$msg';</script>";
    exit;
}
function getPHPErrors($user_target, $lines = 50) {
    $log_path = "/var/log/apache2/{$user_target}_error.log";
    
    if (!file_exists($log_path)) {
        return "Belum ada catatan error untuk user ini.";
    }

    if (!is_readable($log_path)) {
        // Jika file ada tapi tidak terbaca, coba gunakan sudo via shell_exec
        $escaped_path = escapeshellarg($log_path);
        $output = shell_exec("sudo tail -n $lines $escaped_path");
        return $output ?: "Log kosong atau tidak dapat diakses.";
    }

    // Membaca baris terakhir secara efisien
    $data = file($log_path);
    $data = array_slice($data, -$lines);
    return implode("", $data);
}

// Logika untuk membersihkan log jika tombol ditekan
if (isset($_POST['clear_log'])) {
    $log_path = "/var/log/apache2/{$user_target}_error.log";
    shell_exec("sudo truncate -s 0 " . escapeshellarg($log_path));
    $msg = urlencode("Log berhasil dibersihkan.");
    echo "<script>window.location.href='$current_url&status=success&msg=$msg';</script>";
    exit;
}
// --- LOGIKA 1: SET PHP VERSION & AUTO INSTALL ---
if (isset($_POST['set_php_vhost'])) {
    $v_selected = preg_replace('/[^0-9.]/', '', $_POST['php_vhost']);
    $socket_path = "/run/php/php$v_selected-fpm.sock";
    
    $stmt = $conn->prepare("SELECT domain FROM db_users WHERE username = ?");
    $stmt->bind_param("s", $user_target);
    $stmt->execute();
    $u_result = $stmt->get_result();
    $u_data = $u_result->fetch_assoc();

    if ($u_data) {
        $domain_user = $u_data['domain'];
        
        // Template Vhost > port panel diambil dari config.php
        $vhost_template = "<VirtualHost *:$port_panel>
    ServerName $domain_user
    DocumentRoot $path_domain_user
    <Directory $path_domain_user>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    <FilesMatch \.php$>
        SetHandler \"proxy:unix:$socket_path|fcgi://localhost\"
    </FilesMatch>
    ProxyTimeout 300
    ErrorLog \${APACHE_LOG_DIR}/{$user_target}_error.log
    CustomLog \${APACHE_LOG_DIR}/{$user_target}_access.log combined
</VirtualHost>";
        
        // Tulis file vhost
        $tmp_vhost = "/tmp/vhost_" . time() . "_" . $user_target;
        file_put_contents($tmp_vhost, $vhost_template);
        
        // Eksekusi sistem
        shell_exec("sudo mv $tmp_vhost /etc/apache2/sites-available/$apache_conf");
        shell_exec("sudo a2enmod proxy_fcgi setenvif rewrite > /dev/null 2>&1");
        shell_exec("sudo services php$v_selected-fpm start");
        shell_exec("sudo services php$v_selected-fpm enable");
        shell_exec("sudo services php$v_selected-fpm restart");
        shell_exec("sudo services apache2 reload");
        
        $msg = urlencode("PHP Berhasil diubah ke v$v_selected untuk $domain_user");
        echo "<script>window.location.href='$current_url&status=success&msg=$msg';</script>";
        exit;
    } else {
        $msg = urlencode("Gagal: User $user_target tidak ditemukan di database.");
        echo "<script>window.location.href='$current_url&status=error&msg=$msg';</script>";
        exit;
    }
}

// --- LOGIKA 2: SIMPAN PHP SETTINGS ---
if (isset($_POST['save_php_settings'])) {
    $ini_content = "; Generated by Panel Control - " . date('Y-m-d H:i:s') . "\n";
    
    if (isset($_POST['raw_mode'])) {
        $ini_content .= $_POST['raw_content'];
    } else {
        foreach ($_POST['settings'] as $k => $v) {
            $k_clean = preg_replace('/[^a-z0-9._]/', '', $k);
            $v_clean = addslashes($v);
            $ini_content .= "$k_clean = \"$v_clean\"\n";
        }
    }

    $tmp_ini = "/tmp/.user.ini_" . time() . "_" . $user_target;
    if (file_put_contents($tmp_ini, $ini_content)) {
        $target_path = escapeshellarg($user_ini_path);
        shell_exec("sudo mv $tmp_ini $target_path");
        shell_exec("sudo chown $user_target:$user_target $target_path");
        shell_exec("sudo chmod 644 $target_path");
        
        $active_v = getActivePHPVersion($user_target, $apache_conf);
        if ($active_v) shell_exec("sudo services php$active_v-fpm reload");

        $msg = urlencode("Konfigurasi PHP .user.ini berhasil diperbarui!");
        echo "<script>window.location.href='$current_url&status=success&msg=$msg';</script>";
        exit;
    } else {
        $msg = urlencode("Gagal menyimpan konfigurasi. Periksa izin folder /tmp.");
        echo "<script>window.location.href='$current_url&status=error&msg=$msg';</script>";
        exit;
    }
}

?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-primary"><i class="bi bi-gear-wide-connected"></i> PHP Settings: <?php echo $user_target; ?></h4>
        <a href="<?php echo $user_manage_url; ?>" class="btn btn-white btn-sm border shadow-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    </div>
    

    <div class="card border-0 shadow-sm mb-4 rounded-4 overflow-hidden">
        <div class="card-header bg-white border-0 py-3">
            <h6 class="mb-0 fw-bold text-dark">
                <i class="bi bi-cpu-fill me-2"></i>Installed PHP Versions
            </h6>
        </div>
        <div class="card-body pt-0">
            <div class="d-flex flex-wrap gap-2">
                <?php 
                foreach ($available_php as $version): 
                    $is_running = getServiceStatus($version);
                    $is_system = ($current_active_v == $version);
                ?>
                    <div class="d-flex align-items-center bg-light rounded-pill px-3 py-2 border shadow-sm">
                        <div class="bg-success rounded-circle me-2" style="width: 8px; height: 8px;"></div>
                        <span class="small fw-bold text-secondary">v<?= htmlspecialchars($version) ?></span>
                        <?php if ($is_system): ?>
                            <span class="badge bg-primary ms-2" style="font-size: 0.5rem;">DEFAULT</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="plesk-card border-0 shadow-sm bg-white">                
                <div class="p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Versi PHP</th>
                                    <th>Status Service</th>
                                    <th>Socket Path</th>
                                    <th class="text-center">Aksi Service</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    foreach($available_php as $v): 
                                    $is_running = getServiceStatus($v);
                                    $is_active_here = ($current_active_v == $v);
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <strong class="text-primary">PHP v<?php echo $v; ?></strong>
                                        <?php if($is_active_here): ?>
                                            <span class="badge bg-success ms-2">Digunakan User Ini</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($is_running): ?>
                                            <span class="text-success"><i class="bi bi-check-circle-fill me-1"></i> Active (Running)</span>
                                        <?php else: ?>
                                            <span class="text-danger"><i class="bi bi-x-circle-fill me-1"></i> Inactive (Stopped)</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><code class="small">/run/php/php<?php echo $v; ?>-fpm.sock</code></td>
                                    <td class="text-center">
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="target_v" value="<?php echo $v; ?>">
                                            <button name="restart_service" class="btn btn-outline-secondary btn-sm py-0 shadow-sm" title="Restart Service">
                                                <i class="bi bi-arrow-clockwise"></i> Restart
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="mt-3 p-2 bg-light-subtle rounded-3 border border-dashed">
                <small class="text-muted" style="font-size: 0.65rem;">
                    <i class="bi bi-info-circle me-1"></i>
                    Versi di atas dapat dipilih sebagai <b>Interpreter</b> pada masing-masing aplikasi Node Anda melalui menu NPM Manager.
                </small>
            </div>
        </div>
    </div>
                
    <div class="plesk-card mb-4 border-info">
        <div class="plesk-card-header bg-light d-flex justify-content-between align-items-center">
            <span><i class="bi bi-layers-half me-2"></i> PHP Version Handler (FastCGI/FPM)</span>
            <span class="badge bg-info"><i class="bi bi-hdd-stack me-1"></i> <?php echo count($available_php); ?> Versi Terpasang</span>
        </div>
        <div class="p-4">
            <form method="POST" class="row g-3 align-items-end">
                <div class="col-md-8">
                    <label class="form-label small fw-bold"><i class="bi bi-check2-circle me-1"></i> Pilih Versi PHP</label>
                    <select name="php_vhost" class="form-select">
                        <optgroup label="Versi PHP Tersedia">
                            <?php foreach($available_php as $v): ?>
                                <option value="<?php echo $v; ?>" <?php echo ($current_active_v == $v) ? 'selected' : ''; ?>>
                                    PHP v<?php echo $v; ?> <?php echo ($current_active_v == $v) ? : ''; ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    </select>
                </div>
                <div class="col-md-4">
                    <button name="set_php_vhost" class="btn btn-info text-white w-100">
                        <i class="bi bi-cloud-download me-1"></i> Switch
                    </button>
                </div>
            </form>
        </div>
    </div>
<div class="card border-0 shadow-sm mb-5 rounded-4 overflow-hidden">
    <div class="card-header bg-dark d-flex justify-content-between align-items-center py-3">
        <h6 class="mb-0 fw-bold text-white">
            <i class="bi bi-terminal me-2 text-danger"></i> PHP & Apache Error Log (Last 50 Lines)
        </h6>
        <div class="d-flex gap-2">
            <form method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus semua catatan log?');">
                <button type="submit" name="clear_log" class="btn btn-outline-light btn-sm py-0 shadow-sm" style="font-size: 0.75rem;">
                    <i class="bi bi-trash me-1"></i> Clear Log
                </button>
            </form>
            <button onclick="location.reload();" class="btn btn-outline-info btn-sm py-0 shadow-sm" style="font-size: 0.75rem;">
                <i class="bi bi-arrow-clockwise me-1"></i> Refresh
            </button>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="log-container" style="background: #1e1e1e; max-height: 400px; overflow-y: auto; padding: 15px;">
            <pre class="mb-0" style="color: #dcdccc; font-family: 'Courier New', Courier, monospace; font-size: 12px; white-space: pre-wrap; word-wrap: break-word;"><?php 
                $logs = getPHPErrors($user_target);
                echo htmlspecialchars($logs); 
            ?></pre>
        </div>
        <div class="card-footer bg-light border-0 py-2">
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-muted" style="font-size: 0.7rem;">
                    <i class="bi bi-file-earmark-ruled me-1"></i> 
                    Path: <code>/var/log/apache2/<?php echo $user_target; ?>_error.log</code>
                </small>
                <span class="badge bg-secondary" style="font-size: 0.6rem;">REAL-TIME MONITORING</span>
            </div>
        </div>
    </div>
</div>
    <form method="POST">
        <div class="plesk-card border-primary mb-4">
            <div class="plesk-card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <span><i class="bi bi-sliders2-vertical me-2"></i> PHP Configuration Manager</span>
                <button type="button" class="btn btn-sm btn-light py-0 px-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#rawIniModal" style="font-size: 0.75rem;">
                    <i class="bi bi-file-earmark-code me-1"></i> Edit Manual (.ini)
                </button>
            </div>
            
            <div class="p-4">
                <h6 class="fw-bold border-bottom pb-2 mb-3 text-danger small text-uppercase"><i class="bi bi-shield-lock me-2"></i> Performance & Security Settings</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label small text-danger fw-bold">disable_functions</label>
                        <input type="text" name="settings[disable_functions]" class="form-control form-control-sm" value="<?php echo $current_val['disable_functions']; ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">open_basedir</label>
                        <input type="text" name="settings[open_basedir]" class="form-control form-control-sm" value="<?php echo $current_val['open_basedir']; ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">display_errors</label>
                        <select name="settings[display_errors]" class="form-select form-select-sm">
                            <option value="On" <?php echo $current_val['display_errors']=='On'?'selected':''; ?>>On (Debug)</option>
                            <option value="Off" <?php echo $current_val['display_errors']=='Off'?'selected':''; ?>>Off (Production)</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">allow_url_fopen</label>
                        <select name="settings[allow_url_fopen]" class="form-select form-select-sm">
                            <option value="On" <?php echo $current_val['allow_url_fopen']=='On'?'selected':''; ?>>Enabled</option>
                            <option value="Off" <?php echo $current_val['allow_url_fopen']=='Off'?'selected':''; ?>>Disabled</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">opcache.enable</label>
                        <select name="settings[opcache.enable]" class="form-select form-select-sm">
                            <option value="1" <?php echo $current_val['opcache.enable']=='1'?'selected':''; ?>>Enabled</option>
                            <option value="0" <?php echo $current_val['opcache.enable']=='0'?'selected':''; ?>>Disabled</option>
                        </select>
                    </div>
                </div>

                <h6 class="fw-bold border-bottom pb-2 mb-3 text-secondary small text-uppercase"><i class="bi bi-list-check me-2"></i> Common Settings</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <label class="form-label small">memory_limit</label>
                        <select name="settings[memory_limit]" class="form-select form-select-sm">
                            <?php foreach(['64M','128M','256M','512M','1024M'] as $o) echo "<option value='$o' ".($current_val['memory_limit']==$o?'selected':'').">$o</option>"; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">upload_max_filesize</label>
                        <select name="settings[upload_max_filesize]" class="form-select form-select-sm">
                            <?php foreach(['2M','10M','50M','100M','500M'] as $o) echo "<option value='$o' ".($current_val['upload_max_filesize']==$o?'selected':'').">$o</option>"; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">max_execution_time</label>
                        <input type="number" name="settings[max_execution_time]" class="form-control form-control-sm" value="<?php echo $current_val['max_execution_time']; ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small">max_input_vars</label>
                        <input type="number" name="settings[max_input_vars]" class="form-control form-control-sm" value="<?php echo $current_val['max_input_vars']; ?>">
                    </div>
                </div>

                <h6 class="fw-bold border-bottom pb-2 mb-3 text-success small text-uppercase"><i class="bi bi-server me-2"></i> PHP FPM Settings</h6>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label small">zlib.output_compression</label>
                        <select name="settings[zlib.output_compression]" class="form-select form-select-sm">
                            <option value="On" <?php echo $current_val['zlib.output_compression']=='On'?'selected':''; ?>>On</option>
                            <option value="Off" <?php echo $current_val['zlib.output_compression']=='Off'?'selected':''; ?>>Off</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">session.gc_maxlifetime</label>
                        <input type="number" name="settings[session.gc_maxlifetime]" class="form-control form-control-sm" value="<?php echo $current_val['session.gc_maxlifetime']; ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">short_open_tag</label>
                        <select name="settings[short_open_tag]" class="form-select form-select-sm">
                            <option value="On" <?php echo $current_val['short_open_tag']=='On'?'selected':''; ?>>On</option>
                            <option value="Off" <?php echo $current_val['short_open_tag']=='Off'?'selected':''; ?>>Off</option>
                        </select>
                    </div>
                </div>

                <br/>
                <h6 class="fw-bold border-bottom pb-2 mb-3 text-info small text-uppercase"><i class="bi bi-lightning-charge-fill me-2"></i> FastCGI Settings</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="form-label small">cgi.fix_pathinfo</label>
                        <select name="settings[cgi.fix_pathinfo]" class="form-select form-select-sm">
                            <option value="1" <?php echo $current_val['cgi.fix_pathinfo']=='1'?'selected':''; ?>>1 (Recommended)</option>
                            <option value="0" <?php echo $current_val['cgi.fix_pathinfo']=='0'?'selected':''; ?>>0</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">fastcgi.logging</label>
                        <select name="settings[fastcgi.logging]" class="form-select form-select-sm">
                            <option value="1" <?php echo $current_val['fastcgi.logging']=='1'?'selected':''; ?>>Enabled</option>
                            <option value="0" <?php echo $current_val['fastcgi.logging']=='0'?'selected':''; ?>>Disabled</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small">max_input_time</label>
                        <input type="number" name="settings[max_input_time]" class="form-control form-control-sm" value="<?php echo $current_val['max_input_time']; ?>">
                    </div>
                </div>

                <div class="mt-4 pt-3 border-top text-end">
                    <button name="save_php_settings" class="btn btn-primary px-5 shadow-sm">
                        <i class="bi bi-save me-2"></i> Update Configuration
                    </button>
                </div>
            </div>
        </div>
    </form>

    <div class="plesk-card border-0 bg-white shadow-sm mb-5">
        <div class="plesk-card-header bg-dark text-white"><i class="bi bi-book me-2"></i> Dokumentasi Fitur PHP Manager</div>
        <div class="p-4">
            <div class="row g-4">
                <div class="col-md-6">
                    <h6 class="fw-bold text-primary"><i class="bi bi-cpu"></i> 1. PHP Version Switcher</h6>
                    <ul class="small text-muted">
                        <li><strong>Fitur:</strong> Memungkinkan perpindahan versi PHP yang tersedia di sistem secara instan.</li>
                        <li><strong>Stabilitas:</strong> Hanya menampilkan versi yang sudah dikonfigurasi oleh Administrator untuk memastikan performa website tetap terjaga.</li>
                        <li><strong>Integrasi:</strong> Otomatis memperbarui file VirtualHost Apache dan reload service terkait.</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6 class="fw-bold text-success"><i class="bi bi-file-earmark-text"></i> 2. PHP Configuration Manager (.user.ini)</h6>
                    <ul class="small text-muted">
                        <li><strong>Fitur:</strong> Mengatur variabel <code>php.ini</code> secara spesifik untuk website user ini tanpa mengganggu website lain.</li>
                        <li><strong>Keamanan:</strong> Dilengkapi fitur <code>disable_functions</code> untuk mematikan fungsi berbahaya dan <code>open_basedir</code> untuk mengunci akses folder.</li>
                        <li><strong>Performa:</strong> Pengaturan <code>opcache</code> dan <code>memory_limit</code> yang dapat disesuaikan untuk kebutuhan aplikasi berat.</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6 class="fw-bold text-warning"><i class="bi bi-code-square"></i> 3. Raw Editor Mode</h6>
                    <ul class="small text-muted">
                        <li><strong>Fitur:</strong> Editor berbasis teks (Modal) untuk memasukkan konfigurasi PHP custom yang tidak tersedia di form input biasa.</li>
                        <li><strong>Fleksibilitas:</strong> Berguna bagi developer yang ingin menambahkan parameter khusus seperti <code>auto_prepend_file</code> atau pengaturan ekstensi spesifik.</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h6 class="fw-bold text-info"><i class="bi bi-arrow-repeat"></i> 4. Auto-Sync Service Reload</h6>
                    <ul class="small text-muted">
                        <li><strong>Fitur:</strong> Setiap kali pengaturan disimpan, sistem secara otomatis melakukan <code>reload</code> pada layanan <strong>PHP-FPM</strong> yang sedang aktif.</li>
                        <li><strong>Tanpa Downtime:</strong> Menggunakan perintah <code>reload</code> (bukan restart) untuk memastikan perubahan diterapkan tanpa memutus koneksi user yang sedang aktif.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="rawIniModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST">
            <div class="modal-content bg-dark">
                <div class="modal-header border-secondary text-white">
                    <h6 class="modal-title small"><i class="bi bi-pencil-square me-2"></i> Edit Manual: .user.ini</h6>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-0">
                    <input type="hidden" name="raw_mode" value="1">
                    <textarea name="raw_content" class="form-control font-monospace border-0" rows="15" style="background:#121212; color:#00ff00; padding:20px; font-size: 13px;"><?php 
                        echo file_exists($user_ini_path) ? file_get_contents($user_ini_path) : "; Custom PHP configuration\n"; 
                    ?></textarea>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-sm btn-outline-light" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="save_php_settings" class="btn btn-sm btn-success">Simpan Perubahan</button>
                </div>
            </div>
        </form>
    </div>
</div>

menambahkan dokumentasi lengkap semua fitur yang ada
perbaiki script lengkap tanpa mengubah tampilan dan layout yang sekarang, kecuali hanya untuk menambahkan fitur, tetap pertahankan jangan mengubah atau menghapus fitur yang ada pada PHP Configuration Manager tetap seperti itu jangan dioptimalisasi.