<?php

namespace DJumPer\Platform;

use DJumPer\Client\Client;
use DJumPer\Client\ytClient;
use DJumPer\Utils\Utils;
use Exception;

class Youtube
{
    
    // Guzzle
    private $client;
    private $yt_client;
    private $data = [];
    
    public function __construct()
    {
        $this->client = new Client();
        $this->yt_client = new ytClient();
    }

    private function jsonGetBody($response)
    {
        return $this->client->jsonGetBody($response);;
    }
    
    private function stringGetBody($response)
    {
        return $this->client->stringGetBody($response);
    }

    public function ytUA()
    {
        return $this->data['userAgent'];
    }

    public function ytHeaders()
    {
        $headers = [
            "User-Agent: " . $this->data['userAgent'],
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "Cache-Control: no-cache",
            "Sec-Fetch-Mode: navigate",
            "Range: bytes=0-"
        ];
        return $headers;
    }

    public function ytHandler($clientName = null)
    {
        return $clientName
            ? $this->yt_client->getClientByName($clientName)
            : $this->yt_client->getRandomClient();
    }
    
    private function ytPayload($videoId, $sigTimestamp)
    {
        return [
            "context" => [
                "client" => $this->data['client'],
                "user" => [
                    "lockedSafetyMode" => false
                ],
                "request" => [
                    "useSsl" => true
                ]
            ],
            "videoId" => $videoId,
            "playbackContext" => [
                "contentPlaybackContext" => [
                    "html5Preference" => "HTML5_PREF_WANTS",
                    "signatureTimestamp" => $sigTimestamp
                ]
            ],
            //"params" => "CgIQBg",
            "racyCheckOk" => true,
            "contentCheckOk" => true
        ];
    }

    private function postApi($videoId, $sigTimestamp)
    {
        $apiUrl = "https://www.youtube.com/youtubei/v1/player";
        //$apiUrl = "https://www.youtube.com/youtubei/v1/player?key=" . $this->data['apiKey'];
        //$apiUrl = "https://youtubei.googleapis.com/youtubei/v1/player?key=" . $this->data['apiKey'];
        
        $payload = $this->ytPayload($videoId, $sigTimestamp);
        $response = $this->client->post($apiUrl, [
            "json" => $payload,
            "headers" => array_merge($this->yt_client->clientHeader($this->data), [
                "Accept" => $this->data['acceptHeader'],
                "Accept-Language" => "de,de-DE;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6"
            ])
        ]);
        return $this->jsonGetBody($response);
    }

    private function getVideoId($url)
    {
        preg_match('%(?:youtube\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/\s]{11})%i', $url, $match);
        $videoId = $match[1] ?? null;
        if (!$videoId) { throw new Exception("Video YouTube tidak ditemukan."); }
        return $videoId;
    }

    private function getContent($videoId, $userAgent)
    {
        $apiUrl = "https://www.youtube.com/watch?v=";
        $response = $this->client->get($apiUrl . $videoId, [
            'headers' => [
                'User-Agent' => $userAgent,
                'Origin' => 'https://www.youtube.com'
            ]
        ]);        
        return $this->stringGetBody($response);
    }

    private function contentData($content)
    {
        $client = []; $visitorData = null; $apiKey = null;
        $sigTimestamp = null; $jsUrl = null; $ytcfgArray = [];
        
        $pattern = '/ytcfg\.set\(\s*({.*?})\s*\)\s*;/s';
        preg_match($pattern, $content, $ytcfg);
        return json_decode($ytcfg[1], true);
    }

    private function getBaseJs($jsUrl)
    {
        if (strpos($jsUrl, 'http') !== 0) {
            $jsUrl = "https://www.youtube.com" . $jsUrl;
        }
        $jsResponse = $this->client->get($jsUrl, [
            "headers" => [
                "User-Agent" => $this->data['data']['userAgent']
            ]
        ]);
        return $this->stringGetBody($jsResponse);
    }

    private function getData($videoId, $sigTimestamp, $contentData = null)
    {
        $data = [];
        $data = $this->postApi($videoId, $sigTimestamp) ?? [];
        if(!$data) {
            preg_match('/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/s', $contentData, $matches);
            $data = json_decode($matches[1], true);
        }
        return $data;
    }

    public function scrape($url)
    {

        $platform = 'Youtube'; $title = null; $thumbnail = null;
        $audioUrl = null; $streamingQualities = []; 
        $videoQualities = []; $audioQualities = []; 
        $data = []; $reason = 'OK';

        $client = $this->ytHandler();
        $videoId = $this->getVideoId($url);
        //$getContent = $this->getContent($videoId, $client['data']['userAgent']);
        //$contentData = $this->contentData($getContent);
        //$baseJs = $this->getBaseJs($contentData['PLAYER_JS_URL']);
                
        $this->data = array_merge($client, [
            "acceptHeader" => "*/*"
            //"apiKey" => $client['data']['apiKey'] ?? $contentData['INNERTUBE_API_KEY'],
            //"acceptHeader" => $contentData['INNERTUBE_CONTEXT']['client']['acceptHeader'] ?? "*/*",
            //"visitorData" => $contentData['VISITOR_DATA'],
            //"ytcfg" => $contentData,
            //"baseJs" => $baseJs
        ]);
        
        //$data = $this->getData($videoId, $contentData['STS'], $getContent);
        //$data = $this->postApi($videoId, $contentData['STS']);
        $data = $this->postApi($videoId, 20529);
        
        if (isset($data['playabilityStatus']['status']) && $data['playabilityStatus']['status'] !== 'OK') {
            $reason = $data['playabilityStatus']['reason'] ?? 'Video tidak dapat diputar (Private/Age Restricted).';
            throw new Exception($platform . ": " . $reason);
        }
        
        $videoDetails = $data['videoDetails'] ?? [];
        $title = $videoDetails['title'] ?? $title;
        if (isset($videoDetails['thumbnail']['thumbnails'])) {
            $thumbnail = end($videoDetails['thumbnail']['thumbnails'])['url'];
        }
        
        $streamingData = $data['streamingData'] ?? [];
        $formats = array_merge(
            $streamingData['formats'] ?? [],
            $streamingData['adaptiveFormats'] ?? []
        );
        foreach ($formats as $f) {
            $contentUrl = null;
            if(isset($f['signatureCipher'])){
                parse_str($f['signatureCipher'],$c);
                $contentUrl=$c['url'] ?? null;
                if(isset($c['s'])){
                    $contentUrl.="&".$c['sp']."=".$c['s'];
                }
            }
            elseif (isset($f['url'])) {
                $contentUrl = $f['url'];
            } 
            if (!$contentUrl) {
                throw new Exception("Gagal mengekstrak video. Video mungkin privat atau dihapus.");
            }

            //$streamingUrl =  $streamingData['serverAbrStreamingUrl'];
            $muxed = [36,22,18,17];
            //$muxed = [313];
            $isMuxed = in_array($f['itag'], $muxed);
            $icon = $isMuxed ? "🎥" : "🔇";
            if ($isMuxed) {
                $codec = (strpos($f['mimeType'], 'webm') !== false) ? 'WEBM' : 'MP4';
                $streamingQualities[] = [
                    "type" => strtolower($codec),
                    "url" => $contentUrl
                ];
            }
            
            // Video tanpa suara saja
            if (strpos($f['mimeType'], 'vp') !== false && isset($f['url']) || isset($f['signatureCipher'])) {
                $qualityLabel = isset($f['qualityLabel']) ? $f['qualityLabel'] : 'SD';
                $codec = (strpos($f['mimeType'], 'webm') !== false) ? 'WEBM' : 'MP4';
                $videoQualities[] = [
                    "itag" => $f['itag'],
                    "type" => strtolower($codec),
                    "qualityLabel" => "Video " . $codec . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; " . $icon . $qualityLabel,
                    "url" => $contentUrl
                ];
            }
                    
            // Audio Saja
            if (strpos($f['mimeType'], 'audio/') !== false && !isset($f['xtags']) && isset($f['url']) || isset($f['signatureCipher'])) {
                $bitrate = isset($f['bitrate']) ? round($f['bitrate'] / 1000) : "Unknown";
                $codec = (strpos($f['mimeType'], 'opus') !== false) ? 'OPUS' : 'M4A';
                $space = ($codec == 'OPUS') ? '&nbsp;&nbsp;&nbsp;&nbsp;' : '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                $audioQualities[] = [
                    "itag" => $f['itag'],
                    "type" => strtolower($codec),
                    "qualityLabel" => "Audio " . $codec . " " . $space . " 🎵" . $bitrate,
                    "url" => $contentUrl
                ];
            }
        }
        
        usort($audioQualities, function($a, $b) {
            preg_match('/(\d+)/', $a['qualityLabel'], $matchA);
            preg_match('/(\d+)/', $b['qualityLabel'], $matchB);
            $valA = isset($matchA[1]) ? (int)$matchA[1] : 0;
            $valB = isset($matchB[1]) ? (int)$matchB[1] : 0;
            return $valA <=> $valB;
        });
        
        $title = Utils::cleanString($title);
        return [
            'status' => $reason,
            'platform' => $platform,
            'title' => Utils::limitString($title, 100),
            'thumbnail' => Utils::cleanString($thumbnail),
            'streaming_data' => $streamingQualities,
            'video_data' => $videoQualities,
            'audio_data' => $audioQualities,
            'data' => ['data' => $data, 'client' => $this->data]
        ];
                
    }
    
}