<html>
<head></head>
<body>

<div class="card shadow-sm border-0 rounded-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between">
        <h6 class="mb-0">WhatsApp QR Scan</h6>
        <span id="qr-status" class="badge bg-light text-primary">Menghubungkan...</span>
    </div>
    <div class="card-body text-center p-4">
        <div id="qr-container">
            <div class="spinner-border text-primary" role="status"></div>
            <p class="text-muted mt-2">Menunggu respons server...</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const qrStatus = document.getElementById('qr-status');
    const qrContainer = document.getElementById('qr-container');

    if (qrStatus && qrContainer) {
        getQRCode();
        setInterval(getQRCode, 5000);
    } else {
        console.error("Elemen qr-status atau qr-container tidak ditemukan di HTML!");
    }
});
async function refreshQR() {
    try {
        const response = await fetch('http://kontol.localhost:5000/start-session?session=arf&scan=true');
        const data = await response.json();

        if (data.qr) {
            document.getElementById('qr-container').innerHTML = `
                <img src="${data.qr}" class="img-fluid shadow-sm rounded" style="max-width: 250px;" />
            `;
            document.getElementById('qr-status').innerText = "Silakan Scan";
        }
    } catch (err) {
        console.warn("QR belum siap atau server offline...");
    }
}
refreshQR();
setInterval(refreshQR, 15000);
</script>

</body>
</html>