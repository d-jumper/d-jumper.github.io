<?php

namespace DJumPer\Client;

use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Cookie\CookieJar;

class Client
{

    // Guzzle
    public $client;
    public $jar;
    
    public function __construct()
    {

        $this->jar = new CookieJar();
        $this->client = new GuzzleClient([
            'timeout'  => 30.0,
            'verify'   => false,
            'cookies'  => $this->jar,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language' => 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                'Cache-Control' => 'no-cache',
                'Sec-Fetch-Mode' => 'navigate',
            ],
        ]);
    }
    
    public function get($url, array $options = [])
    {
        return $this->client->get($url, $options);
    }
    
    public function post($url, array $options = [])
    {
        return $this->client->post($url, $options);
    }

    public function stringGetBody($response)
    {
        return (string)$response->getBody();
    }

    public function jsonGetBody($response)
    {
        return json_decode($response->getBody(), true);
    }

    public function jar($response)
    {
        return $this->jar->toArray();
    }

}