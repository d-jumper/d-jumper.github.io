<?php
/**
 * AUTHENTICATION & ROUTING
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
} else {
    $id_session = $_SESSION['user_id'];
    $user_session = $_SESSION['user'];
    $role_user = $_SESSION['role'];
    require_once('csrf_token.php');
}

?>