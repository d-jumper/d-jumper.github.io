<?php
set_time_limit(0);
error_reporting(E_ALL);
ini_set('display_errors', 1);

$video = "https://rr3---sn-poqvn5u-jb3y.googlevideo.com/videoplayback?expire=1773346876&ei=3MuyafKuDezKssUPm92hqAE&ip=114.10.28.96&id=o-AKbkdUBOaC7kChm92K_d8XDQg6gOj8A1w0zusg4NzQgb&itag=137&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&cps=729&met=1773325276%2C&mh=jp&mm=31%2C26&mn=sn-poqvn5u-jb3y%2Csn-oguelnsz&ms=au%2Conr&mv=m&mvi=3&pl=23&rms=au%2Cau&initcwndbps=351250&bui=AVNa5-yDXOgrPg-2DpP6kf4wH70zqJlLaGwNzs1HCr3O8XaPrDh4hoXt--5SyhCX1DbP023RWPVsgDkI&spc=6dlaFIhj5-AUdkUkZ42ar71_8ZfSHIakauJhu-v7SgC096mQf6f7Ah4Ggtpw7JC9&vprv=1&svpuc=1&mime=video%2Fmp4&rqh=1&gir=yes&clen=21414715&dur=313.566&lmt=1773012332813809&mt=1773324829&fvip=3&keepalive=yes&fexp=51565116%2C51565682%2C51791334&c=ANDROID&txp=5535534&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AHEqNM4wRQIhAIFSRuIlUvUVMCLv4Asr1Iywlis-K3uR0GTtJz0iLRpiAiBM2pH-sVEYM7FXyfViPpN8c0bVbCFU5RDscRxtcxu7tg%3D%3D&lsparams=cps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRgIhAOKo1NDTPjomSCKGTquYYSgNbM87Tf8h0Yb-kQeiy4f-AiEAqhdoLmzkaHnPRnzdE-sPIq6yxHD3xXDXidb0Vx5ylQc%3D";

$audio = "https://rr3---sn-poqvn5u-jb3y.googlevideo.com/videoplayback?expire=1773346876&ei=3MuyafKuDezKssUPm92hqAE&ip=114.10.28.96&id=o-AKbkdUBOaC7kChm92K_d8XDQg6gOj8A1w0zusg4NzQgb&itag=140&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&cps=729&met=1773325276%2C&mh=jp&mm=31%2C26&mn=sn-poqvn5u-jb3y%2Csn-oguelnsz&ms=au%2Conr&mv=m&mvi=3&pl=23&rms=au%2Cau&initcwndbps=351250&bui=AVNa5-yDXOgrPg-2DpP6kf4wH70zqJlLaGwNzs1HCr3O8XaPrDh4hoXt--5SyhCX1DbP023RWPVsgDkI&spc=6dlaFIhj5-AUdkUkZ42ar71_8ZfSHIakauJhu-v7SgC096mQf6f7Ah4Ggtpw7JC9&vprv=1&svpuc=1&mime=audio%2Fmp4&rqh=1&gir=yes&clen=5076981&dur=313.655&lmt=1773010845129516&mt=1773324829&fvip=3&keepalive=yes&fexp=51565116%2C51565682%2C51791334&c=ANDROID&txp=5532534&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cxpc%2Cbui%2Cspc%2Cvprv%2Csvpuc%2Cmime%2Crqh%2Cgir%2Cclen%2Cdur%2Clmt&sig=AHEqNM4wRQIgfAGD12hkH1kE0dkVHd5FAvt4oWBuswNXOZLKmgGjgoYCIQCUNadqv_qngjyU8QzoqcfCL6MKQBkQI1XaoRb-MorzYQ%3D%3D&lsparams=cps%2Cmet%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=APaTxxMwRgIhAOKo1NDTPjomSCKGTquYYSgNbM87Tf8h0Yb-kQeiy4f-AiEAqhdoLmzkaHnPRnzdE-sPIq6yxHD3xXDXidb0Vx5ylQc%3D";

$ua = "com.google.android.youtube/20.42.40 (Linux; U; Android 14)";

while (ob_get_level()) { ob_end_clean(); }

// Set header agar browser mengenali ini sebagai video MP4
header('Content-Type: video/mp4');
header('Cache-Control: no-cache');
// Jika ingin memaksa download, gunakan header di bawah ini:
// header('Content-Disposition: attachment; filename="video_gabungan.mp4"');

// Susun perintah FFmpeg
// 1. -headers: Mengirim User-Agent yang sama agar tidak ditolak YouTube (403)
// 2. -i: Input URL langsung ke FFmpeg
// 3. -c copy: Menyalin codec asli tanpa re-encode (proses instan dan tidak membebani CPU)
// 4. -f mp4 -movflags frag_keyframe+empty_moov: Syarat wajib agar MP4 bisa di-stream langsung (piped)
// 5. pipe:1 : Meneruskan hasil gabungan langsung ke stdout (PHP akan merespons ke browser)

$ffmpeg_cmd = sprintf(
    'ffmpeg -hide_banner -loglevel error -headers "User-Agent: %s\r\n" -i %s -headers "User-Agent: %s\r\n" -i %s -c:v copy -c:a copy -map 0:v:0 -map 1:a:0 -f mp4 -movflags frag_keyframe+empty_moov pipe:1',
    $ua,
    escapeshellarg($video),
    $ua,
    escapeshellarg($audio)
);

// Eksekusi FFmpeg dan alirkan (stream) hasilnya langsung ke browser
passthru($ffmpeg_cmd);

// Hentikan script setelah selesai
exit();