<?php
date_default_timezone_set('Asia/Jakarta');
require_once 'vendor/autoload.php'; // Pastikan composer autoload atau require file manual
use DJumPer\Downloader;

$downloader = new Downloader();

// Daftar URL sample yang valid untuk ditest (Ganti dengan URL yang aktif)
$test_cases = [
    'YouTube'   => 'https://youtu.be/Zv11L-ZfrSg',
    'TikTok'    => 'https://vt.tiktok.com/ZSmgDqskg/', 
    'Facebook'  => 'https://www.facebook.com/share/r/1AhaFwD36s/',
    'Instagram' => 'https://www.instagram.com/reel/DUcUvd4j1CE/'
];

$results = [];

foreach ($test_cases as $platform => $url) {
    $start_time = microtime(true);
    try {
        $info = $downloader->getVideoInfo($url, 'getData');
        $duration = round(microtime(true) - $start_time, 2);
        
        if (!empty($info['video_data'])) {
            $results[$platform] = [
                'status' => '✅ BERHASIL',
                'time' => $duration . 's',
                'title' => $info['title'],
                'message' => 'Scraper berfungsi normal.'
            ];
        } else {
            throw new Exception("URL ditemukan tapi kosong.");
        }
    } catch (Exception $e) {
        $results[$platform] = [
            'status' => '❌ GAGAL',
            'time' => '0s',
            'title' => '-',
            'message' => $e->getMessage()
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>System Health Check - Scraper</title>
    <style>
        body { font-family: sans-serif; background: #f4f4f9; padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background: #333; color: #fff; }
        .berhasil { color: green; font-weight: bold; }
        .gagal { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h1>Scraper Status Dashboard</h1>
    <p>Terakhir diperiksa: <?php echo date('d-m-Y H:i:s'); ?></p>
    
    <table>
        <thead>
            <tr>
                <th>Platform</th>
                <th>Status</th>
                <th>Respon Time</th>
                <th>Sample Title</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($results as $platform => $res): ?>
            <tr>
                <td><strong><?php echo $platform; ?></strong></td>
                <td class="<?php echo strpos($res['status'], 'BERHASIL') !== false ? 'berhasil' : 'gagal'; ?>">
                    <?php echo $res['status']; ?>
                </td>
                <td><?php echo $res['time']; ?></td>
                <td><?php echo $res['title']; ?></td>
                <td><?php echo $res['message']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>