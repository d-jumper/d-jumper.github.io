<?php
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    $_SESSION = array();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --plesk-blue: #00a8e0; --sidebar-bg: #2d3e50; }
        body { background-color: #f5f7f9; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }
        /* Sidebar Styling */
        #sidebar { 
            width: 241px; 
            height: 100vh; 
            position: fixed; 
            background: var(--sidebar-bg); 
            color: white; 
            z-index: 1000;
            transition: all 0.3s;
        }
        .sidebar-header { padding: 20px; background: rgba(0,0,0,0.2); color: white; border-bottom: 1px solid #3e5165; }
        .nav-link { color: #abbac3; padding: 12px 20px; display: flex; align-items: center; text-decoration: none; border-left: 4px solid transparent; cursor: pointer; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { background: #36495e; color: white; border-left-color: var(--plesk-blue); }
        .nav-link i { margin-right: 0px; width: 20px; text-align: center; }
        .submenu { list-style: none; padding: 0; background: rgba(0,0,0,0.15); }
        .submenu .nav-link { padding-left: 50px; font-size: 0.85rem; border-left: none; }
        .submenu .nav-link:hover { background: rgba(255,255,255,0.05); }
        /* Keadaan ketika Sidebar Tertutup (Collapsed) */
        body.sidebar-toggled #sidebar {
            margin-left: -241px; /* Menggeser sidebar keluar layar */
        }
        
        body.sidebar-toggled #main-content {
            margin-left: 0; /* Konten memenuhi layar */
        }
        /* Main Content Styling */
        #main-content { 
            margin-left: 241px; 
            padding: 30px; 
            transition: all 0.3s;
        }
        /* Mobile Header / Toggle Bar */
        .mobile-header {
            display: none;
            background: var(--sidebar-bg);
            color: white;
            padding: 10px 15px;
            align-items: center;
            justify-content: space-between;
        }
        /* Responsive Logic */
        @media (max-width: 768px) {
            .mobile-header { display: flex; }
            #sidebar { margin-left: -241px; }
            #main-content { margin-left: 0; }
            
            /* Class saat sidebar dibuka di mobile */
            #sidebar.active { margin-left: 0; }
            
            /* Overlay saat sidebar aktif */
            .sidebar-overlay {
                display: none;
                position: fixed;
                width: 100vw;
                height: 100vh;
                background: rgba(0,0,0,0.5);
                z-index: 999;
            }
            .sidebar-overlay.active { display: block; }
            body.sidebar-toggled #sidebar {
                margin-left: 0; /* Di mobile, klik toggle justru memunculkan sidebar */
            }
            
        }
        .plesk-card { background: white; border: 1px solid #e1e4e8; border-radius: 4px; margin-bottom: 25px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .plesk-card-header { padding: 12px 20px; border-bottom: 1px solid #f0f2f5; background: #fafbfc; color: var(--plesk-blue); font-weight: bold; }
        .plesk-header { padding: 12px 20px; border-bottom: 1px solid #f0f2f5; font-weight: 600; background: #fafbfc; color: #333; }
        .grid-menu { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 12px; padding: 20px; }
        .grid-item { border: 1px solid #eee; border-radius: 8px; padding: 15px 5px; text-align: center; color: #555; text-decoration: none; transition: 0.2s; font-size: 0.8rem; }
        .grid-item:hover { background: #f0f8ff; border-color: var(--plesk-blue); color: var(--plesk-blue); transform: translateY(-2px); }
        .grid-item i { font-size: 1.8rem; display: block; margin-bottom: 8px; }
        .stat-icon { width: 42px; height: 42px; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 1.2rem; }
        .progress-label { display: flex; justify-content: space-between; font-size: 0.85rem; margin-bottom: 6px; }
        #sidebar .nav-link { color: #abbac3; padding: 15px 20px; border-bottom: 1px solid #36495e; text-decoration: none; display: block; }
        #sidebar .nav-link.active { background: #36495e; border-left: 4px solid var(--plesk-blue); color: white; }
    </style>
    
</head>
<body>

<div class="mobile-header">
    <h5 class="mb-0"></h5>
    <button class="btn btn-outline-light btn-sm" onclick="toggleSidebar()">
        <i class="bi bi-list"></i>
    </button>
</div>

<div id="sidebar">
    <div class="sidebar-header"><i class="bi bi-cpu-fill text-info me-2"></i><span class="fw-bold">Control Panel</span></div>
    
    <a href="?page=home" class="nav-link <?php echo $page=='home'?'active':''; ?>"><i class="bi bi-speedometer2"></i> Home</a>
    <div class="nav-link <?php echo in_array($page,['domains'])?'active':''; ?>" data-bs-toggle="collapse" data-bs-target="#hostingSub">
        <i class="bi bi-hdd-network"></i> Hosting Service <i class="bi bi-chevron-down ms-auto small"></i>
    </div>
    <div class="collapse <?php echo in_array($page,['domains'])?'show':''; ?>" id="hostingSub">
        <ul class="submenu">
            <li><a href="?page=domains" class="nav-link <?php echo $page=='domains'?'active':''; ?>"><i class="bi bi-globe"></i> Users & Domain</a></li>
        </ul>
    </div>
    <div class="nav-link <?php echo in_array($page,['settings','stats','extensions','wordpress','monitoring','laravel'])?'active':''; ?>" data-bs-toggle="collapse" data-bs-target="#mgmtSub">
        <i class="bi bi-tools"></i> Services Management <i class="bi bi-chevron-down ms-auto small"></i>
    </div>
    <div class="collapse <?php echo in_array($page,['settings','stats','extensions','wordpress','monitoring','laravel'])?'show':''; ?>" id="mgmtSub">
        <ul class="submenu">
            <li><a href="?page=settings" class="nav-link <?php echo $page=='settings'?'active':''; ?>"><i class="bi bi-gear"></i> Tools & Settings</a></li>
            <li><a href="?page=stats" class="nav-link <?php echo $page=='stats'?'active':''; ?>"><i class="bi bi-graph-up"></i> Statistics</a></li>
            <li><a href="?page=extensions" class="nav-link <?php echo $page=='extensions'?'active':''; ?>"><i class="bi bi-puzzle"></i> Extensions</a></li>
            <li><a href="?page=services" class="nav-link <?php echo $page=='services'?'active':''; ?>"><i class="bi bi-puzzle"></i> Installer</a></li>
            <li><a href="?page=wordpress" class="nav-link <?php echo $page=='wordpress'?'active':''; ?>"><i class="bi bi-wordpress"></i> WordPress</a></li>
            <li><a href="?page=monitoring" class="nav-link <?php echo $page=='monitoring'?'active':''; ?>"><i class="bi bi-eye"></i> Monitoring</a></li>
            <li><a href="?page=laravel" class="nav-link <?php echo $page=='laravel'?'active':''; ?>"><i class="bi bi-box-seam"></i> Laravel</a></li>
        </ul>
    </div>
    <div class="nav-link <?php echo in_array($page,['profile'])?'active':''; ?>" data-bs-toggle="collapse" data-bs-target="#profileSub">
        <i class="bi bi-person-circle"></i> My Profiles <i class="bi bi-chevron-down ms-auto small"></i>
    </div>
    <div class="collapse <?php echo in_array($page,['profile'])?'show':''; ?>" id="profileSub">
        <ul class="submenu">
            <li><a href="?page=profile" class="nav-link <?php echo $page=='profile'?'active':''; ?>"><i class="bi bi-person-gear"></i> Profiles & Preferences</a></li>
        </ul>
    </div>
    <a href="?action=logout" class="nav-link text-danger mt-4" style="border-bottom: none;" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
        <i class="bi bi-box-arrow-right"></i> Logout
    </a>
</div>

<div id="main-content">

    <button class="btn btn-light shadow-sm mb-3 d-none d-md-block" onclick="toggleSidebarDesktop()">
        <i class="bi bi-list"></i>
    </button>
    