<?php header("HTTP/1.1 Maintenance"); ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>404 Not Found - Server System</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
        <style>
            :root { --plesk-blue: #00a8e0; --sidebar-bg: #2d3e50; }
            body { background-color: #f5f7f9; font-family: "Segoe UI", sans-serif; height: 100vh; display: flex; align-items: center; justify-content: center; margin: 0; }
            .error-container { max-width: 600px; width: 90%; text-align: center; }
            .plesk-card { background: white; border: 1px solid #e1e4e8; border-radius: 4px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow: hidden;}
            .plesk-card-header { padding: 15px 20px; border-bottom: 1px solid #f0f2f5; background: #fafbfc; color: var(--sidebar-bg); font-weight: bold; display: flex; align-items: center; justify-content: center; gap: 10px; }
            .card-body { padding: 40px 20px; }
            .error-code { font-size: 80px; font-weight: 800; color: var(--plesk-blue); line-height: 1;margin-bottom: 10px;}
            .error-title { font-size: 1.5rem; font-weight: 600; color: #333; margin-bottom: 20px; }
            .error-text { color: #666; margin-bottom: 30px; line-height: 1.6; }
            .btn-plesk { background-color: var(--plesk-blue); color: white; border: none; padding: 10px 25px; border-radius: 4px; font-weight: 600; transition: 0.3s; }
            .btn-plesk:hover { background-color: #008dbd; color: white; transform: translateY(-2px); }
            .server-footer { margin-top: 20px; font-size: 0.85rem; color: #abbac3; }
        </style>
    </head>
    <body>
    <div class="error-container">
        <div class="plesk-card">
            <div class="plesk-card-header">
                <i class="bi bi-exclamation-triangle-fill text-warning"></i>
                SERVER STATUS SYSTEM
            </div>
            <div class="card-body">
                <div class="error-code">MAINTENANCE</div>
                <h2 class="error-title">SERVER</h2>
                <p class="error-text">
                    Server under maintenance...
                </p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
