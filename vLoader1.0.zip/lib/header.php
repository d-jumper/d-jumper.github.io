<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>V-Loader || Advanced Video Downloader</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #3a7bd5;
            --secondary: #00d2ff;
            --accent: #d946ef;
            --bg-body: #f8fafc;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --card-bg: rgba(255, 255, 255, 0.8);
            --input-bg: #ffffff;
            --border-color: #e2e8f0;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body { 
            font-family: 'Inter', sans-serif; 
            background: linear-gradient(135deg, #f0f4f8 0%, #e2e8f0 100%);
            color: var(--text-main); 
            line-height: 1.6;
            min-height: 100vh;
        }

        .container { max-width: 900px; margin: 0 auto; padding: 40px 20px; }

        /* Header Styles */
        header { text-align: center; margin-bottom: 50px; }
        header h1 { 
            font-size: clamp(2.5rem, 8vw, 3.5rem); 
            font-weight: 800; 
            background: linear-gradient(135deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
            letter-spacing: -1px;
        }
        header p { color: var(--text-muted); font-size: 1.1rem; font-weight: 400; }

        /* Card & Form Styles */
        .glass-card { 
            background: var(--card-bg);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 28px;
            padding: clamp(20px, 5vw, 40px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 10px 10px -5px rgba(0, 0, 0, 0.02);
            margin-bottom: 40px;
        }

        .search-form { display: flex; gap: 12px; margin-top: 20px; flex-wrap: wrap; }
        .search-form input { 
            flex: 1; 
            padding: 18px 24px; 
            border-radius: 16px; 
            border: 2px solid var(--border-color);
            background: var(--input-bg);
            color: var(--text-main);
            font-size: 1rem;
            transition: all 0.3s ease;
            min-width: 280px;
        }
        .search-form input:focus { 
            border-color: var(--primary); 
            outline: none; 
            box-shadow: 0 0 0 4px rgba(58, 123, 213, 0.1);
        }
        .search-form button { 
            padding: 16px 36px; 
            border-radius: 16px; 
            border: none; 
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; 
            font-weight: 700; 
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(58, 123, 213, 0.3);
        }
        .search-form button:hover { 
            transform: translateY(-2px); 
            box-shadow: 0 8px 15px rgba(58, 123, 213, 0.4); 
            filter: brightness(1.05);
        }

        /* Results Styles */
        .result-container { 
            display: grid; 
            grid-template-columns: 1fr; 
            gap: 30px; 
            margin-top: 30px; 
        }
        
        @media (min-width: 768px) { 
            .result-container { 
                grid-template-columns: 1fr 1fr; 
            }
            .video-preview {
                height: 300px;
            }
        }
                        
        .video-preview {
            width: 100%;
            min-height: 300px;
            height: 150px;
            border-radius: 20px; 
            overflow: hidden; 
            background: #000; 
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .video-preview video { 
            width: 100%; 
            height: auto;
            max-height: 70vh;
            display: block; 
            object-fit: contain; 
        }

        #sharing-main-video-el {
            width: 100%;
            height: 100%;
            object-fit: contain; 
            background: #000;
        }
        
        .badge { 
            display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 50px; 
            font-size: 0.8rem; font-weight: 700; text-transform: uppercase; margin-bottom: 12px;
            background: #eff6ff; color: var(--primary); border: 1px solid #dbeafe;
        }

        .video-details h2 { font-size: 1.4rem; font-weight: 700; line-height: 1.4; color: var(--text-main); margin-bottom: 20px; }

        .form-select {
            width: 100%; padding: 14px; border-radius: 12px; background: #f1f5f9;
            border: 1px solid var(--border-color); color: var(--text-main); margin-bottom: 20px;
            font-family: inherit; font-size: 0.95rem; outline: none; transition: border 0.3s;
        }
        .form-select:focus { border-color: var(--primary); }

        .dl-btn { 
            display: flex; align-items: center; justify-content: center; gap: 10px;
            width: 100%; background: var(--accent);
            color: #fff; padding: 18px; border-radius: 16px; text-decoration: none;
            font-weight: 700; transition: all 0.3s ease; border: none; cursor: pointer;
            box-shadow: 0 4px 14px rgba(217, 70, 239, 0.3);
        }
        .dl-btn:hover { background: #c026d3; transform: translateY(-2px); box-shadow: 0 8px 20px rgba(217, 70, 239, 0.4); }

        /* About Section */
        .about-section { margin-top: 80px; text-align: center; }
        .about-section h2 { font-size: 2rem; font-weight: 800; margin-bottom: 15px; }
        .features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 24px; margin-top: 40px; }
        .feature-item { 
            padding: 30px; 
            background: #ffffff; 
            border-radius: 24px; 
            border: 1px solid var(--border-color);
            transition: transform 0.3s;
        }
        .feature-item:hover { transform: translateY(-5px); }
        .feature-item i { font-size: 2.5rem; color: var(--primary); margin-bottom: 20px; display: block; }
        .feature-item h3 { margin-bottom: 12px; font-size: 1.15rem; font-weight: 700; }
        .feature-item p { font-size: 0.95rem; color: var(--text-muted); }

        .alert { 
            padding: 16px; border-radius: 16px; background: #fef2f2; color: #dc2626; 
            border: 1px solid #fecaca; margin-top: 20px; font-weight: 500;
        }
        
        /* Loading Animation */
        .fa-spin { margin-right: 8px; }

        /* Footer Styles */
        footer { 
            margin-top: 60px; 
            padding-bottom: 40px;
            text-align: center; 
            color: var(--text-muted); 
            font-size: 0.85rem; 
        }

        .donation-section {
            margin-top: 50px;
            padding: 30px 20px;
            background: rgba(58, 123, 213, 0.05);
            border-radius: 24px;
            text-align: center;
            border: 1px dashed var(--border-color);
        }

        .donation-section p {
            color: var(--text-muted);
            font-size: 0.95rem;
            margin-bottom: 20px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.5;
        }

        .donation-container {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .coffee-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 24px;
            background: #FFDD00;
            color: #000000;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.9rem;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(0,0,0,0.05);
        }

        .trakteer-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 24px;
            background: #be1e2d;
            color: #ffffff;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.9rem;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .coffee-btn:hover, .trakteer-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>V-Loader</h1>
        <p>Video Downloader - Unduh Video Favorit Anda Tanpa Batas</p>
    </header>