<?php
ob_start();
session_start();
require_once('lib/session_login.php');
require_once('config.php');
require_once('lib/function.php');

/**
 * AUTHENTICATION & ROUTING
 */
if ($_SESSION['role'] === 'user') {
    $page = 'domains';
}
if ($_SESSION['role'] === 'admin' && $page === 'manage' && !isset($_GET['id'])) {
    header("$direct_url&status=danger&msg=User+not+found!!");
    exit();
}

/**
 * AJAX HANDLER: ACTION WITH PROGRESS
 */
if ($_SESSION['role'] === 'admin') {
    $log_dir = $path_logs . "panel/" . $user_session . "/";
    if (!is_dir($log_dir)) {
        mkdir($log_dir, 0755, true);
        shell_exec("sudo chown " . escapeshellarg($user_session) . ":" . escapeshellarg($user_session) . " " . escapeshellarg($log_dir));
    }
    if (isset($_POST['action_with_progress'])) {
        while (ob_get_level()) ob_end_clean(); 
        header('Content-Type: application/json');
    
        $action = $_POST['action_type'] ?? '';
        $task_id = $_POST['task_id'] ?? $user_session;
        
        $logFile = $log_dir . "domainManage_" . preg_replace('/[^a-z0-9]/i', '', $task_id) . ".log";
        file_put_contents($logFile, "Initializing\n");
        chmod($logFile, 0666);
        
        $stopWithError = function($msg) use ($logFile) {
            file_put_contents($logFile, "ERROR: $msg\n", FILE_APPEND);
            echo json_encode(['status' => 'error', 'message' => $msg]);
            exit();
        };
        file_put_contents($logFile, "Processing\n");
        
        if ($action == 'add_web' || $action == 'add_subdomain') {
            $new_u = $_POST['username'] ?? '';
            $email_user = $_POST['email'] ?? '';
            $password_user = $_POST['password'] ?? '';
            $php_version = $_POST['php_version'] ?? '';
            $type_server = $_POST['type_server'] ?? '';
            if(!empty($password_user)) { $pwd_hash = password_hash($password_user, PASSWORD_DEFAULT); }
            if(empty($new_u) || strlen($new_u) < 3 || strlen($password_user) < 3) {
                $stopWithError("Username/Passwordmust be at least 3 characters!");
            } else {
                $new_user = preg_replace('/[^a-z0-9]/', '', strtolower($new_u));
                $base_dir = $path_vhost . "$new_user";
                $path_user = "$base_dir/httpdocs";
                //$path_escape = escapeshellarg($path_user);
                
                $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
                $check->bind_param("s", $new_user);
                $check->execute();
                if ($check->get_result()->num_rows > 0) {
                    $stopWithError("Username already exists");
                }
            }
        }
    
        if ($action == 'add_web') {
            if ($_SESSION['role'] !== 'admin') $stopWithError("Access Denied!");
            try {
                $type_domain = "domain";
                $type = $_POST['domain_type'] ?? '';
                if ($type === 'main') {
                    $domain_user = $_SERVER['SERVER_ADDR'];
                } elseif ($type === 'custom') {
                    $domain_user = preg_replace('/[^a-z0-9.-]/', '', strtolower($_POST['custom_domain']));
                } else {
                    $domain_user = preg_replace('/[^a-z0-9.-]/', '', strtolower($type));
                }
                if(empty($domain_user)) $stopWithError("Domain can't be empty");
            
                $check = $conn->prepare("SELECT * FROM data_website WHERE domain = ?");
                $check->bind_param("s", $domain_user);
                $check->execute();
                if ($check->get_result()->num_rows > 0) {
                    $stopWithError("Domain already exists");
                }
                
                $php_info = "<?php phpinfo(); ?>";
                if (!is_dir($base_dir)) {
                    if (!file_exists($path_user . "/index.php")) {
                        //shell_exec("sudo useradd -p $(openssl passwd -1 $pwd) $path_escape > /dev/null 2>&1 &");
                        mkdir($path_user, 0755, true);
                        shell_exec("sudo chown -R $new_user:$new_user $path_user > /dev/null 2>&1 &");
                        $tmp_file = "/tmp/index_" . time() . ".php";
                        file_put_contents($tmp_file, $php_info);
                        shell_exec("sudo mv $tmp_file $path_user/index.php > /dev/null 2>&1 &");
                        shell_exec("sudo chown $new_user:$new_user $path_user/index.php > /dev/null 2>&1 &");
                    } else {
                        $stopWithError("There was a problem with the index.php");
                    }
                } else {
                    $stopWithError("There was a problem with the domain path");
                }
                
                if ($type !== 'main') {
                    $check = $conn->prepare("SELECT * FROM domain_list WHERE domain = ?");
                    $check->bind_param("s", $domain_user);
                    $check->execute();
                    if ($check->get_result()->num_rows == 0) {
                        $stmt2 = $conn->prepare("INSERT INTO domain_list (domain) VALUES (?)");
                        $stmt2->bind_param("s",$domain_user);
                        $stmt2->execute();
                    }
                }
                
                require_once("lib/config_generator.php");
    
                $stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $new_user, $pwd_hash, $email_user);
                if ($stmt->execute()) {
                    $last_id = $conn->insert_id;
                    
                    $stmt2 = $conn->prepare("INSERT INTO data_website (user_id, type_server, domain, type_domain, php_version, path_web) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt2->bind_param("isssss",$last_id, $type_server, $domain_user, $type_domain, $php_version, $base_dir);
                    $stmt2->execute();
                    $stmt2->close();
                }
                $stmt->close();
        
                actionServer("apache", "", "reload");
                actionServer("nginx", "", "reload");
                actionServer("php", $php_version, "reload");
                $alert = "success"; $msg = "The website has been successfully created.";
                
            } catch (Exception $e) { 
                $msg = $e->getMessage();
                $stopWithError($msg);
            }
            
        } else if ($action == 'add_subdomain') {
            if ($_SESSION['role'] !== 'admin') $stopWithError("Access Denied!");
            try {
                $type_domain = "subdomain";
                $type = $_POST['main_domain'] ?? '';
                $sub_prefix = preg_replace('/[^a-z0-9.-]/', '', strtolower($_POST['sub_prefix']));
                $domain_user = $sub_prefix . "." . $type;
                if(empty($domain_user)) $stopWithError("Domain can't be empty");
                    
                $check = $conn->prepare("SELECT * FROM data_website WHERE domain = ?");
                $check->bind_param("s", $domain_user);
                $check->execute();
                if ($check->get_result()->num_rows > 0) {
                    $stopWithError("Domain already exists");
                }
                
                $php_info = "<?php phpinfo(); ?>";
                if (!is_dir($base_dir)) {
                    if (!file_exists($path_user . "/index.php")) {
                        //shell_exec("sudo useradd -p $(openssl passwd -1 $pwd) $path_escape > /dev/null 2>&1 &");
                        mkdir($path_user, 0755, true);
                        shell_exec("sudo chown -R $new_user:$new_user $path_user > /dev/null 2>&1 &");
                        $tmp_file = "/tmp/index_" . time() . ".php";
                        file_put_contents($tmp_file, $php_info);
                        shell_exec("sudo mv $tmp_file $path_user/index.php > /dev/null 2>&1 &");
                        shell_exec("sudo chown $new_user:$new_user $path_user/index.php > /dev/null 2>&1 &");
                    } else {
                        $stopWithError("There was a problem with the index.php");
                    }
                } else {
                    $stopWithError("There was a problem with the Domain Path");
                }
        
                require_once("lib/config_generator.php");
                
                $stmt = $conn->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $new_user, $pwd_hash, $email_user);
                if ($stmt->execute()) {
                    $last_id = $conn->insert_id;
                    
                    $stmt2 = $conn->prepare("INSERT INTO data_website (user_id, type_server, domain, type_domain, php_version, path_web) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt2->bind_param("isssss",$last_id, $type_server, $domain_user, $type_domain, $php_version, $base_dir);
                    $stmt2->execute();
                    $stmt2->close();
                }
                $stmt->close();
        
                actionServer("apache", "", "reload");
                actionServer("nginx", "", "reload");
                actionServer("php", $php_version, "reload");
                $alert = "success"; $msg = "The website has been successfully created.";
                
            } catch (Exception $e) { 
                $msg = $e->getMessage();
                $stopWithError($msg);
            }
            
        } else if ($action == 'delete_user') {
            if ($_SESSION['role'] !== 'admin') $stopWithError("Access Denied!");
            $target_id = (int)$_POST['uid'];
            
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param("i", $target_id);
            $stmt->execute();
            $res = $stmt->get_result();
            if($u = $res->fetch_assoc()) {
                
                $stmt2 = $conn->prepare("SELECT * FROM data_website WHERE user_id = ?");
                $stmt2->bind_param("i", $target_id);
                $stmt2->execute();
                $res2 = $stmt2->get_result();
                $a = $res2->fetch_assoc();
                if (!$a) { $stopWithError("User Not Found"); }
                
                $target_user = $u['username'];
                $type_server = $a['type_server'];
                $domain_user = $a['domain'];
                $path_user = $a['path_web'];
                
                $db_prefix = mysqli_real_escape_string($conn, $target_user) . "_%";
                $res = mysqli_query($conn, "SHOW DATABASES LIKE '$db_prefix'");
                if ($res) {
                    while ($row = mysqli_fetch_array($res)) {
                        $db_name = $row[0];
                        mysqli_query($conn, "DROP DATABASE IF EXISTS `$db_name`");
                    }
                }
                $res_user = mysqli_query($conn, "SELECT User FROM mysql.user WHERE User LIKE '$db_prefix' AND Host = 'localhost'");
                if ($res_user) {
                    while ($user_row = mysqli_fetch_array($res_user)) {
                        $found_user = $user_row[0];
                        mysqli_query($conn, "DROP USER IF EXISTS '$found_user'@'localhost'");
                    }
                }
                $stmt_del = $conn->prepare("DELETE FROM users WHERE id = ?");
                $stmt_del->bind_param("i", $target_id);
                $stmt_del->execute();
                $stmt_del = $conn->prepare("DELETE FROM data_website WHERE user_id = ?");
                $stmt_del->bind_param("i", $target_id);
                $stmt_del->execute();
                mysqli_query($conn, "FLUSH PRIVILEGES");
                
                if($type_server == 'apache') {
                    shell_exec("sudo rm ". $apache_available . $domain_user . ".conf > /dev/null 2>&1 &");
                    shell_exec("sudo rm ". $apache_enabled . $domain_user . ".conf > /dev/null 2>&1 &");
                }
                shell_exec("sudo rm ". $nginx_available . $domain_user . " > /dev/null 2>&1 &");
                shell_exec("sudo rm ". $nginx_enabled . $domain_user . " > /dev/null 2>&1 &");
                shell_exec("sudo chattr -i $path_user/httpdocs/.user.ini > /dev/null 2>&1 &");
                shell_exec("sudo rm -rf $path_user > /dev/null 2>&1 &");
                actionServer("apache", "", "reload");
                actionServer("nginx", "", "reload");
                $alert = "success"; $msg = "The website has been successfully deleted.";
            }
        }
        
        file_put_contents($logFile, "Finish: $action\n");
        file_put_contents($logFile, "Completed\n");
        echo json_encode(['status' => 'started', 'alert' => $alert, 'message' => $msg]);
        exit();
    }
    if (isset($_GET['read_log'])) {
        while (ob_get_level()) { ob_end_clean(); }
        $task_id = $_GET['task_id'] ?? $user_session;
        $logFile = $log_dir . "domainManage_" . preg_replace('/[^a-z0-9]/i', '', $task_id) . ".log";
        if (file_exists($logFile)) {
            $content = file_get_contents($logFile);
            $is_done = (strpos($content, 'Completed') !== false);
            $lines = explode("\n", $content);
            $output = nl2br(htmlspecialchars(implode("\n", array_slice($lines, -20))));
            echo json_encode(['log' => $output, 'done' => $is_done]);
            if ($is_done) {
                //unlink($logFile);
            }
        } else {
            echo json_encode(['log' => 'Waiting for log...', 'done' => false]);
        }
        exit();
    }
}

/**
 * REAL-TIME MONITORING
 */
if (isset($_GET['get_stats'])) {
    header('Content-Type: application/json');
    $load = sys_getloadavg();
    $cpu = ($load[0] * 10 > 100) ? 100 : $load[0] * 10;
    
    $free = shell_exec('free -m');
    $memory_perc = 0; $mem_used = 0; $mem_total = 0;
    
    if ($free) {
        $lines = explode("\n", trim($free));
        $mem = preg_split('/\s+/', $lines[1]);
        $mem_total = $mem[1] ?? 0;
        $mem_used = $mem[2] ?? 0;
        $memory_perc = $mem_total > 0 ? ($mem_used / $mem_total) * 100 : 0;
    }
    
    $disk_total = disk_total_space("/");
    $disk_free = disk_free_space("/");
    $disk_perc = (($disk_total - $disk_free) / $disk_total) * 100;

    echo json_encode([
        'cpu' => round($cpu, 1),
        'mem_perc' => round($memory_perc, 1),
        'mem_used' => round($mem_used / 1024, 2),
        'mem_total' => round($mem_total / 1024, 2),
        'disk_perc' => round($disk_perc, 1),
        'disk_used' => round(($disk_total - $disk_free) / (1024**3), 2),
        'disk_total' => round($disk_total / (1024**3), 2),
        'uptime' => trim(shell_exec("uptime -p") ?? "N/A")
    ]);
    exit();
}

$listWebsite = $conn->query("SELECT * FROM data_website ORDER BY id ASC");

require_once("lib/header.php");
?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="col-md">
            <h3 class="fw-bold text-dark mb-1">
                <img src="<?php srcIcon($page); ?>" width="20" class="me-1"></img>
                <?php
                    if(!$page_ext && !$subpage){
                        if($page == 'home') echo 'Dashboard Overview';
                        elseif($page == 'domains') echo 'Manage List Domain';
                        elseif($page == 'settings') echo 'Tools & Settings';
                        elseif($page == 'extensions') echo 'Manage Extensions';
                        else echo 'Dashboard Overview'; 
                    }
                    if(!empty($page_ext)){
                        $dataExt = $conn->query("SELECT package, title FROM extensions WHERE package = '$page_ext'");
                        if($dataExt && $data_Ext = $dataExt->fetch_assoc()){
                            $package_ext = $data_Ext['package'];
                            $title_ext = $data_Ext['title'];
                        } else { $package_ext = ""; $title_ext = ""; }
                        if($page_ext == $package_ext) echo $title_ext;
                        else echo ''; 
                    } else {
                        if($subpage == 'manage') echo 'Manage Domain';
                        elseif($subpage == 'installer') echo 'Manage Extension Installer';
                        else echo ''; 
                    }
                ?>
            </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <?php if($page == 'home') { ?>
                        <li class="breadcrumb-item active">Dashboard</li>
                    <?php } else { ?>
                        <li class="breadcrumb-item"><a href="<?php echo $dashboard; ?>" class="text-decoration-none">Dashboard</a></li>
                        <?php
                            if($page_ext) $breadcumb_item = ucfirst($subpage) . " / " . ucfirst($page_ext);
                            elseif($subpage) $breadcumb_item = ucfirst($subpage);
                            elseif($page) $breadcumb_item = ucfirst($page);
                            else $breadcumb_item = "";
                        ?>
                        <li class="breadcrumb-item active"><?php echo $breadcumb_item; ?>: <strong><?= htmlspecialchars($_SESSION['user']) ?></strong></li>
                    <?php } ?>
                </ol>
            </nav>
        </div>
    </div>

    <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show rounded-4 mb-4 d-none" role="alert">
        <div class="d-flex align-items-center">
            <div class="icon-alert fs-4 me-3"></div>
            <div><span class="alert-msg small"></span></div>
        </div>
        <button type="button" class="btn-close" onclick="this.parentElement.classList.add('d-none')"></button>
    </div>
    <?php if(isset($_SESSION['result'])): ?>
        <div class="alert alert-<?= ($_SESSION['result']['status'] == 'success') ? 'success' : 'danger' ?> border-0 shadow-sm alert-dismissible fade show rounded-4 mb-4" role="alert">
            <div class="d-flex align-items-center">
                <div class="fs-4 me-3"><?= ($_SESSION['result']['status'] == 'success') ? '🎉' : '⚠️' ?></div>
                <div><span class="small"><?= htmlspecialchars($_SESSION['result']['message']) ?></span></div>
            </div>
            <button type="button" class="btn-close" onclick="this.parentElement.classList.add('d-none')"></button>
        </div>
    <?php unset($_SESSION['result']); endif; ?>

    <?php switch($page) {
        case 'home': ?>
            <div class="row g-4">
                <div class="col-md-8">
                    <div class="plesk-card mb-4">
                        <div class="plesk-card-header">System Information</div>
                        <div class="p-4">
                            <div class="row g-4 text-center">
                                <div class="col-6 col-sm-3 border-end">
                                    <div class="small text-muted">Hostname</div><div class="fw-bold text-truncate"><?php echo gethostname(); ?></div>
                                </div>
                                <div class="col-6 col-sm-3 border-end">
                                    <div class="small text-muted">IP Address</div><div class="fw-bold"><?php echo $_SERVER['SERVER_ADDR'] ?? '127.0.0.1'; ?></div>
                                </div>
                                <div class="col-6 col-sm-3 border-end">
                                    <div class="small text-muted">Uptime</div><div id="uptime-val" class="fw-bold text-primary">...</div>
                                </div>
                                <div class="col-6 col-sm-3">
                                    <div class="small text-muted">Active Users</div><div class="fw-bold"><?php echo $listWebsite->num_rows; ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="plesk-card">
                        <div class="plesk-card-header">Real-time Resource Usage</div>
                        <div class="p-4">
                            <div class="mb-4">
                                <div class="d-flex justify-content-between mb-1">
                                    <label class="small fw-bold">CPU Usage</label>
                                    <span id="cpu-text" class="small">0%</span>
                                </div>
                                <div class="progress" style="height: 8px;"><div id="cpu-bar" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div></div>
                            </div>
                            <div class="mb-2">
                                <div class="d-flex justify-content-between mb-1">
                                    <label class="small fw-bold">RAM Usage</label>
                                    <span id="mem-text" class="small">0/0 GB</span>
                                </div>
                                <div class="progress" style="height: 8px;"><div id="mem-bar" class="progress-bar bg-success" style="width: 0%"></div></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="plesk-card text-center p-4 h-100 d-flex flex-column justify-content-center">
                        <i class="bi bi-cpu display-4 text-primary mb-3"></i>
                        <h5>Server Node 01</h5>
                        <p class="text-muted small">Status: <span class="badge bg-success">Online</span></p>
                        <hr>
                        <div class="d-grid gap-2">
                            <a href="?page=domains" class="btn btn-primary btn-sm">Manage Domains</a>
                            <button class="btn btn-outline-secondary btn-sm" onclick="location.reload()">Refresh Data</button>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                function updateStats() {
                    fetch('?get_stats=1').then(r => r.json()).then(data => {
                        document.getElementById('cpu-bar').style.width = data.cpu + '%';
                        document.getElementById('cpu-text').innerText = data.cpu + '%';
                        document.getElementById('mem-bar').style.width = data.mem_perc + '%';
                        document.getElementById('mem-text').innerText = data.mem_used + ' / ' + data.mem_total + ' GB';
                        document.getElementById('uptime-val').innerText = data.uptime;
                    });
                }
                setInterval(updateStats, 3000); updateStats();
            </script>
        <?php break;

        case 'domains':
        
            if ($_SESSION['role'] === 'user') {
                $page = 'domains';
                $subpage = 'manage';
                include('manage-user.php');
            } else if ($_SESSION['role'] === 'admin') {
                $subpage = isset($_GET['subpage']) ? $_GET['subpage'] : '';
                if ($subpage === 'manage' && isset($_GET['id'])) {
                    include('manage-user.php');
                } else { ?>
                    <div class="mb-4 text-end">
                        <button class="btn btn-primary px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#addModal">
                            <i class="bi bi-plus-lg me-1"></i> Add Domain
                        </button>
                        <button class="btn btn-primary px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#subdomainModal">
                            <i class="bi bi-plus-lg me-1"></i> Add Subdomain
                        </button>
                    </div>
                    <ul class="dropdown-menu shadow-sm border-0">
                        <li><h6 class="dropdown-header">Switch PHP Version</h6></li>
                        <?php foreach($available_sock as $v): ?>
                        <li><a class="dropdown-item small <?php echo ($v == $php_v) ? 'active' : ''; ?>" href="#"><?php echo $v; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="plesk-card shadow-sm border-0">
                        <div class="plesk-card-header bg-white d-flex justify-content-between align-items-center py-3">
                            <span class="fs-5">Active Domain</span>
                            <div class="input-group input-group-sm" style="width: 250px;">
                                <input type="text" id="userSearch" class="form-control" placeholder="Cari user atau domain..." onkeyup="filterUser()">
                                <span class="input-group-text"><i class="bi bi-search"></i></span>
                            </div>
                        </div>
                        <div id="classRefresh" class="row g-3" id="subscriptionCards">
                            <?php if($listWebsite->num_rows > 0): while($u = $listWebsite->fetch_assoc()):
                                $user_id = $u['user_id'];
                                $resUser = $conn->query("SELECT * FROM users WHERE id = '$user_id'");
                                $dataUser = $resUser->fetch_assoc();
                                                                        
                                $is_online = is_dir($u['path_web'] . "/httpdocs");
                            ?>
                                <div class="col-12 col-md-6 col-lg-4">
                                    <div class="plesk-card h-100 shadow-sm border-0 transition-hover">
                                        <div class="plesk-card-header bg-white d-flex align-items-center justify-content-between py-3 px-3">
                                            <div class="d-flex align-items-center">
                                                <div class="position-relative me-3">
                                                    <div class="rounded-circle bg-soft-primary text-primary d-flex align-items-center justify-content-center" style="width: 45px; height: 45px;">
                                                        <i class="bi bi-person-fill fs-5"></i>
                                                    </div>
                                                    <span class="position-absolute bottom-0 end-0 border border-2 border-white rounded-circle <?= $is_online ? 'bg-success' : 'bg-danger' ?> p-1" style="width: 12px; height: 12px;"></span>
                                                </div>
                                                <div>
                                                    <h6 class="mb-0 fw-bold text-dark"><?php echo htmlspecialchars($dataUser['username']); ?></h6>
                                                    <small class="text-muted" style="font-size: 0.7rem;">Since <?php echo $u['created_at']; ?></small>
                                                </div>
                                            </div>
                                            <form method="POST" id="actionWebForm_<?= $user_id ?>">
                                                <input type="hidden" name="action_type">
                                                <input type="hidden" name="uid" value="<?= $u['user_id'] ?>">
                                                <div class="dropdown">
                                                    <button class="btn btn-link text-muted p-0" data-bs-toggle="dropdown">
                                                        <i class="bi bi-three-dots-vertical"></i>
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                                        <li><a class="dropdown-item small" href="?page=manage&id=<?php echo $u['user_id']; ?>"><i class="bi bi-pencil me-2"></i>Edit Profile</a></li>
                                                        <li><hr class="dropdown-divider"></li>
                                                        <li><button type="button" name="btn-delete_user_<?= $user_id ?>" class="dropdown-item small text-danger" onclick="tryAction('delete_user', 'btn-delete_user_<?= $user_id ?>', 'actionWebForm_<?= $user_id ?>', 'Please wait, Delete Website will take a few minutes.')"><i class="bi bi-trash me-2"></i>Delete</button></li>
                                                    </ul>
                                                </div>
                                            </form>
                                        </div>
                            
                                        <div class="card-body px-3 py-3">
                                            <div class="mb-3">
                                                <label class="text-uppercase text-muted fw-bold" style="font-size: 0.65rem; letter-spacing: 1px;">Primary Domain</label>
                                                <div class="d-flex align-items-center mt-1">
                                                    <a href="http://<?php echo $u['domain']; ?>" target="_blank" class="text-primary text-decoration-none fw-medium text-truncate me-2">
                                                        <?php echo htmlspecialchars($u['domain']); ?>
                                                    </a>
                                                    <i class="bi bi-box-arrow-up-right text-muted small"></i>
                                                </div>
                                            </div>
                            
                                            <div class="row g-2 mb-3">
                                                <div class="col-6">
                                                    <div class="p-2 rounded bg-light border-start border-primary border-3">
                                                        <label class="d-block text-muted" style="font-size: 0.6rem;">Web Server : </label>
                                                        <span class="small fw-bold text-dark text-truncate d-block"><?php echo ucfirst($u['type_server']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="p-2 rounded bg-light border-start border-info border-3">
                                                        <label class="d-block text-muted" style="font-size: 0.6rem;">PHP ENGINE</label>
                                                        <span class="small fw-bold text-dark d-block">v<?php echo htmlspecialchars($u['php_version']); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            
                                        <div class="card-footer bg-transparent border-top-0 px-3 pb-3">
                                            <div class="d-grid gap-2 d-flex">
                                                <a href="?page=domains&subpage=manage&id=<?php echo $u['user_id']; ?>" class="btn btn-primary btn-sm flex-grow-1 rounded-pill fw-bold">
                                                    <i class="bi bi-cpu-fill me-1"></i> Manage
                                                </a>
                                                <a href="http://<?php echo $host_panel; ?>/pma" target="_blank" class="btn btn-outline-secondary btn-sm rounded-pill">
                                                    <i class="bi bi-database-fill-gear"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; else: ?>
                            <div class="col-12">
                                <div class="text-center py-5 bg-white rounded shadow-sm">
                                    <i class="bi bi-folder2-open display-1 text-light"></i>
                                    <p class="text-muted mt-3">There are no active domains yet.</p>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php }
            }
        break; 

        require_once('lib/session_admin.php');
        case 'settings':
            include('services/index.php');
            break; 

        case 'extensions': 
            include('extensions/index.php');
            break;
            
        case 'nodesetting':
            include('services/node-settings.php');
            break; 

        case 'phpsetting':
            include('services/php-settings.php');
            break; 

        case 'cronjobs':
            include('services/cronjob-setting.php');
            break; 

        }
?>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content border-0 shadow text-dark" id="addWebForm">
            <input type="hidden" name="action_type">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold">Provision New Website</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="userweb01" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Email</label>
                    <input type="text" name="email" class="form-control" placeholder="example@mail.com" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Web Server</label>
                    <select name="type_server" class="form-select">
                        <option value="apache">Apache</option>
                        <option value="nginx">Nginx</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">PHP Version</label>
                    <select name="php_version" class="form-select">
                        <?php foreach($available_sock as $v): ?>
                            <option value="<?= $v ?>"> PHP <?= ($v) ? : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php $listDomain = $conn->query("SELECT domain FROM domain_list ORDER BY id DESC"); ?>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Domain Type</label>
                    <select name="domain_type" class="form-select" onchange="toggleDomainInputs(this.value)">
                        <option value="main">Host (<?php echo $_SERVER['SERVER_ADDR']; ?>)</option>
                        <option value="custom">Custom / Own Domain</option>
                        <?php if($listDomain->num_rows > 0): 
                            while($row = $listDomain->fetch_assoc()): ?>
                            <option value="<?= $row['domain']; ?>"><?= $row['domain']; ?></option>
                        <?php endwhile; else: endif; ?>
                    </select>
                </div>
                        
                <div id="input_custom" class="mb-3 d-none">
                    <label class="form-label fw-bold small">Domain</label>
                    <input type="text" name="custom_domain" class="form-control" placeholder="example.com">
                    <div class="form-text text-danger small">Pastikan DNS A Record mengarah ke IP ini.</div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" name="btn-add_web" class="btn btn-primary w-100 fw-bold" onclick="tryAction('add_web', 'btn-add_web', 'addWebForm', 'Please wait, Build new Website will take a few minutes.')" disabled>Deploy Website Now</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="subdomainModal" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content border-0 shadow text-dark" id="addSubDomainForm">
            <input type="hidden" name="action_type">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold">Provision New Website Subdomain</h5>
                <button type="submit" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold small">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="userweb01" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Email</label>
                    <input type="text" name="email" class="form-control" placeholder="example@mail.com" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Web Server</label>
                    <select name="type_server" class="form-select">
                        <option value="apache">Apache</option>
                        <option value="nginx">Nginx</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">PHP Version</label>
                    <select name="php_version" class="form-select">
                        <?php foreach($available_sock as $v): ?>
                            <option value="<?= $v ?>"> PHP <?= ($v) ? : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php
                    $listDomain = $conn->query("SELECT domain FROM domain_list ORDER BY id DESC"); ?>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Subdomain</label>
                    <div class="input-group">
                        <input type="text" name="sub_prefix" class="form-control" placeholder="mywebsite" required>
                        <span class="input-group-text">.</span>
                        <select name="main_domain" class="form-select">
                            <?php if($listDomain->num_rows > 0): 
                                while($row = $listDomain->fetch_assoc()): ?>
                                <option value="<?= $row['domain']; ?>"><?= $row['domain']; ?></option>
                            <?php endwhile; else: ?>
                                <option value="">Not Available</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-text text-danger small">Pastikan DNS A Record mengarah ke IP ini.</div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" name="btn-add_subdomain" class="btn btn-primary w-100 fw-bold" onclick="tryAction('add_subdomain', 'btn-add_subdomain', 'addSubDomainForm', 'Please wait, Build new Website with Sub-Domain will take a few minutes.')" disabled>Deploy Website Now</button>
            </div>
            
        </form>
    </div>
</div>

<script>
function toggleDomainInputs(val) {
    document.getElementById('input_custom').classList.add('d-none');
    if (val === 'custom') {
        document.getElementById('input_custom').classList.remove('d-none');
    }
}
document.addEventListener('DOMContentLoaded', function() {
    const domainForm = document.getElementById('addWebForm');
    const domainSelect = domainForm.querySelector(`select[name="domain_type"]`);
    function checkDomain() {
        if (domainSelect.value === "custom") {
            btnFilled('addWebForm', 'btn-add_web', ['username', 'email', 'password', 'custom_domain']);
        } else {
            btnFilled('addWebForm', 'btn-add_web', ['username', 'email', 'password']);
        }
    }
    checkDomain();
    domainSelect.addEventListener('change', checkDomain);
    
    const subForm = document.getElementById('addSubDomainForm');
    const subSelect = subForm.querySelector(`select[name="main_domain"]`);
    function checkSubDomain() {
        if (subSelect.value === "" || subSelect.options[subSelect.selectedIndex].text.includes("Not Available")) {
            btnFilled('addSubDomainForm', 'btn-add_subdomain', ['username', 'email', 'password', 'sub_prefix']);
        } else {
            btnFilled('addSubDomainForm', 'btn-add_subdomain', ['username', 'email', 'password', 'sub_prefix']);
        }
    }
    checkSubDomain();
    subSelect.addEventListener('change', checkSubDomain);
});
function filterUser() {
    let input = document.getElementById("userSearch");
    let filter = input.value.toLowerCase();
    
    let container = document.getElementById("subscriptionCards");
    let cards = container.getElementsByClassName("col-12");

    for (let i = 0; i < cards.length; i++) {
        let username = cards[i].querySelector("h6").textContent || cards[i].querySelector("h6").innerText;
        let domain = cards[i].querySelector("a.text-primary").textContent || cards[i].querySelector("a.text-primary").innerText;
        
        let combinedText = username + " " + domain
        

        if (combinedText.toLowerCase().indexOf(filter) > -1) {
            cards[i].style.display = "";
        } else {
            cards[i].style.display = "none";
        }
    }
}
</script>

<?php
require_once("lib/footer.php");
?>