<?php

namespace DJumPer\Platform;

use DJumPer\Utils\Utils;
use Exception;

class Facebook
{

    public function scrape($html)
    {

        $platform = 'Facebook'; $title = null; $thumbnail = null;
        $videoUrl = null; $audioUrl = null; $streamingUrl = null;
        $videoQualities = []; $audioQualities = []; $streamingQualities = []; 
        $reason = 'Video tidak dapat diputar (Private/Age Restricted).';

        preg_match('/"browser_native_hd_url":"([^"]+)"/', $html, $hd1);
        preg_match('/"browser_native_sd_url":"([^"]+)"/', $html, $sd1);
        preg_match('/"playable_url_quality_hd":"([^"]+)"/', $html, $hd2);
        preg_match('/"playable_url":"([^"]+)"/', $html, $sd2);
        preg_match('/<meta property="og:video" content="([^"]+)"/', $html, $og);
        $sources = [
            '1440' => $hd1[1] ?? null,
            '1080'  => $hd2[1] ?? null,
            '720'   => $sd1[1] ?? $sd2[1] ?? null,
            '360'   => $og[1] ?? null
        ];
        foreach ($sources as $quality => $url) {
            if (!$url) continue;
            $url = stripslashes($url);
            $url = str_replace('\/', '/', $url);
            $videoQualities[] = [
                "itag" => count($videoQualities) + 1,
                "type" => "mp4",
                "qualityLabel" => "Video MP4 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎥 {$quality}p",
                "url" => Utils::cleanString($url)
            ];
            
            parse_str(parse_url($url, PHP_URL_QUERY), $q);
            $bitrate = (int)$q['bitrate'] ?? (int)$quality;
            $bitrate = $bitrate / 1000;
            $audioQualities[] = [
                "itag" => count($audioQualities) + 1,
                "type" => "mp3",
                "qualityLabel" => "Audio MP3 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 🎵 {$bitrate}",
                "url" => Utils::cleanString($url)
            ];

            if (!$videoUrl) {
                $videoUrl = $url;
            }
        }

        preg_match('/"(browser_native_sd_url|browser_native_hd_url)":"([^"]+)"/', $html, $videoMatches);
        $streamingUrl = isset($videoMatches[2]) ? stripslashes($videoMatches[2]) : null;
        $streamingQualities[] = [
            "type" => "mp4",
            "url" => Utils::cleanString($streamingUrl)
        ];

        preg_match('/<meta property="og:image" content="([^"]+)"/', $html, $thumbMatches);
        $thumbnail = isset($thumbMatches[1]) ? htmlspecialchars_decode($thumbMatches[1]) : null;
        
        preg_match('/<meta property="og:description" content="([^"]+)"/', $html, $descMatches);
        $title = isset($descMatches[1]) ? htmlspecialchars_decode($descMatches[1]) : null;
        if (!$title){
            preg_match('/<meta property="og:title" content="([^"]+)"/', $html, $titleMatches);
            $title = isset($titleMatches[1]) ? htmlspecialchars_decode($titleMatches[1]) : null;
        }

        if (!$videoUrl) {
            throw new Exception($platform . ": " . $reason);
        } else {
            $reason = "OK";
        }
        
        $title = Utils::cleanString($title);
        return [
            'status' => $reason,
            'platform' => $platform,
            'title' => Utils::limitString($title, 100),
            'thumbnail' => Utils::cleanString($thumbnail),
            'streaming_data' => $streamingQualities,
            'video_data' => $videoQualities,
            'audio_data' => $audioQualities
        ];
                
    }
    
}