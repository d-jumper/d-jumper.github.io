<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'root') { die("Access Denied"); }
if (!isset($_GET['user']) || !isset($_GET['domain'])) { die("Parameter missing!"); }

$user_target = preg_replace('/[^a-z0-9]/', '', $_GET['user']);
$root_path = "/var/www/html/" . $user_target . "/";
$sub_dir = isset($_GET['dir']) ? trim($_GET['dir'], '/') : '';
// Gunakan realpath untuk keamanan, jika gagal kembali ke root_path
$path = realpath($root_path . ($sub_dir ? "/" . $sub_dir : ""));
$id = $_GET['id'] ?? '';

if (!$path || strpos($path, $root_path) !== 0) {
    $path = $root_path;
    $sub_dir = '';
}

$msg = "";

// --- LOGIKA: ZIP ITEMS (PERBAIKAN) ---
if (isset($_POST['action_type']) && $_POST['action_type'] === 'zip' && isset($_POST['selected_items'])) {
    $zip_name = "archive_" . date('Ymd_His') . ".zip";
    $items_array = array_map(function($i) { return escapeshellarg($i); }, $_POST['selected_items']);
    $items_string = implode(" ", $items_array);
    
    // Perintah: Pindah ke direktori target baru jalankan zip agar file tercipta di tempat yang benar
    $cmd = "cd " . escapeshellarg($path) . " && sudo zip -r " . escapeshellarg($zip_name) . " " . $items_string . " 2>&1";
    $output = shell_exec($cmd);
    
    if (file_exists($path . "/" . $zip_name)) {
        shell_exec("sudo chown $user_target:$user_target " . escapeshellarg($path . "/" . $zip_name));
        $msg = "<div class='alert alert-success py-2 small'>Berhasil membuat: <b>$zip_name</b></div>";
    } else {
        $msg = "<div class='alert alert-danger py-2 small'>Gagal membuat Zip. Error: <pre class='mb-0 small'>$output</pre></div>";
    }
}

// --- LOGIKA: UNZIP FILE ---
if (isset($_GET['unzip'])) {
    $file_to_unzip = $path . "/" . basename($_GET['unzip']);
    if (file_exists($file_to_unzip)) {
        shell_exec("sudo unzip -o " . escapeshellarg($file_to_unzip) . " -d " . escapeshellarg($path));
        shell_exec("sudo chown -R $user_target:$user_target " . escapeshellarg($path));
        $msg = "<div class='alert alert-success py-2 small'>File diekstrak ke direktori saat ini.</div>";
    }
}

// --- LOGIKA: UPDATE PERMISSIONS ---
if (isset($_POST['update_perms'])) {
    $target = $path . "/" . basename($_POST['target_item']);
    if (file_exists($target)) {
        $p = $_POST['perms'];
        $owner = (isset($p['ur']) ? 4 : 0) + (isset($p['uw']) ? 2 : 0) + (isset($p['ux']) ? 1 : 0);
        $group = (isset($p['gr']) ? 4 : 0) + (isset($p['gw']) ? 2 : 0) + (isset($p['gx']) ? 1 : 0);
        $other = (isset($p['or']) ? 4 : 0) + (isset($p['ow']) ? 2 : 0) + (isset($p['ox']) ? 1 : 0);
        $mode = $owner . $group . $other;
        shell_exec("sudo chmod $mode " . escapeshellarg($target));
    }
}

// --- LOGIKA LAIN (Delete, Create, Rename, Upload, Paste) ---
if (isset($_POST['create_file'])) {
    $new_f = basename($_POST['file_name']);
    if (!file_exists($path . "/" . $new_f)) {
        touch($path . "/" . $new_f);
        shell_exec("sudo chown $user_target:$user_target " . escapeshellarg($path . "/" . $new_f));
    }
}

if (isset($_POST['set_clipboard']) && $_POST['action_type'] !== 'zip') {
    $_SESSION['clipboard'] = ['items' => $_POST['selected_items'], 'source_path' => $path, 'action' => $_POST['action_type']];
}

if (isset($_POST['paste_now']) && isset($_SESSION['clipboard'])) {
    $cb = $_SESSION['clipboard'];
    foreach ($cb['items'] as $item) {
        $src = $cb['source_path'] . "/" . $item;
        $dst = $path . "/" . $item;
        if (file_exists($src)) {
            $cmd = ($cb['action'] === 'move') ? "sudo mv" : "sudo cp -rn";
            shell_exec("$cmd " . escapeshellarg($src) . " " . escapeshellarg($dst));
            shell_exec("sudo chown -R $user_target:$user_target " . escapeshellarg($dst));
        }
    }
    unset($_SESSION['clipboard']);
}

if (isset($_POST['bulk_delete']) && isset($_POST['selected_items'])) {
    foreach ($_POST['selected_items'] as $item) { shell_exec("sudo rm -rf " . escapeshellarg($path . "/" . $item)); }
}

if (isset($_GET['delete'])) {
    shell_exec("sudo rm -rf " . escapeshellarg($path . "/" . basename($_GET['delete'])));
}

if (isset($_POST['create_folder'])) {
    $new_fold = preg_replace('/[^a-zA-Z0-9_-]/', '', $_POST['folder_name']);
    if (!file_exists($path . "/" . $new_fold)) {
        mkdir($path . "/" . $new_fold, 0755);
        shell_exec("sudo chown $user_target:$user_target " . escapeshellarg($path . "/" . $new_fold));
    }
}

if (isset($_POST['rename_item'])) {
    $old = $path . "/" . basename($_POST['old_name']);
    $new = $path . "/" . basename($_POST['new_name']);
    if (file_exists($old) && !file_exists($new)) rename($old, $new);
}

if (isset($_POST['save_content'])) {
    file_put_contents($path . "/" . basename($_POST['filename']), $_POST['content']);
}

if (isset($_FILES['new_file']) && $_FILES['new_file']['error'] == 0) {
    $target_up = $path . "/" . basename($_FILES['new_file']['name']);
    if (move_uploaded_file($_FILES['new_file']['tmp_name'], $target_up)) {
        shell_exec("sudo chown $user_target:$user_target " . escapeshellarg($target_up));
    }
}

// Scan data
$items_raw = array_diff(scandir($path), ['.', '..']);
$folders = []; $files = [];
foreach ($items_raw as $i) { is_dir($path."/".$i) ? $folders[] = $i : $files[] = $i; }
natcasesort($folders); natcasesort($files);
$sorted_items = array_merge($folders, $files);

function get_octal_perms($file) {
    return file_exists($file) ? substr(sprintf('%o', fileperms($file)), -3) : '000';
}
?>
<style>
    /* Menghilangkan padding container bawaan agar card lebar */
    .plesk-card { 
        background: #fff; 
        border-radius: 8px; 
        border: 1px solid #dee2e6; 
        width: 100%; /* Pastikan 100% */
        overflow: hidden;
    }
    
    /* Perbaikan tabel agar tidak terpotong */
    .table-responsive-custom {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .table-custom {
        width: 100%;
        margin-bottom: 0;
        table-layout: auto; /* Biarkan browser menghitung lebar otomatis */
    }

    /* Memastikan nama file bisa panjang dan tidak merusak layout */
    .col-name {
        min-width: 250px; 
        word-break: break-all;
    }

    /* Fixed width untuk kolom kecil */
    .col-check { width: 40px; }
    .col-perm { width: 80px; text-align: center; }
    .col-size { width: 120px; text-align: right; }
    .col-action { width: 70px; text-align: center; }
#editor { height: 70vh; width: 100%; border-radius: 4px; }
    
    .floating-toolbar { 
        position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); 
        z-index: 2000; display: flex; gap: 10px; align-items: center;
        background: #212529; color: #fff; padding: 12px 25px; border-radius: 50px; 
        box-shadow: 0 5px 25px rgba(0,0,0,0.4);
    }
    
    /* Mencegah dropdown tertutup container */
    .dropdown-menu { z-index: 1060; }
</style>

<div class="plesk-card-header p-3 border-bottom d-flex justify-content-between align-items-center">
    <span class="fw-bold">File Manager</span>
    <div class="d-flex gap-2">
        <?php if(isset($_SESSION['clipboard'])): ?>
            <form method="POST"><button type="submit" name="paste_now" class="btn btn-sm btn-warning">Paste Here</button></form>
        <?php endif; ?>
        <a href="?page=manage&id=<?php echo $id; ?>" class="btn btn-sm btn-outline-secondary">Kembali</a>
    </div>
</div>

<div class="p-3 border-bottom bg-opacity-10 bg-info">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="mb-0 text-primary fw-bold"><i class="bi bi-folder2-open me-2"></i> /<?php echo $sub_dir; ?></h6>
        <div class="d-flex gap-2">
            <button class="btn btn-sm btn-outline-primary" onclick="openModal('fileModal')">+ File</button>
            <button class="btn btn-sm btn-outline-success" onclick="openModal('folderModal')">+ Folder</button>
            <form method="POST" enctype="multipart/form-data" class="d-flex gap-1">
                <input type="file" name="new_file" class="form-control form-control-sm">
                <button class="btn btn-sm btn-primary">Upload</button>
            </form>
        </div>
    </div>

    <?php echo $msg; ?>

    <form id="mainForm" method="POST">
        <input type="hidden" name="action_type" id="actionType">
        <table class="table table-hover align-middle small">
            <thead class="table-light">
                <tr>
                    <th width="40"><input type="checkbox" id="selectAll" class="form-check-input"></th>
                    <th>Nama</th>
                    <th width="100">Izin</th>
                    <th width="120">Ukuran</th>
                    <th width="50">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($sub_dir): ?>
                <tr class="back-row" onclick="window.location.href='?page=manage&id=<?php echo $id; ?>&subpage=file-manager&user=<?php echo $user_target; ?>&domain=<?php echo $_GET['domain']; ?>&dir=<?php echo urlencode(dirname($sub_dir) == '.' ? '' : dirname($sub_dir)); ?>'">
                    <td></td><td colspan="4" class="text-muted"><i class="bi bi-arrow-return-left me-2"></i> Kembali</td>
                </tr>
                <?php endif; ?>

                <?php foreach($sorted_items as $f): 
                    $is_d = is_dir($path."/".$f); 
                    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                    $oct = get_octal_perms($path."/".$f);
                    $url_base = "?page=manage&id=$id&subpage=file-manager&user=$user_target&domain=".$_GET['domain']."&dir=".urlencode($sub_dir);
                ?>
                <tr>
                    <td><input type="checkbox" name="selected_items[]" value="<?php echo $f; ?>" class="form-check-input item-checkbox"></td>
                    <td>
                        <?php if($is_d): ?>
                            <a href="<?php echo $url_base; ?>&dir=<?php echo urlencode(($sub_dir ? $sub_dir.'/' : '').$f); ?>" class="text-decoration-none fw-bold text-dark">
                                <i class="bi bi-folder-fill text-warning me-2"></i> <?php echo $f; ?>
                            </a>
                        <?php else: ?>
                            <i class="bi <?php echo ($ext=='zip')?'bi-file-zip-fill text-danger':'bi-file-earmark-text text-secondary'; ?> me-2"></i> <?php echo $f; ?>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge bg-light text-dark border pointer" onclick="openPerms('<?php echo $f; ?>', '<?php echo $oct; ?>')"><?php echo $oct; ?></span></td>
                    <td><?php echo $is_d ? '-' : round(filesize($path."/".$f)/1024, 2).' KB'; ?></td>
                    <td>
                        <div class="dropdown">
                            <button type="button" class="btn btn-sm btn-light border" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></button>
                            <ul class="dropdown-menu shadow">
                                <?php if(!$is_d): ?>
                                    <li><button type="button" class="dropdown-item" onclick="editFile('<?php echo $f; ?>', `<?php echo htmlspecialchars(@file_get_contents($path.'/'.$f)); ?>`)">Edit</button></li>
                                    <?php if($ext == 'zip'): ?>
                                        <li><a class="dropdown-item text-primary" href="<?php echo $url_base; ?>&unzip=<?php echo urlencode($f); ?>">Unzip Here</a></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <li><button type="button" class="dropdown-item" onclick="openRename('<?php echo $f; ?>')">Rename</button></li>
                                <li><button type="button" class="dropdown-item" onclick="openPerms('<?php echo $f; ?>', '<?php echo $oct; ?>')">Chmod</button></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo $url_base; ?>&delete=<?php echo urlencode($f); ?>" onclick="return confirm('Hapus?')">Hapus</a></li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div id="selectionToolbar" class="floating-toolbar d-none">
            <span class="badge bg-primary mr-2" id="selectedCount">0</span>
            <button type="submit" name="btn_action" class="btn btn-sm btn-outline-warning" onclick="setAction('zip')">Zip</button>
            <button type="submit" name="set_clipboard" class="btn btn-sm btn-outline-light" onclick="setAction('copy')">Copy</button>
            <button type="submit" name="set_clipboard" class="btn btn-sm btn-outline-light" onclick="setAction('move')">Cut</button>
            <button type="submit" name="bulk_delete" class="btn btn-sm btn-danger" onclick="return confirm('Hapus terpilih?')">Hapus</button>
        </div>
    </form>
</div>

<div class="modal fade" id="permModal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <form method="POST" class="modal-content">
            <div class="modal-header py-2 bg-dark text-white d-flex justify-content-between">
                <h6 class="modal-title">Permissions</h6>
                <div class="octal-display" id="octalValue">000</div>
            </div>
            <div class="modal-body">
                <input type="hidden" name="target_item" id="permTarget">
                <table class="table table-bordered text-center mb-0 small">
                    <thead><tr class="table-light"><th></th><th>R</th><th>W</th><th>X</th></tr></thead>
                    <tbody>
                        <?php $grps = ['u'=>'Owner', 'g'=>'Group', 'o'=>'Other']; foreach($grps as $k=>$v): ?>
                        <tr><td><?php echo $v; ?></td>
                            <td><input type="checkbox" class="perm-check" name="perms[<?php echo $k; ?>r]" data-val="4" data-group="<?php echo $k; ?>"></td>
                            <td><input type="checkbox" class="perm-check" name="perms[<?php echo $k; ?>w]" data-val="2" data-group="<?php echo $k; ?>"></td>
                            <td><input type="checkbox" class="perm-check" name="perms[<?php echo $k; ?>x]" data-val="1" data-group="<?php echo $k; ?>"></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer p-1"><button type="submit" name="update_perms" class="btn btn-sm btn-primary w-100">Simpan</button></div>
        </form>
    </div>
</div>

<div class="modal fade" id="fileModal" tabindex="-1"><div class="modal-dialog modal-sm modal-dialog-centered"><form method="POST" class="modal-content"><div class="modal-header py-2"><h6>File Baru</h6></div><div class="modal-body"><input type="text" name="file_name" class="form-control" placeholder="file.php" required></div><div class="modal-footer p-1"><button type="submit" name="create_file" class="btn btn-sm btn-primary w-100">Buat</button></div></form></div></div>
<div class="modal fade" id="folderModal" tabindex="-1"><div class="modal-dialog modal-sm modal-dialog-centered"><form method="POST" class="modal-content"><div class="modal-header py-2"><h6>Folder Baru</h6></div><div class="modal-body"><input type="text" name="folder_name" class="form-control" required></div><div class="modal-footer p-1"><button type="submit" name="create_folder" class="btn btn-sm btn-success w-100">Simpan</button></div></form></div></div>
<div class="modal fade" id="renameModal" tabindex="-1"><div class="modal-dialog modal-sm modal-dialog-centered"><form method="POST" class="modal-content"><div class="modal-header py-2"><h6>Rename</h6></div><div class="modal-body"><input type="hidden" name="old_name" id="rnOld"><input type="text" name="new_name" id="rnNew" class="form-control" required></div><div class="modal-footer p-1"><button type="submit" name="rename_item" class="btn btn-sm btn-primary w-100">Update</button></div></form></div></div>
<div class="modal fade" id="editModal" tabindex="-1"><div class="modal-dialog modal-xl"><form method="POST" class="modal-content" onsubmit="prepareSave()"><div class="modal-header bg-dark text-white py-2"><h6 id="editTitle">Edit</h6><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body p-0"><div id="editor"></div></div><input type="hidden" name="filename" id="editFile"><textarea name="content" id="editContent" class="d-none"></textarea><div class="modal-footer py-1"><button type="submit" name="save_content" class="btn btn-sm btn-primary px-4">Simpan</button></div></form></div></div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.32.2/ace.js"></script>
<script>
function openModal(id) { new bootstrap.Modal(document.getElementById(id)).show(); }

const permChecks = document.querySelectorAll('.perm-check');
const octalDisplay = document.getElementById('octalValue');
function updateOctal() {
    let u=0, g=0, o=0;
    permChecks.forEach(cb => {
        if (cb.checked) {
            let val = parseInt(cb.dataset.val), grp = cb.dataset.group;
            if (grp === 'u') u += val; if (grp === 'g') g += val; if (grp === 'o') o += val;
        }
    });
    octalDisplay.innerText = `${u}${g}${o}`;
}
permChecks.forEach(cb => cb.addEventListener('change', updateOctal));

function openPerms(name, octal) {
    document.getElementById('permTarget').value = name;
    const p = octal.toString().padStart(3, '0').split('');
    const types = ['u', 'g', 'o'], map = [4, 2, 1], actions = ['r', 'w', 'x'];
    types.forEach((t, ti) => {
        let val = parseInt(p[ti]);
        actions.forEach((a, ai) => {
            let el = document.getElementsByName(`perms[${t}${a}]`)[0];
            if(el) el.checked = (val & map[ai]);
        });
    });
    updateOctal(); openModal('permModal');
}

const checks = document.querySelectorAll('.item-checkbox');
const toolbar = document.getElementById('selectionToolbar');
function updateUI() {
    let count = document.querySelectorAll('.item-checkbox:checked').length;
    document.getElementById('selectedCount').innerText = count + " Item";
    count > 0 ? toolbar.classList.remove('d-none') : toolbar.classList.add('d-none');
}
document.getElementById('selectAll').onchange = (e) => { checks.forEach(c => c.checked = e.target.checked); updateUI(); };
checks.forEach(c => c.onchange = updateUI);

function setAction(type) { document.getElementById('actionType').value = type; }
function openRename(n) { document.getElementById('rnOld').value = n; document.getElementById('rnNew').value = n; openModal('renameModal'); }

let aceEditor = ace.edit("editor");
aceEditor.setTheme("ace/theme/monokai");
function editFile(n, c) {
    document.getElementById('editFile').value = n;
    document.getElementById('editTitle').innerText = "Edit: " + n;
    aceEditor.setValue(c, -1);
    openModal('editModal');
}
function prepareSave() { document.getElementById('editContent').value = aceEditor.getValue(); }
</script>