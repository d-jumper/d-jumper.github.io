<?php
if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

$node_name = isset($_GET['name']) ? preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['name']) : '';
if ($node_name) {
    $raw_log = shell_exec("sudo pm2 logs " . escapeshellarg($node_name) . " --lines 100 --nostream --raw 2>&1");
    if (empty($raw_log)) {
        echo "No logs available. Application might be stopped.";
    } else {
        $clean_log = preg_replace('/^\[TAILING\].*$/m', '', $raw_log);
        $clean_log = preg_replace('/^\/root\/.pm2\/logs\/.*$/m', '', $clean_log);
        echo trim($clean_log);
    }
}

?>