<?php

namespace DJumPer\Utils;

class Utils
{
    public static function limitString($string, $limit = 100)
    {
        if ($string === null) return null;

        if (!is_string($string)) {
            $string = (string)$string;
        }

        $string = strip_tags($string);

        return strlen($string) > $limit
            ? substr($string, 0, $limit) . "..."
            : $string;
    }

    public static function cleanString($string)
    {
        if ($string === null) return null;

        if (!is_string($string)) {
            $string = (string)$string;
        }

        $string = html_entity_decode($string, ENT_QUOTES | ENT_HTML5);
        $string = str_replace(['\\u002F', '\\u0026'], ['/', '&'], $string);
        $string = stripslashes($string);

        return trim($string, '"');
    }
}