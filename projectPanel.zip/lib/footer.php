</div>

<div class="sidebar-overlay" id="overlay" onclick="toggleSidebar()"></div>

<?php 
    //require_once('progressAction.php');
    require_once('toastNotification.php'); 
?>

<script>
    /*function toggleSidebarDesktop() {
        document.body.classList.toggle('sidebar-toggled');
    }*/
    function toggleSidebarDesktop() {
        const isToggled = document.body.classList.toggle('sidebar-toggled');
        localStorage.setItem('sidebarStatus', isToggled ? 'open' : 'closed');
    }
    
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }
    
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>