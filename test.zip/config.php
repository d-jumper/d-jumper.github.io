<?php
    date_default_timezone_set('Asia/Jakarta');
    
    $showErrorLog = false;
    if ($showErrorLog) {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(0);
    }
    
    $str = shell_exec("echo $(hostname)");
    $host_server = str_replace('
', '', $str);
    $host_panel = "cpanel";
    $port_panel = 8080;
    $path_panel = "/var/www/".$host_panel."/";
    
    $db_config = [
        'host' => 'localhost',
        'name' => 'cp_panel',
        'user' => 'phpmyadmin',
        'pass' => 'weweasd12312'
    ];
    
    $conn = mysqli_connect($db_config['host'], $db_config['user'], $db_config['pass'], $db_config['name']);
    if (!$conn) {
        die("Koneksi Database Gagal: " . mysqli_connect_error());
    }