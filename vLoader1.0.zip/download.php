<?php
date_default_timezone_set('Asia/Jakarta');

set_time_limit(0);
ini_set('memory_limit', '512M');
ini_set('zlib.output_compression', 'Off');
ignore_user_abort(false);

if (!isset($_GET['url'])) {
    http_response_code(400);
    die("Bad Request: URL parameter is missing.");
}

$url = $_GET['url'];
$parsed_url = parse_url($url);
if (!in_array($parsed_url['scheme'] ?? '', ['http', 'https'])) {
    http_response_code(403);
    die("Forbidden: Invalid protocol.");
}

$cookie = $_GET['cookie'] ?? '';
$title = $_GET['title'] ?? 'video_content';
$audio_type = isset($_GET['audio']) ? preg_replace('/[^a-zA-Z0-9]/', '', $_GET['audio']) : false;

while (ob_get_level()) { ob_end_clean(); }
$ch = curl_init();

curl_setopt_array($ch, [
    CURLOPT_URL => $url,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 5,
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_BUFFERSIZE => 262144,
    CURLOPT_ENCODING => "", 
    CURLOPT_TCP_KEEPALIVE => 1,
    CURLOPT_TCP_KEEPIDLE => 120,
    CURLOPT_TCP_KEEPINTVL => 60,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_2_0
]);

$desktopUA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
$iPhoneUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1';
$androidUA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
$apkUA = 'com.google.android.youtube/19.09.37 (Linux; U; Android 11) gzip';
$apkUA2 = 'com.google.android.youtube/21.08.265 (Linux; U; Android 12; id_ID; SM-G998B) gzip';
$smartTvUA= 'Mozilla/5.0 (SMART-TV; Linux; Tizen 6.5)';

$referer = null; $origin = null;
$host = $parsed_url['host'] ?? '';
$headers = [];
if (strpos($host, 'googlevideo.com') !== false || strpos($host, 'youtube.com') !== false) {
$headers[] = "User-Agent: com.google.android.youtube/21.08.265 (Linux; U; Android 12; id_ID; SM-G998B) gzip";
$headers[] = "Accept: */*";

    if (isset($_SERVER['HTTP_RANGE'])) {
        $headers[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
    }
} else {

    $uA = $desktopUA;
    if (strpos($host, 'tiktok.com') !== false || strpos($host, 'tiktokcdn.com') !== false) {
        $uA = $iPhoneUA;
        $referer = "Referer: https://www.tiktok.com/";
        $origin = "Origin: https://www.tiktok.com";
    } else if (strpos($host, 'fbcdn.net') !== false || strpos($host, 'instagram.com') !== false) {
        $referer = "Referer: https://www.instagram.com/";
        $origin = "Origin: https://www.instagram.com";
    } else if (strpos($host, 'facebook.com') !== false) {
        $referer = "Referer: https://www.facebook.com/";
        $origin = "Origin: https://www.facebook.com";
    }
    
    $headers[] = "User-Agent: " . $uA;
    $headers[] = "Accept: */*";
    $headers[] = "Connection: keep-alive";
    $headers[] = "Sec-Fetch-Dest: video";
    $headers[] = "Sec-Fetch-Mode: no-cors";
    $headers[] = "Sec-Fetch-Site: cross-site";
    
    if ($referer) $headers[] = $referer;
    if ($origin) $headers[] = $origin;

    if (!empty($cookie)) {
        $headers[] = (strpos($cookie, '=') === false) ? "Cookie: ttwid=" . $cookie : "Cookie: " . $cookie;
    }
    if (isset($_SERVER['HTTP_RANGE'])) {
        $headers[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
    }
}

$valid = false;
$allowedHosts = [
    'googlevideo.com', 'youtube.com',
    'tiktok.com', 'tiktokcdn.com',
    'fbcdn.net', 'instagram.com',
    'facebook.com'
];
foreach ($allowedHosts as $h) {
    if (strpos($host, $h) !== false) {
        $valid = true;
        break;
    }
}
if (!$valid) { die("Forbidden: Host not allowed."); }
    
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_HEADERFUNCTION, function($curl, $header) use ($title, $audio_type) {
    $len = strlen($header);
    $h = strtolower($header);
    
    if (preg_match('/^http\/(1\.[01]|2|3)\s+(\d+)/', $h, $matches)) {
        http_response_code(intval($matches[2]));
        return $len;
    }

    $allowed = ['content-type:', 'content-length:', 'content-range:', 'accept-ranges:'];
    foreach ($allowed as $a) {
        if (strpos($h, $a) === 0) {
            if ($audio_type && $a === 'content-type:') {
                header("Content-Type: application/octet-stream");
            } elseif ($a === 'content-type:' && strpos($h, 'application/octet-stream') !== false) {
                header("Content-Type: video/mp4");
            } else { 
                header($header, false); 
            }
            break;
        }
    }

    if (strpos($h, 'content-type:') === 0) {
        $cleanTitle = preg_replace('/[^A-Za-z0-9_\- \(\)\[\]]/', '_', $title);
        $ext = $audio_type ? $audio_type : "mp4";
        header("Content-Disposition: attachment; filename=\"{$cleanTitle}.{$ext}\"");
    }

    return $len;
});

curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($curl, $data) {
    if (connection_aborted()) { return -1; }
    echo $data; 
    ob_flush(); 
    flush(); 
    return strlen($data);
});

//curl_setopt($ch, CURLOPT_HEADER, true);
$result = curl_exec($ch);
curl_close($ch);
exit;