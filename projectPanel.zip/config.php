<?php
    // 1. Pengaturan Waktu
    date_default_timezone_set('Asia/Jakarta');
    
    // 2. Error Reporting (Ubah ke false jika sudah online/production)
    $is_development = true; 
    if ($is_development) {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    } else {
        error_reporting(0);
        ini_set('display_errors', '0');
    }
    
    // 3. Konfigurasi Host & Path
    $host_server = gethostname();
    $host_panel  = "control-panel." . $host_server;
    $port_panel  = 8080;
    // Gunakan __DIR__ agar path selalu tepat relatif terhadap lokasi file ini
    $path_panel  = __DIR__ . "/"; 

    // 4. Konfigurasi Database
    $db_config = [
        'host' => '127.0.0.1', // Menggunakan IP lebih stabil daripada 'localhost'
        'name' => 'db_panel',
        'user' => 'admin',
        'pass' => '0987654321',
        'charset' => 'utf8mb4'
    ];
    
    // 5. Membuat Koneksi
    $conn = mysqli_connect(
        $db_config['host'], 
        $db_config['user'], 
        $db_config['pass'], 
        $db_config['name']
    );
    
    // 6. Validasi Koneksi & Set Charset
    if (!$conn) {
        // Jangan tampilkan detail error di production untuk keamanan
        error_log("Koneksi Database Gagal: " . mysqli_connect_error());
        die("Maaf, terjadi masalah pada koneksi ke server.");
    }

    mysqli_set_charset($conn, $db_config['charset']);
?>