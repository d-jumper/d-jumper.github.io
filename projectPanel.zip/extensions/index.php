<?php
/**
 * AUTHENTICATION & ROUTING
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['user']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}
if ($_SESSION['role'] === 'user') {
    $page = 'domains';
} else if($_SESSION['role'] !== 'admin') {
    $msg = "Access+denied!";
    echo "<script>window.location.href='?status=danger&msg=$msg';</script>";
}

/**
 * PARAMETER
 */
$keyword_package = $_GET['package'] ?? '';
$title_package = $_GET['title'] ?? '';
$base_page = $_GET['page'] ?? '';
$base_subpage = $_GET['subpage'] ?? '';
$base_param = "page=$base_page&subpage=$base_subpage&package=$keyword_package&title=$title_package";
$current_url = "?$base_param";
$back_button = "?page=home";

// Query ambil semua extension
$ext_query = $conn->query("SELECT * FROM extensions ORDER BY category ASC, title ASC");
$extensions = [];
while ($row = $ext_query->fetch_assoc()) {
    $extensions[$row['category']][] = $row;
}

$subpage_key = isset($_GET['subpage']) ? $_GET['subpage'] : '';
if (!empty($subpage_key)) {
    include('extensions/installer.php');
} else { ?>

    <div class="container mt-4 pb-5">
        <div class="plesk-card-header p-3 border-bottom d-flex justify-content-between align-items-center">
            <span class="fw-bold"></span>
            <div class="d-flex gap-2">
                <a href="<?= $back_button ?>" class="btn btn-white border shadow-sm rounded-3 px-3">
                    <img src="pma/themes/bootstrap/img/b_left.png" width="20" class="me-1"></img> Back
                </a>
            </div>
        </div>
        
        <?php foreach ($extensions as $category => $items): ?>
            <h5 class="fw-bold mt-4 mb-3 text-uppercase text-muted" style="font-size: 0.8rem; letter-spacing: 1px;">
                <?= str_replace('-', ' ', $category) ?>
            </h5>
            <div class="row g-3">
                <?php foreach ($items as $ext): ?>
                    <div class="col-6 col-md-3">
                        <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                            <div class="card-body text-center p-4">
                                <img src="<?php echo srcIcon($ext['package']); ?>" width="48" height="48" class="mb-3 object-fit-contain">
                                <br/><span class="small text-dark fw-bold mb-1"><?php echo htmlspecialchars($ext['title']); ?></span>
                            </div>
                            <div class="card-body text-center">
                                <a href="?page=extensions&subpage=installer&package=<?php echo $ext['package']; ?>&title=<?php echo $ext['title']; ?>" class="btn btn-sm btn-outline-primary w-100 rounded-pill">
                                    <span class="small text-dark fw-bold">Manage</span>
                                </a>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

<?php } ?>