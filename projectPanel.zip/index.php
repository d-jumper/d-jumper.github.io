<?php
session_start();
require_once('config.php'); 

if (isset($_SESSION['user']) && $_SESSION['role'] == 'root') {
    header("Location: dashboard.php");
    exit();
}
$msg = "";
$msg_type = "danger";

$is_root_exists = false;
$check_root = $conn->query("SELECT id FROM admin WHERE role='root' LIMIT 1");
if ($check_root && $check_root->num_rows > 0) {
    $is_root_exists = true;
}

if (isset($_POST['register_root']) && !$is_root_exists) {
    if ($is_root_exists) {
        die("Akses Ilegal: Administrator sudah ada.");
    }
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $pwd = mysqli_real_escape_string($conn, $_POST['password']);
    
    if (strlen($pwd) < 6) {
        $msg = "Password minimal harus 6 karakter!";
    } else {
        $username_db_admin = "db_" . $username;
        $pwd_hash = password_hash($pwd, PASSWORD_DEFAULT);
        $host_panel = mysqli_real_escape_string($conn, $_POST['host_panel']);
        
        $conn->begin_transaction();
        try {
            $stmt1 = $conn->prepare("INSERT INTO admin (username, password, role) VALUES (?, ?, 'root')");
            $stmt1->bind_param("ss", $username, $pwd_hash);
            $stmt1->execute();
            
            $conn->commit();
            $msg = "<b>Administrator</b> berhasil didaftarkan!</b>";
            $msg_type = "success";
            $is_root_exists = true; 
    
        } catch (Exception $e) {
            $conn->rollback();
            $msg = "Gagal Setup: " . $e->getMessage();
        }
    }
    
}

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']); 
    $pass = $_POST['password'];

    // LANGKAH 1: Cek di tabel Admin (Root)
    $stmt = $conn->prepare("SELECT id, username, password, 'root' as role FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        // LANGKAH 2: Jika bukan admin, cek di tabel db_users (User Biasa)
        $stmt = $conn->prepare("SELECT id, username, pwdb as password, role FROM db_users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();
    }

    if ($res && $res->num_rows > 0) {
        $data = $res->fetch_assoc();
        
        // Verifikasi password (menggunakan password_verify karena kita simpan hash)
        if (password_verify($pass, $data['password'])) {
            
            // Set Session Dasar
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['user']    = $data['username'];
            $_SESSION['role']    = $data['role'];

            if ($data['role'] === 'root') {
                header("Location: dashboard.php");
            } else {
                $_SESSION['id_user']   = $data['id'];
                $_SESSION['username_user'] = $data['username'];
                header("Location: dashboard.php?page=manage");
            }
            exit();
        } else {
            $msg = "Password salah!";
        }
    } else {
        $msg = "Akun tidak ditemukan.";
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <title>CP Panel - <?php echo $is_root_exists ? 'Login' : 'System Setup'; ?></title>
    <style>
        body { background: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .auth-card { max-width: 400px; margin: 100px auto; border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); overflow: hidden; }
        .setup-header { background: #00a8e0; color: white; padding: 40px 20px; text-align: center; }
        .btn-primary { background: #00a8e0; border: none; padding: 12px; font-weight: 600; transition: 0.3s; }
        .btn-primary:hover { background: #008dbd; transform: translateY(-2px); }
        .form-control { padding: 12px; border-radius: 8px; }
        .alert { border-radius: 10px; }
    </style>
</head>
<body>

<div class="container">
    <div class="card auth-card">
        <div class="setup-header">
            <i class="bi bi-cpu-fill" style="font-size: 3.5rem;"></i>
            <h4 class="mt-3 fw-bold">CP PANEL</h4>
            <p class="mb-0 opacity-75 small text-uppercase tracking-wider">
                <?php echo $is_root_exists ? 'Secure Authentication' : 'Initial System Setup'; ?>
            </p>
        </div>
        <div class="card-body p-4">

            <?php if($msg): ?>
                <div class="alert alert-<?php echo $msg_type; ?> small shadow-sm mb-4">
                    <i class="bi bi-info-circle me-2"></i> <?php echo $msg; ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Username</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-person text-primary"></i></span>
                        <input type="text" name="username" class="form-control border-start-0" placeholder="Masukkan username" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted">Password</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-shield-lock text-primary"></i></span>
                        <input type="password" name="password" class="form-control border-start-0" placeholder="Masukkan password" required>
                    </div>
                </div>
                
                <?php if (!$is_root_exists): ?>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">Domain / Host Panel</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-globe text-primary"></i></span>
                            <input type="text" name="host_panel" class="form-control border-start-0" value="<?php echo $host_panel; ?>" required readonly>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!$is_root_exists): ?>
                    <button name="register_root" class="btn btn-primary w-100 mb-3 shadow-sm">
                        <i class="bi bi-rocket-takeoff me-2"></i> Install System Now
                    </button>
                    <div class="p-2 bg-light rounded text-center">
                        <small class="text-muted" style="font-size: 0.75rem;">
                            <i class="bi bi-exclamation-triangle-fill text-warning"></i> 
                            Pendaftaran ini hanya tersedia satu kali untuk akun administrator utama.
                        </small>
                    </div>
                <?php else: ?>
                    <button name="login" class="btn btn-primary w-100 shadow-sm">
                        <i class="bi bi-box-arrow-in-right me-2"></i> Sign In
                    </button>
                <?php endif; ?>
            </form>
        </div>
        <div class="card-footer bg-white border-0 text-center pb-4">
            <small class="text-muted" style="font-size: 0.7rem;">&copy; <?php echo date('Y'); ?> PanelControl. All Rights Reserved.</small>
        </div>
    </div>
</div>

</body>
</html>