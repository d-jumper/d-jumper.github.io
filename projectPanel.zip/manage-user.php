<?php 
require_once('lib/session_user.php');

/**
* PARAMETER
**/
$disk_usage = getFolderSize($path_user);
$traffic_usage = getTrafficUsage($domain_user);
$is_online = is_dir($path_user . "/httpdocs");

/**
 * SUB-ROUTING EXTENSIONS
 */
$extension_key = isset($_GET['extensions']) ? $_GET['extensions'] : '';
if (!empty($extension_key)) {
    $check_ext = $conn->prepare("SELECT path_location FROM extensions WHERE package = ? AND is_installed = 'true'");
    $check_ext->bind_param("s", $extension_key);
    $check_ext->execute();
    $ext_res = $check_ext->get_result()->fetch_assoc();

    if ($ext_res && file_exists($ext_res['path_location'])) {
        include($ext_res['path_location']);
    } else {
        echo "<div class='alert alert-warning'>Extension tidak ditemukan atau belum diinstal.</div>";
    }
} else { ?>
    
    <div class="container mt-4 pb-5">
        <div class="row g-4 text-dark">
            <div class="col-md-12">
                <div class="plesk-card">
                    <div class="plesk-card-header d-flex justify-content-between align-items-center">
                        <a href="http://<?= $domain_user ?>" target="_blank" class="text-primary text-decoration-none fw-medium">
                            <span><i class="bi bi-globe me-2"></i> <?= htmlspecialchars($domain_user) ?></span>
                            <i class="bi bi-box-arrow-up-right text-muted small"></i>
                        </a>
                        <span class="badge bg-<?= $is_online ? 'success' : 'danger' ?>">Status: <?= $is_online ? 'Active' : 'Non Active' ?></span>
                    </div>
                    <div class="p-4">
                        <div class="row align-items-center">
                            <div class="col-md-6 border-end">
                                <table class="table table-sm table-borderless mb-0">
                                    <tr><td class="text-muted" width="150">System User</td><td class="fw-bold">: <?= $username_user ?></td></tr>
                                    <tr><td class="text-muted">IPv4 Address</td><td class="fw-bold">: <?= $ip_Server ?></td></tr>
                                    <tr><td class="text-muted">Web Server</td><td class="fw-bold">: <?= ucfirst($type_server) ?></td></tr>
                                    <tr><td class="text-muted">PHP Version</td><td class="fw-bold">: PHP<?= $php_v_user ?>-FPM</td></tr>
                                </table>
                            </div>
                            <div class="col-md-6 ps-md-4">
                                <div class="plesk-card-header text-muted"> Resource Usage Estimate:</div>
                                <div class="d-flex justify-content-between align-items-center mb-4">
                                    <div class="col-4">
                                        <div class="fw-bold">Disk</div>
                                        <div class="text-primary"><?= $disk_usage ?> MB</div>
                                    </div>
                                    <div class="col-4 border-start border-end">
                                        <div class="fw-bold">Traffic</div>
                                        <div class="text-primary"><?= $traffic_usage ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $ext_query = $conn->query("SELECT * FROM extensions WHERE is_installed = 'true' ORDER BY category ASC, title ASC");
            $extensions = [];
            while ($row = $ext_query->fetch_assoc()) {
                $extensions[$row['category']][] = $row;
            }
            foreach ($extensions as $category => $items): ?>
                <div class="plesk-card">
                    <div class="plesk-card-header"><?= ucfirst(str_replace('-', ' ', $category)) ?></div>
                    <div class="row g-2 justify-content-start"> <?php foreach ($items as $ext): ?>
                            <div class="col-4 col-sm-3 col-md-2"> <div class="card-body text-center p-2 h-100">
                                    <a href="?page=domains&subpage=manage&extensions=<?= $ext['package'] ?>&id=<?= $id_user ?>" class="text-decoration-none">
                                        <img src="<?= $ext['icon'] ?>" width="48" height="48" class="mb-2 object-fit-contain">
                                        <br/>
                                        <span class="small text-dark fw-bold" style="font-size: 0.75rem; display: block; line-height: 1.2;">
                                            <?= htmlspecialchars($ext['title']) ?>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <div class="col-md-12">
                <div class="plesk-card h-100">
                    <div class="plesk-card-header">Account Security</div>
                    <div class="p-4 text-center">
                        <p class="small text-muted">Gunakan fitur ini untuk mereset password FTP/Panel user.</p>
                        <button class="btn btn-outline-warning btn-sm w-100 mb-2"><i class="bi bi-key me-1"></i> Change Password</button>
                        <button class="btn btn-outline-secondary btn-sm w-100"><i class="bi bi-envelope me-1"></i> Send Credentials</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php } ?>