<?php

/**
 * AUTHENTICATION & ROUTING
 */
    if($role_user !== 'admin') {
        header("Location: dashboard.php?");
        exit();
    }
            
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id_session);
    $stmt->execute();
    $res_admin = $stmt->get_result();
    if(!$data_admin = $res_admin->fetch_assoc()){
        header("Location: dashboard.php?");
        exit();
    }
    
    /**
    * PARAMETER
    **/
    $id_user = $data_admin['id'];
    $username_user = $data_admin['username'];
    $email_user = $data_admin['email'];
    
    $base_ext = "?page=extensions";
    $base_services = "?page=settings";
    $current_ext = "$base_ext&subpage=$subpage";
    $current_services = "$base_services&subpage=$subpage";
?>