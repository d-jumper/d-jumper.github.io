<?php

	if (empty($_SESSION['token'])) {
		$_SESSION['token'] = bin2hex(random_bytes(32));
	}

	$config['csrf_token'] = $_SESSION['token'];
	$access_token = $config['csrf_token'];

	if ($_POST AND !isset($_POST['csrf_token'])) {
		exit("Request Denied!");
	} else if ($_POST AND isset($_POST['csrf_token'])) {
		if (hash_equals($_SESSION['token'], $_POST['csrf_token']) == false) {
		    exit("Request Denied!");
		}
	}

?>