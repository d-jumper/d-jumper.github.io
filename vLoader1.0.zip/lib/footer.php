<!-- 
    // Footer Styles
-->
        
        <div class="donation-section">
        <p>"Layanan ini gratis dan tanpa iklan. Jika Anda menyukainya, bantu saya menjaga server tetap menyala dengan traktir kopi!"</p>
        <div class="donation-container">
            <a href="https://www.buymeacoffee.com/USERNAME_ANDA" target="_blank" class="coffee-btn">
                <i class="fas fa-coffee"></i> Buy me a coffee
            </a>
            
            <a href="https://trakteer.id/USERNAME_ANDA" target="_blank" class="trakteer-btn">
                <i class="fas fa-heart"></i> Trakteer
            </a>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date('Y') ?> <strong>V-Loader</strong>. Made with <i class="fas fa-heart" style="color: #e25555;"></i> for creators.</p>
    </footer>
</div>

<script>
    const video = document.getElementById('sharing-main-video-el');
    if (video) {
        video.addEventListener('play', function() {
            if (video.duration === 0 || isNaN(video.duration)) {
                video.load();
            }
        }, { once: true });
    }

    async function grabVideo() {
        const inputUrl = document.getElementById('input-url');
        const btnSearch = document.getElementById('btn-search');
        const resultDisplay = document.getElementById('result-display');
        
        if (!inputUrl.value) return alert("Masukkan URL terlebih dahulu!");
    
        const originalText = btnSearch.innerHTML;
        btnSearch.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Mencari...';
        btnSearch.disabled = true;
    
        try {
            const response = await fetch(`handler.php?url=${encodeURIComponent(inputUrl.value)}&handler=get_data`);
            const res = await response.json();
    
            if (res.status) {
                const data = res.data;

                let formatType = 'mp4';
                data.streaming_data.forEach(q => {
                    formatType = `${q.type}`;
                });
                let optionsHtml = '';
                data.video_data.forEach(q => {
                    optionsHtml += `<option value='{"type":"download_video","itag":${q.itag}}'>${q.qualityLabel}</option>`;
                });
                data.audio_data.forEach(q => {
                    optionsHtml += `<option value='{"type":"download_audio","itag":${q.itag}}'>${q.qualityLabel}</option>`;
                });
                
                resultDisplay.innerHTML = `
                    <div class="result-container">
                        <div class="video-preview">
                            <video id="sharing-main-video-el" controls controlsList="nodownload" oncontextmenu="return false;" playsinline poster="${data.thumbnail}">
                                <source src="handler.php?url=${encodeURIComponent(inputUrl.value)}&handler=streaming" type="video/${formatType}">
                            </video>
                        </div>
                        <div class="video-details">
                            <span class="badge">${data.platform}</span>
                            <h2>${data.title}</h2>
                            <form id="download_form">
                                <select name="download_select" class="form-select">
                                    ${optionsHtml}
                                </select>
                                <button type="button" id="btn-download" class="dl-btn" onclick="executeDownload('${inputUrl.value}')"> Download</button>
                            </form>
                        </div>
                    </div>
                `;
            } else {
                resultDisplay.innerHTML = `<div class="result-container"><span class="badge">${res.message}</span></div>`;
            }
        } catch (error) {
            resultDisplay.innerHTML = `<div class="result-container"><span class="badge">Error: Sedang ada gangguan pada server.</span></div>`;
        } finally {
            resultDisplay.style.display = 'block';
            btnSearch.innerHTML = originalText;
            btnSearch.disabled = false;
        }
    }
    
    function executeDownload(url) {
        if (!url) return alert("Masukkan URL terlebih dahulu!");
        let actionType = null; let itag = null;
    
        const El = document.getElementById('download_form');
        const btn = document.getElementById('btn-download');
        const selectEl = El.querySelector('select[name="download_select"]');
        const selectedValue = selectEl.value;
        
        const data = JSON.parse(selectedValue);
        actionType = data.type;
        itag = data.itag;
        
        const originalContent = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Memproses...';
        btn.disabled = true;
    
        let downloadUrl = '';
        downloadUrl = `handler.php?url=${encodeURIComponent(url)}&handler=download`;
        if (actionType) downloadUrl += `&type=${encodeURIComponent(actionType)}`;
        if (itag) downloadUrl += `&itag=${encodeURIComponent(itag)}`;
        window.open(downloadUrl, "_blank");
    
        setTimeout(() => {
            btn.innerHTML = originalContent;
            btn.disabled = false;
        }, 5000);
    }
</script>
</body>
</html>