<?php
// user/manage-user.php

// Ambil ID dari URL
$id = (int)$_GET['id'];
$res_user = $conn->query("SELECT * FROM db_users WHERE id = $id");
$u = $res_user->fetch_assoc();

// Jika user tidak ditemukan, kembali ke daftar domain
if (!$u) { 
    echo "<script>location.href='?page=domains';</script>"; 
    exit; 
}

// Logika Sub-routing
$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'overview';
 
switch($subpage) {
    case 'file-manager':
        $_GET['id'] = $u['id'];
        $_GET['user'] = $u['username'];
        $_GET['db'] = $u['db'];
        $_GET['domain'] = $u['domain'];
        include('file-manager/index.php');
        break;
    case 'database':
        $_GET['id'] = $u['id'];
        $_GET['user'] = $u['username'];
        $_GET['db'] = $u['db'];
        $_GET['domain'] = $u['domain'];
        include('db-manager/index.php');
        break;
    case 'node-config':
        $_GET['id'] = $u['id'];
        $_GET['user'] = $u['username'];
        $_GET['db'] = $u['db'];
        $_GET['domain'] = $u['domain'];
        include('node-manager/index.php');
        break;
    case 'php-settings':
        $_GET['id'] = $u['id'];
        $_GET['user'] = $u['username'];
        $_GET['db'] = $u['db'];
        $_GET['domain'] = $u['domain'];
        include('php-manager/index.php');
        break;
    default:
        // TAMPILAN DASHBOARD USER (OVERVIEW)
        ?>
        <div class="row g-4 text-dark">
            <div class="col-md-12">
                <div class="plesk-card">
                    <div class="plesk-card-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-globe me-2"></i> <?php echo htmlspecialchars($u['domain']); ?></span>
                        <span class="badge bg-success">Status: Active</span>
                    </div>
                    <div class="p-4">
                        <div class="row align-items-center">
                            <div class="col-md-6 border-end">
                                <table class="table table-sm table-borderless mb-0">
                                    <tr><td class="text-muted" width="150">System User</td><td class="fw-bold">: <?php echo $u['username']; ?></td></tr>
                                    <tr><td class="text-muted">IPv4 Address</td><td class="fw-bold">: <?php echo $_SERVER['SERVER_ADDR']; ?></td></tr>
                                </table>
                            </div>
                            <div class="col-md-6 ps-md-4">
                                <div class="small text-muted mb-2">Resource Usage Estimate:</div>
                                <div class="row text-center small">
                                    <div class="col-4">
                                        <div class="fw-bold">Disk</div>
                                        <div class="text-primary">124 MB</div>
                                    </div>
                                    <div class="col-4 border-start border-end">
                                        <div class="fw-bold">Traffic</div>
                                        <div class="text-primary">1.2 GB</div>
                                    </div>
                                    <div class="col-4">
                                        <div class="fw-bold">Files</div>
                                        <div class="text-primary">842</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="row g-3">
                    <div class="col-6 col-md-3">
                        <a href="?page=manage&id=<?php echo $id; ?>&subpage=file-manager" class="action-box">
                            <i class="bi bi-folder2-open text-warning"></i><span>File Manager</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="?page=manage&id=<?php echo $id; ?>&subpage=database" class="action-box">
                            <i class="bi bi-database-fill-gear text-info"></i><span>Databases</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="?page=manage&id=<?php echo $id; ?>&subpage=node-config" class="action-box">
                            <i class="bi bi-hexagon-fill text-success"></i><span>Node.js Config</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a href="?page=manage&id=<?php echo $id; ?>&subpage=php-settings" class="action-box">
                            <i class="bi bi-filetype-php text-primary"></i><span>PHP Settings</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="plesk-card h-100">
                    <div class="plesk-card-header">Access Details</div>
                    <div class="p-4">
                        <h6 class="fw-bold border-bottom pb-2 mb-3">Database Connection</h6>
                        <div class="bg-light p-3 rounded">
                            <div class="small text-muted">DB Name / DB User:</div>
                            <code class="text-dark d-block mb-2"><?php echo $u['db']; ?></code>
                            <div class="small text-muted">Host:</div>
                            <code class="text-dark d-block">localhost</code>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="col-md-6">
                <div class="plesk-card h-100">
                    <div class="plesk-card-header">Account Security</div>
                    <div class="p-4 text-center">
                        <p class="small text-muted">Gunakan fitur ini untuk mereset password FTP/Panel user.</p>
                        <button class="btn btn-outline-warning btn-sm w-100 mb-2"><i class="bi bi-key me-1"></i> Change Password</button>
                        <button class="btn btn-outline-secondary btn-sm w-100"><i class="bi bi-envelope me-1"></i> Send Credentials</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    break;
}
?>