<?php
    date_default_timezone_set('Asia/Jakarta');
    require_once 'vendor/autoload.php';
    use DJumPer\Downloader;
    
    $result = null;
    $error = null;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            $dl = new Downloader();
            $result = $dl->getVideoInfo($_POST['url']);
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
    
    require_once('lib/header.php');
?>

    <div class="glass-card">
    
        <div class="search-form">
            <input type="text" id="input-url" placeholder="Tempel link video (YouTube, TikTok, FB, IG)..." required>
            <button type="button" onclick="grabVideo()" id="btn-search" class="dl-btn">Cari Video</button>
        </div>
        <div id="result-display" style="display: none;"></div>
                        <!--<div class="video-preview">
                            <video id="sharing-main-video-el" controls controlsList="nodownload" oncontextmenu="return false;" playsinline>
                                <source src="s.php?url=https://youtu.be/wAnfpeUavRU" type="video/mp4">
                            </video>
                        </div>-->
    </div>

    <section class="about-section">
        <h2>Layanan Terbaik Untuk Anda</h2>
        <p style="color: var(--text-muted); max-width: 600px; margin: 10px auto;">Nikmati kemudahan mengunduh konten multimedia dari berbagai platform dengan kualitas terbaik dan proses yang transparan.</p>
        
        <div class="features-grid">
            <div class="feature-item">
                <i class="fas fa-bolt"></i>
                <h3>Sangat Cepat</h3>
                <p>Proses pemindaian link dilakukan secara real-time untuk hasil instan.</p>
            </div>
            <div class="feature-item">
                <i class="fab fa-tiktok"></i>
                <h3>TikTok Bersih</h3>
                <p>Dapatkan video TikTok tanpa logo watermark untuk koleksi pribadi Anda.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-user-shield"></i>
                <h3>Aman & Anonim</h3>
                <p>Kami menghargai privasi Anda. Tidak ada data pribadi yang kami kumpulkan.</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-headphones-alt"></i>
                <h3>Ekstrak Audio</h3>
                <p>Ubah video musik menjadi file MP3 berkualitas tinggi dengan satu klik.</p>
            </div>
        </div>
    </section>

<?php
    require_once('lib/footer.php');
?>