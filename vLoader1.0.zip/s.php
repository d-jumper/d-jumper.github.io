<?php
// 1. Naikkan limit setinggi mungkin
ini_set('pcre.backtrack_limit', 10000000);
ini_set('pcre.recursion_limit', 10000000);
date_default_timezone_set('Asia/Jakarta');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ==========================================
// CLASS HTTP CLIENT (ALA GUZZLE)
// ==========================================

class Response {
    protected $body;
    protected $info;

    public function __construct($body, $info) {
        $this->body = $body;
        $this->info = $info;
    }

    public function getBody() {
        return $this->body;
    }

    public function json() {
        return json_decode($this->body, true);
    }

    public function getStatusCode() {
        return $this->info['http_code'];
    }
}

class Client {
    protected $defaultHeaders;

    public function __construct($headers = null) {
        $this->defaultHeaders = $headers ? (is_array($headers) ? $headers : [$headers]) : [
            "User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "Accept-Language: en-US,en;q=0.9"
        ];
    }

    private function request($method, $url, $options = []) {
        $ch = curl_init($url);
        $headers = $options['headers'] ?? $this->defaultHeaders;
        $postFields = null;

        if (isset($options['json'])) {
            $postFields = json_encode($options['json']);
            $headers[] = 'Content-Type: application/json';
        } elseif (isset($options['form_params'])) {
            $postFields = http_build_query($options['form_params']);
            $headers[] = 'Content-Type: application/x-www-form-urlencoded';
        }

        $curlOptions = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_ENCODING       => '',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_FOLLOWLOCATION => true
        ];

        if ($postFields) {
            $curlOptions[CURLOPT_POSTFIELDS] = $postFields;
        }

        curl_setopt_array($ch, $curlOptions);
        $result = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);

        return new Response($result, $info);
    }

    public function get($url, $options = []) {
        return $this->request('GET', $url, $options);
    }

    public function post($url, $options = []) {
        return $this->request('POST', $url, $options);
    }
}
/**
  * EXAMPLE
  
$userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
$client = new Client(["User-Agent: $userAgent"]);

// POST & GET ACTION
# $option -> header or header with post field in array
# post field suuport : json (payload) || form_params (files)

$response = $client->post($url, $option);
$response = $client->get($url, $option);

// GET STATUS CODE
$status = $response->getStatusCode();

// GET BODY REQUEST
$html = $response->getBody();

// JSON_DECODE
$data = $response->json();

**/


// ==========================================
// LOGIKA UTAMA YOUTUBE
// ==========================================

// Inisialisasi Client dengan UserAgent khusus YouTube
$client = new Client();

$url = "https://youtu.be/wAnfpeUavRU";
preg_match('%(?:youtube\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/\s]{11})%i', $url, $match);
$videoId = $match[1] ?? null;
if (!$videoId) die("Video ID tidak ditemukan");
    
$whatchUrl = "https://www.youtube.com/watch?v=" . $videoId;
$response = $client->get($whatchUrl, [
    'headers' => [
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept: */*",
        "Accept-Language: de,de-DE;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6"
    ]
]);
$html = $response->getBody(); 

$pattern = '/ytcfg\.set\(\s*({.*?})\s*\)\s*;/s';
preg_match($pattern, $html, $matches);
$jsonString = $matches[1];
$ytcfgArray = json_decode($jsonString, true);

$jsUrl = $ytcfgArray['PLAYER_JS_URL'] ?? '';
if (strpos($jsUrl, 'http') !== 0) $jsUrl = "https://www.youtube.com" . $jsUrl;
$baseJs = $client->get($jsUrl)->getBody();
//header('Content-Type: text/plain; charset=utf-8'); echo $baseJs; exit();
function getSignatureCipher($baseJs, $signature) {
    // 1. Cari langsung BODY dari fungsi decipher
    // Mendukung tanda kutip ganda ("") maupun kutip tunggal ('')
    $funcPattern = '/([a-zA-Z0-9$]+)\s*=\s*function\(\s*([a-zA-Z0-9$]+)\s*\)\s*\{\s*\2\s*=\s*\2\.split\(\s*["\']{2}\s*\)\s*;\s*([^}]+)\s*;\s*return\s+\2\.join\(\s*["\']{2}\s*\)\s*\}/';
    
    if (!preg_match($funcPattern, $baseJs, $matches)) {
        // Fallback: Pola pencarian alternatif jika tidak ada return eksplisit di akhir
        $fallbackPattern = '/function\(\s*([a-zA-Z0-9$]+)\s*\)\s*\{\s*\1\s*=\s*\1\.split\(\s*["\']{2}\s*\)\s*;\s*(([a-zA-Z0-9$]+)\.[a-zA-Z0-9$]+\(\1,\s*\d+\);[^}]+)join\(\s*["\']{2}\s*\)/';
        
        if (!preg_match($fallbackPattern, $baseJs, $fallbackMatches)) {
            return "Gagal menemukan struktur fungsi decipher. Pastikan regex mencakup variasi ES6.";
        }
        $funcArg = $fallbackMatches[1];
        $funcBody = $fallbackMatches[2];
        $objName = preg_quote($fallbackMatches[3]);
    } else {
        $funcArg = $matches[2];  // Argumen (biasanya 'a')
        $funcBody = $matches[3]; // Isi di tengah (instruksi manipulasi array)
        
        // Ekstrak nama Helper Object dari dalam isi fungsi
        if (!preg_match('/([a-zA-Z0-9$]+)\.[a-zA-Z0-9$]+\(' . preg_quote($funcArg) . ',\s*[0-9]+\)/', $funcBody, $objMatches)) {
            return "Gagal menemukan Helper Object di dalam fungsi.";
        }
        $objName = preg_quote($objMatches[1]);
    }

    // 2. Cari definisi dari Helper Object beserta method-methodnya
    $objBodyRegex = '/(?:var\s+|,|\b)' . $objName . '\s*=\s*\{([^}]+)\}/';
    if (!preg_match($objBodyRegex, $baseJs, $objBodyMatches)) {
        return "Gagal menemukan isi Helper Object.";
    }
    
    $objBody = $objBodyMatches[1];

    // 3. Ekstrak setiap instruksi di dalam fungsi utama
    preg_match_all('/' . $objName . '\.([a-zA-Z0-9$]+)\(' . preg_quote($funcArg) . ',\s*([0-9]+)\)/', $funcBody, $instructions);
    
    $sigArray = str_split($signature);

    // 4. Jalankan instruksi sesuai dengan method yang ada di Helper Object
    for ($i = 0; $i < count($instructions[0]); $i++) {
        $methodName = preg_quote($instructions[1][$i]);
        $param = (int) $instructions[2][$i];
        
        // Cek isi method di dalam Helper Object
        if (preg_match('/' . $methodName . '\s*:\s*function\([^)]*\)\s*\{([^}]+)\}/', $objBody, $methodMatch)) {
            $methodBody = $methodMatch[1];
            
            if (strpos($methodBody, 'reverse') !== false) {
                $sigArray = array_reverse($sigArray);
            } elseif (strpos($methodBody, 'splice') !== false) {
                array_splice($sigArray, 0, $param);
            } else {
                // Swap
                $temp = $sigArray[0];
                $sigArray[0] = $sigArray[$param % count($sigArray)];
                $sigArray[$param % count($sigArray)] = $temp;
            }
        }
    }
    
    return implode("", $sigArray);
}


// Anggap $signature adalah string signature acak yang didapat dari URL stream (parameter 's')
$dummySignature = "ALUMINA_DUMMY_SIGNATURE_STRING_TO_TEST_THE_FUNCTION"; 
$decryptedSignature = getSignatureCipher($baseJs, $dummySignature);

header('Content-Type: application/json; charset=utf-8'); 
echo json_encode([
    'baseJsUrl' => $jsUrl,
    'baseJsSize' => strlen($baseJs),
    'decryptedSignature' => $decryptedSignature
], JSON_PRETTY_PRINT); 
exit();

preg_match('/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/s', $html, $match);
$data = json_decode($match[1], true);
 header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_PRETTY_PRINT); exit();

$client_name = "ANDROID";
require_once("clientData.php");
foreach($clientData['client'] as $c){
    if($c['clientName'] == $client_name) {
        $int_client_name = $c['clientId'];
        $client_version = $c['clientVersion'];
        $client_userAgent = $c['userAgent'];
        $apiKey = $c['apiKey'];
    }
}

// 2. Ambil konten base.js
function getContentData($client, $videoId, $userAgent) {
    $apiKey = null; $payload = []; $sigTimestamp = time();
    
    $whatchUrl = "https://www.youtube.com/watch?v=" . $videoId;
    $response = $client->get($whatchUrl, [
        'headers' => [
            "User-Agent: " . $userAgent,
            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language: en-US,en;q=0.5"
        ]
    ]);
    $html = $response->getBody();
    
    $pattern = '/ytcfg\.set\(\s*({.*?})\s*\)\s*;/s';
    if (preg_match($pattern, $html, $matches)) {
        $jsonString = $matches[1];
        $ytcfgArray = json_decode($jsonString, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $apiKey = $ytcfgArray['INNERTUBE_API_KEY'] ?? null;
            $client = $ytcfgArray['INNERTUBE_CONTEXT'];
            $visitorData = $ytcfgArray['VISITOR_DATA'];
            $sigTimestamp = $ytcfgArray['STS'];
            $jsUrl = $ytcfgArray['PLAYER_JS_URL'] ?? '';
        }
    }
    /** get base.js
    if (strpos($jsUrl, 'http') !== 0) $jsUrl = "https://www.youtube.com" . $jsUrl;
    $jsContent = $client->get($jsUrl)->getBody();
    **/

    return [
        "apiKey" => $apiKey,
        "context" => $client,
        "visitorData" => $visitorData,
        "sigTimestamp" => $sigTimestamp,
        "player_js_url" => $jsUrl,
        "ytcfg" => $ytcfgArray
    ];
}
$ct_data = getContentData($client, $videoId, $client_userAgent);
$apiKey = $apiKey ?? $ct_data['apiKey'];
$visitorData = $ct_data['visitorData'];
$sigTimestamp = $ct_data['sigTimestamp'];
$ct_client = $ct_data['context']['client'];
$accept_headers = $ct_client['acceptHeader'] ?? "*/*";
// header('Content-Type: application/json; charset=utf-8'); echo json_encode($ct_data, JSON_PRETTY_PRINT); exit();

function getBaseJs($client, $jsUrl){
    if (strpos($jsUrl, 'http') !== 0) {
        $jsUrl = "https://www.youtube.com" . $jsUrl;
    }
    $jsResponse = $client->get($jsUrl);
    return $jsResponse->getBody();
}
$jsUrl = $ct_data['player_js_url'];
$baseJs = getBaseJs($client, $jsUrl);
$regexSig = '/([$\w]{2,})=function\(\w\)\{\w=\w\.split\(""\)/';
preg_match($regexSig, $baseJs, $matches);
 header('Content-Type: application/json; charset=utf-8'); echo json_encode($matches, JSON_PRETTY_PRINT); exit();
 
$apiUrl = "https://www.youtube.com/youtubei/v1/player?key=" . $apiKey;
$payload = [
    "videoId" => $videoId,
    "context" => [
        "client" => [
            /*// com.google.android.youtube/20.42.40 (Linux; U; Android 14) gzip
            "userAgent" => $ct_client['userAgent'],
            'clientName' => 'ANDROID',
            'clientVersion' => '20.42.40',
            "osName" => $ct_client['osName'],
            "osVersion" => $ct_client['osVersion']*/
            
            // com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)
            /*"userAgent" => $ct_client['userAgent'],
            "clientName" => "IOS",
            "clientVersion" => "20.10.4",
            "osName" => $ct_client['osName'],
            "osVersion" => $ct_client['osVersion']*/

            "clientName" => $client_name,
            "clientVersion" => $client_version,
            "osName" => $ct_client['osName'],
            "osVersion" => $ct_client['osVersion'],
            "clientScreen" => "WATCH",
            "platform" => "MOBILE"
        ],
        "user" => [
            "lockedSafetyMode" => false
        ],
        "request" => [
            "useSsl" => true
        ]
    ],
    "playbackContext" => [
        "contentPlaybackContext" => [
            "signatureTimestamp" => $sigTimestamp
        ]
    ],
    "racyCheckOk" => true,
    "contentCheckOk" => true
];

$response = $client->post($apiUrl, [
    'json' => $payload,
    'headers' => [
        "User-Agent: " . $client_userAgent,
        "Accept: " . $accept_headers,
        "Content-Type: application/json",
        "x-youtube-client-name: " . $int_client_name,
        "x-youtube-client-version: " . $client_version,
        'Referer: https://www.youtube.com/'
    ]
]);
$data = $response->json();
// header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_PRETTY_PRINT); exit();

$dataUrl = null;
$adaptive = $data['streamingData']['formats'] ?? [];
foreach($adaptive as $f){
    if(isset($f['itag']) && $f['itag'] == 18) { $dataUrl = $f['url']; break; }
}
if (!$dataUrl) {
    foreach($adaptive as $f) {
        if(isset($f['url']) && strpos($f['mimeType'], 'video/mp4') !== false) { $dataUrl = $f['url']; break; }
    }
}
if (!$dataUrl) die("itag tidak ditemukan atau video diblokir.");
// header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_PRETTY_PRINT); exit;

// ==========================================
// PROSES STREAMING (PASSTHROUGH)
// ==========================================
// Bagian ini menggunakan cURL manual karena kita butuh streaming langsung (CURLOPT_RETURNTRANSFER => false)
$isStream = false;
$parsedUrl = parse_url($dataUrl);
$host = $parsedUrl['host'];
$headersData = [
    "Host: " . $host,
    "User-Agent: " . $client_userAgent,
    "Accept: " . $accept_headers,
    "Accept-Language: en-US,en;q=0.9",
    "Connection: keep-alive"
];

if (isset($_SERVER['HTTP_RANGE'])) {
    $headersData[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
}

if (ob_get_level()) ob_end_clean();
$ch = curl_init($dataUrl);
curl_setopt_array($ch, [
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_RETURNTRANSFER => false, 
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_BUFFERSIZE => 262144,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_HTTPHEADER => $headersData,
    CURLOPT_HEADERFUNCTION => function($curl, $header) use ($isStream) {
        $len = strlen($header);
        $h = strtolower($header);
        
        if (preg_match('/^http\/(1\.[01]|2|3)\s+(\d+)/', $h, $matches)) {
            http_response_code(intval($matches[2]));
            return $len;
        }
        
        $allowed = ['content-type:', 'content-length:', 'content-range:', 'accept-ranges:'];
        foreach ($allowed as $a) {
            if (strpos($h, $a) === 0) {
                if ($a === 'content-type:') {
                    header($isStream ? "Content-Type: video/mp4" : "Content-Type: application/octet-stream");
                    if (!$isStream) header("Content-Disposition: attachment; filename=\"video.mp4\"");
                } else {
                    header($header, false);
                }
                break;
            }
        }
        return $len;
    }
]);

curl_exec($ch);
curl_close($ch);